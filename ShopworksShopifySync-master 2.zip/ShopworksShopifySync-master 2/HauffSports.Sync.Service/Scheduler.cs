﻿using log4net;
using System;
using System.Collections.Generic;
using System.Threading;
using Cronos;

namespace HauffSports.Sync.Service
{
    public class Scheduler
    {
        public delegate void JobDelegate(Object state);
        private class SchedulerJob
        {
            public SchedulerJob(
                string name, 
                JobDelegate jobDelegate,
                object state,
                TimerCallback callback,
                string cron)
            {
                Name = name;
                Delegate = jobDelegate;
                State = state;
                Cron = CronExpression.Parse(cron);
                Timer = new Timer(callback, this, Timeout.Infinite, Timeout.Infinite);
            }

            public DateTime? Schedule()
            {
                var now = DateTime.UtcNow;
                var next = Cron.GetNextOccurrence(now);
                if (next != null)
                {
                    Timer.Change((TimeSpan)(next - now), Timeout.InfiniteTimeSpan);
                }
                return next;
            }

            public void Cancel()
            {
                Timer.Change(Timeout.InfiniteTimeSpan, Timeout.InfiniteTimeSpan);
            }

            public string Name { get; set; }
            public JobDelegate Delegate { get; set; }
            public object State { get; set; }
            public CronExpression Cron { get; set; }
            private Timer Timer { get; set; }
        }

        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly List<SchedulerJob> _jobs = new List<SchedulerJob>();
        private Thread _thread;
        private readonly Queue<SchedulerJob> _jobQueue = new Queue<SchedulerJob>();
        private readonly HashSet<string> _jobsInQueue = new HashSet<string>();
        private readonly ManualResetEvent _stopRequest = new ManualResetEvent(false);
        private readonly ManualResetEvent _queueNotEmpty = new ManualResetEvent(false);

        private bool EnqueueJob(SchedulerJob job)
        {
            lock (_jobQueue)
            {
                if (_jobsInQueue.Contains(job.Name))
                {
                    return false;
                }

                _jobQueue.Enqueue(job);
                _jobsInQueue.Add(job.Name);
                _queueNotEmpty.Set();

                return true;
            }
        }

        private SchedulerJob DequeueJob()
        {
            lock (_jobQueue)
            {
                SchedulerJob taskTuple = null;

                if (_jobQueue.Count > 0)
                {
                    taskTuple = _jobQueue.Dequeue();
                    _jobsInQueue.Remove(taskTuple.Name);
                }

                if (_jobQueue.Count == 0)
                {
                    _queueNotEmpty.Reset();
                }

                return taskTuple;
            }
        }

        public bool AddJob(string name, JobDelegate jobDelegate, Object state, string cron)
        {
            var job = new SchedulerJob(name, jobDelegate, state, JobTimerCallback, cron);
            _jobs.Add(job);
            return true;
        }

        private void JobTimerCallback(Object state)
        {
            if (state is SchedulerJob job)
            {
                Log.Debug($"Queuing Job for Run [Name: {job.Name}, NextRun: {job.Schedule()}]");
                EnqueueJob(job);
            }
        }

        public void Start()
        {
            Log.Info("Starting processing thread");

            _thread = new Thread(Loop);
            _thread.Start();

            _jobs.ForEach(job =>
                Log.Info($"Scheduling Job [Name: {job.Name}, NextRun: {job.Schedule()}]"));

            Log.Info("Started processing thread");
        }

        public void Stop()
        {
            Log.Info("Stopping processing thread");

            _jobs.ForEach(job =>
            {
                Log.Info($"Cancelling Job [Name: {job.Name}]");
                job.Cancel();
            });

            _stopRequest.Set();
            _thread.Join();

            Log.Info("Stopped processing thread");
        }

        private void Loop()
        {
            while (true)
            {
                WaitHandle.WaitAny(new[] { _stopRequest, _queueNotEmpty });

                if (_stopRequest.WaitOne(0))
                {
                    return;
                }

                SchedulerJob job = DequeueJob();

                if (job != null)
                {
                    Log.Info($"Running job [Name: {job.Name}]");

                    try
                    {
                        job.Delegate.Invoke(job.State);
                    }
                    catch (Exception e)
                    {
                        Log.Error($"Error Running Job [Name: {job.Name}", e);
                    }

                    Log.Info($"Job finished [Name: {job.Name}]");
                }
            }
        }
    }
}
