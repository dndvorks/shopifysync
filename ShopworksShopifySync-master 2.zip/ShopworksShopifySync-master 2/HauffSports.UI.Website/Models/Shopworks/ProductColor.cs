﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("ProductColor", Schema = "shopworks")]
    public class ProductColor : BaseShopworks
    {
        public string Name { get; set; }
    }
}