﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class ActiveStatus : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Vendor",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Product",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Employee",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Design",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Customer",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Vendor_ActiveStatus",
                schema: "shopworks",
                table: "Vendor",
                column: "ActiveStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Product_ActiveStatus",
                schema: "shopworks",
                table: "Product",
                column: "ActiveStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_ActiveStatus",
                schema: "shopworks",
                table: "Employee",
                column: "ActiveStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Design_ActiveStatus",
                schema: "shopworks",
                table: "Design",
                column: "ActiveStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Customer_ActiveStatus",
                schema: "shopworks",
                table: "Customer",
                column: "ActiveStatus");

            migrationBuilder.AddForeignKey(
                name: "FK_Customer_Status_ActiveStatus",
                schema: "shopworks",
                table: "Customer",
                column: "ActiveStatus",
                principalSchema: "shopworks",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Design_Status_ActiveStatus",
                schema: "shopworks",
                table: "Design",
                column: "ActiveStatus",
                principalSchema: "shopworks",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Employee_Status_ActiveStatus",
                schema: "shopworks",
                table: "Employee",
                column: "ActiveStatus",
                principalSchema: "shopworks",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Product_Status_ActiveStatus",
                schema: "shopworks",
                table: "Product",
                column: "ActiveStatus",
                principalSchema: "shopworks",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Vendor_Status_ActiveStatus",
                schema: "shopworks",
                table: "Vendor",
                column: "ActiveStatus",
                principalSchema: "shopworks",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Customer_Status_ActiveStatus",
                schema: "shopworks",
                table: "Customer");

            migrationBuilder.DropForeignKey(
                name: "FK_Design_Status_ActiveStatus",
                schema: "shopworks",
                table: "Design");

            migrationBuilder.DropForeignKey(
                name: "FK_Employee_Status_ActiveStatus",
                schema: "shopworks",
                table: "Employee");

            migrationBuilder.DropForeignKey(
                name: "FK_Product_Status_ActiveStatus",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropForeignKey(
                name: "FK_Vendor_Status_ActiveStatus",
                schema: "shopworks",
                table: "Vendor");

            migrationBuilder.DropIndex(
                name: "IX_Vendor_ActiveStatus",
                schema: "shopworks",
                table: "Vendor");

            migrationBuilder.DropIndex(
                name: "IX_Product_ActiveStatus",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropIndex(
                name: "IX_Employee_ActiveStatus",
                schema: "shopworks",
                table: "Employee");

            migrationBuilder.DropIndex(
                name: "IX_Design_ActiveStatus",
                schema: "shopworks",
                table: "Design");

            migrationBuilder.DropIndex(
                name: "IX_Customer_ActiveStatus",
                schema: "shopworks",
                table: "Customer");

            migrationBuilder.DropColumn(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Vendor");

            migrationBuilder.DropColumn(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Design");

            migrationBuilder.DropColumn(
                name: "ActiveStatus",
                schema: "shopworks",
                table: "Customer");
        }
    }
}
