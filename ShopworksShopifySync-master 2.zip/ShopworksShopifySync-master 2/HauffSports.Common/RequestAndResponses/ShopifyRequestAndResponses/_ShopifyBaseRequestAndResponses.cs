﻿using HauffSports.Common.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses
{
    public class BaseRequest
    {
        public BaseRequest()
        {
            ResourceType = ShopifyResourceType.unknown;
        }

        [JsonIgnore]
        public ShopifyResourceType ResourceType { get; set; }
    }

    public class BaseResponse
    {
        public BaseResponse()
        {
            IsSuccess = false;
            IsTokenBad = false;
            ErrorMessage = string.Empty;
        }

        public bool IsSuccess { get; set; }
        public bool IsTokenBad { get; set; }
        public string ErrorMessage { get; set; }
    }


    public class SaveRecordRequest : BaseRequest
    {
        public SaveRecordRequest()
        {
            RecordId = 0;
            ExtendedUrl = string.Empty;
            PostData = null;
        }

        [JsonIgnore]
        public long RecordId { get; set; }
        [JsonIgnore]
        public string ExtendedUrl { get; set; }
        public string PostData { get; set; }
    }

    public class SaveRecordResponse : BaseResponse
    {
        public SaveRecordResponse()
        {
            Data = null;
        }

        public JObject Data { get; set; }
    }

    public class DeleteRecordRequest : BaseRequest
    {
        public DeleteRecordRequest()
        {
            RecordId = 0;
        }

        public long RecordId { get; set; }
    }


    public class GetRecordRequest : BaseRequest
    {
        public GetRecordRequest()
        {
            RecordId = 0;
        }

        public long RecordId { get; set; }
    }

    public class GetRecordByQueryRequest : BaseRequest
    {
        public GetRecordByQueryRequest()
        {
            SearchFields = new Dictionary<string, string>();
        }

        public Dictionary<string, string> SearchFields { get; set; }
    }

    public class GetRecordResponse : BaseResponse
    {
        public GetRecordResponse()
        {
            Data = null;
        }

        public JObject Data { get; set; }
    }


    public class GetRecordsRequest : BaseRequest
    {
        public GetRecordsRequest()
        {
            NumberPerPage = 250;
        }

        public int NumberPerPage { get; set; }
    }

    public class GetRecordsResponse : BaseResponse
    {
        public GetRecordsResponse()
        {
            Data = null;
        }

        public JObject Data { get; set; }
    }

    public class GetRecordCountResponse : BaseResponse
    {
        public GetRecordCountResponse()
        {
            Count = 0;
        }

        public int Count { get; set; }
    }
}