﻿using HauffSports.UI.Website.Data;
using HauffSports.UI.Website.Models.Shopworks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using HauffSports.UI.Website.Models;

namespace HauffSports.UI.Website.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class ShopworksController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ShopworksController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("OrderNotifications")]
        public IEnumerable<OrderNotification> GetOrderNotifications(int offset = 0, int limit = 100)
        {
            return _context.OrderNotifications
                .OrderByDescending(o => o.UpdatedAt)
                .Skip(offset)
                .Take(limit)
                .ToList();
        }

        [HttpGet]
        [Route("Orders/{id}")]
        public Order GetOrder(string id)
        {
            return _context.Orders.FirstOrDefault(o => o.Id == id);
        }
    }
}
