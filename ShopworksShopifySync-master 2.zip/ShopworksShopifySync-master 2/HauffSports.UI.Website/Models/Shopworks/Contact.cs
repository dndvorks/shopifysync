﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Contact", Schema ="shopworks")]
    public class Contact : BaseShopworks
    {
        public string CustomerId { get; set; }
        public Customer Customer { get; set; }

        public string VendorId { get; set; }
        public Vendor Vendor { get; set; }

        public string NameFirst { get; set; }
        public string NameLast { get; set; }
        public string Title { get; set; }
        public string Department { get; set; }
        public string EmailPrimary { get; set; }
        public string Notes { get; set; }

        public List<ContactNumber> ContactNumbers { get; set; }
        public List<Address> Addresses { get; set; }
    }
}
