﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Status", Schema = "shopworks")]
    public class Status : BaseShopworks
    {
        public string Name { get; set; }
    }
}
