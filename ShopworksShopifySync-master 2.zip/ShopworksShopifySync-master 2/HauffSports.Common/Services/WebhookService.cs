﻿using HauffSports.Common.Clients.Shopify;
using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HauffSports.Common.Services
{
    public class WebhookService : BaseService
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private ShopifyWebhookClient WebhookClient { get; set; }

        public string WebhookUrl => this.WebhookClient.ShopifyWebhookUrl;

        public WebhookService(string shopifyPublicKey, string shopifySecreyKey, string shopifyUrl, string webhookUrl = "") : base()
        {
            this.WebhookClient = new ShopifyWebhookClient(shopifyPublicKey, shopifySecreyKey, shopifyUrl, webhookUrl);
        }

        public List<WebhookModel> GetWebhooks()
        {
            var response = WebhookClient.GetWebhooks(new GetRecordsRequest());
            if (!response.IsSuccess)
            {
                throw new ApplicationException("Get Webhooks Error [Error :" + response.ErrorMessage + "]");
            }
            return response.Webhooks;
        }

        public void ActivateWebhook(string webhookUrl)
        {
            WebhookClient.ShopifyWebhookUrl = webhookUrl;

            var response = WebhookClient.GetWebhooks(new GetRecordsRequest());
            if (!response.IsSuccess)
            {
                throw new ApplicationException("Get Webhooks Error [Error :" + response.ErrorMessage + "]");
            }

            var activateRequest = new ActivateWebhookRequest { Webhook = response.Webhooks.FirstOrDefault() };
            var activateResponse = WebhookClient.ActivateWebhook(activateRequest);

            if (!activateResponse.IsSuccess)
            {
                throw new ApplicationException("Activate Webhook Error [Error :" + response.ErrorMessage + "]");
            }
        }

        public void DeleteWebhook()
        {
            var response = WebhookClient.GetWebhooks(new GetRecordsRequest());

            if (!response.IsSuccess)
            {
                throw new ApplicationException("Get Webhooks Error [Error :" + response.ErrorMessage + "]");
            }

            var deleteResponse = WebhookClient.DeleteWebhook(new DeleteWebhookRequest { WebhookId = response.Webhooks.FirstOrDefault().Id });
            if (!deleteResponse.IsSuccess)
            {
                throw new ApplicationException("Delete Webhook Error [Error :" + response.ErrorMessage + "]");
            }
        }
    }
}
