using System.Diagnostics;
using System.IO;
using log4net;
using Microsoft.Extensions.Hosting;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace HauffSports.Sync.Service
{
    public class Worker : BackgroundService
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly Scheduler _scheduler = null;

        public Worker()
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile($"appsettings.json", true, true)
                .AddEnvironmentVariables();

            var settings = builder.Build().Get(typeof(AppSettings)) as AppSettings;

            void JobDelegate(object state)
            {
                if (state is string path)
                {
                    var fileInfo = new FileInfo(path);

                    log.Info($"Running executable [Path: {fileInfo.FullName}]");

                    var p = new Process {StartInfo = {FileName = fileInfo.Name, WorkingDirectory = fileInfo.DirectoryName ?? ".", CreateNoWindow = true}};
                    p.Start();
                    p.WaitForExit();

                    log.Info($"Process exited [StatusCode: {p.ExitCode}]");
                }
            }

            _scheduler = new Scheduler();

            foreach (var job in settings.Jobs)
            {
                _scheduler.AddJob(job.Name, JobDelegate, job.Path, job.Cron);
            }
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _scheduler.Start();
            await Task.Delay(Timeout.InfiniteTimeSpan, stoppingToken);
            _scheduler.Stop();
        }
    }
}
