﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models
{
    [Table("LegacyCustomer")]
    public class LegacyCustomer
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string EmailMain { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string AddressCity { get; set; }
        public string AddressState { get; set; }
        public string AddressZip { get; set; }
    }

    [Table("LegacyContact")]
    public class LegacyContact
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }

    [Table("LegacyDesignThumbnail")]
    public class LegacyDesignThumbnail
    {
        public int Id { get; set; }
        public int DesignId { get; set; }
        public int CustomerId { get; set; }
        public int LocationId { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public string FileName { get; set; }
    }

    [Table("LegacyProduct")]
    public class LegacyProduct
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string ProductClassId { get; set; }
        public string PartNumber { get; set; }
        public string Description { get; set; }
        public string Cost { get; set; }
        public string Colors { get; set; }
    }
}
