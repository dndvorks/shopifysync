﻿using Newtonsoft.Json;

namespace HauffSports.Common.Models.Shopify
{
    [JsonObject(MemberSerialization.OptIn, Title = "webhook")]
    public class WebhookModel : BaseModel
    {
        public WebhookModel()
        {
            this.Url = string.Empty;
            this.Event = string.Empty;
            this.Topic = string.Empty;
            this.Format = "json";
            this.IsActive = false;
        }

        [JsonProperty(PropertyName = "address")]
        public string Url { get; set; }
        public string Event { get; set; }
        [JsonProperty(PropertyName = "topic")]
        public string Topic { get; set; }
        [JsonProperty(PropertyName = "format")]
        public string Format { get; set; }
        public bool IsActive { get; set; }
    }
}