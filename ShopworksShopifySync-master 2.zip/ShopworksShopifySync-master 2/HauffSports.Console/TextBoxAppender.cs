﻿using log4net.Appender;
using log4net.Core;
using System;
using System.IO;
using System.Windows.Forms;

namespace HauffSports.Console
{
    public class TextBoxAppender : AppenderSkeleton
    {
        private RichTextBoxEx _textBox;
        public string FormName { get; set; }
        public string TextBoxName { get; set; }

        protected override void Append(LoggingEvent loggingEvent)
        {
            if (_textBox == null)
            {
                if (String.IsNullOrEmpty(FormName) ||
                    String.IsNullOrEmpty(TextBoxName))
                    return;

                Form form = Application.OpenForms[FormName];
                if (form == null)
                    return;

                _textBox = form.Controls[TextBoxName] as RichTextBoxEx;
                if (_textBox == null)
                    return;

                form.FormClosing += (s, e) => _textBox = null;
            }
            
            using (var sw = new StringWriter())
            {
                Layout.Format(sw, loggingEvent);
                sw.Flush();
                AppendTextBox(sw.ToString() + Environment.NewLine);
            }
        }

        private void AppendTextBox(string value)
        {
            if (_textBox.InvokeRequired)
            {
                _textBox.Invoke(new Action<string>(AppendTextBox), new object[] { value });
                return;
            }
            _textBox.AppendTextWithoutScroll(value);
        }
    }
}
