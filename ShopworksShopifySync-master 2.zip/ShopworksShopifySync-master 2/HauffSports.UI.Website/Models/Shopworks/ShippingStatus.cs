﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("ShippingStatus", Schema = "shopworks")]
    public class ShippingStatus : BaseShopworks
    {
        public string Name { get; set; }
    }
}
