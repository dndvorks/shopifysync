﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class CustomerAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    CompanyName = table.Column<string>(nullable: true),
                    EmailMain = table.Column<string>(nullable: true),
                    Address1 = table.Column<string>(nullable: true),
                    Address2 = table.Column<string>(nullable: true),
                    AddressCity = table.Column<string>(nullable: true),
                    AddressState = table.Column<string>(nullable: true),
                    AddressZip = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.AlterColumn<int>(
                name: "CustomerId",
                table: "SalesOrders",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CustomerCompanyName",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CustomerOrderedBy",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.Sql("UPDATE SalesOrders SET CustomerOrderedBy = CONCAT(CustomerNameFirst, ' ', CustomerNameLast)");

            migrationBuilder.DropColumn(
                name: "CustomerNameFirst",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "CustomerNameLast",
                table: "SalesOrders");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    CustomerId = table.Column<int>(nullable: false),
                    ContactId = table.Column<int>(nullable: false),
                    Email = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    CompanyName = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.RenameColumn(
                name: "CustomerOrderedBy",
                table: "SalesOrders",
                newName: "CustomerNameFirst");

            migrationBuilder.DropColumn(
                name: "CustomerCompanyName",
                table: "SalesOrders");

            migrationBuilder.AddColumn<string>(
                name: "CustomerNameLast",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CustomerId",
                table: "SalesOrders",
                nullable: true,
                oldClrType: typeof(int));
        }
    }
}
