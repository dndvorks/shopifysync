﻿using HauffSports.Common.Models.Shopify;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses
{
    public class GetOrderResponse : BaseResponse
    {
        public GetOrderResponse()
        {
            this.Order = new ShopifyOrderModel();
        }

        public ShopifyOrderModel Order { get; set; }
    }

    public class GetOrdersResponse : BaseResponse
    {
        public GetOrdersResponse()
        {
            this.Orders = new List<ShopifyOrderModel>();
        }

        public List<ShopifyOrderModel> Orders { get; set; }
    }

    public class GetOrderTransactionsResponse : BaseResponse
    {
        public GetOrderTransactionsResponse()
        {
            this.OrderTransactions = new List<ShopifyOrderTransactionModel>();
        }

        public List<ShopifyOrderTransactionModel> OrderTransactions { get; set; }
    }
}