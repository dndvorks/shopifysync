﻿using System;
using System.Collections.Generic;

namespace HauffSports.Common.Models.Shopify
{
    public class ShopifyOrderModel : BaseModel
    {
        public ShopifyOrderModel()
        {
            this.Email = string.Empty;
            this.ClosedAt = null;
            this.Number = 0;
            this.Note = string.Empty;
            this.Token = string.Empty;
            this.Gateway = string.Empty;
            this.Test = string.Empty;
            this.TotalPrice = 0.0m;
            this.SubtotalPrice = 0.0m;
            this.TotalWeight = 0.0m;
            this.TotalTax = 0.0m;
            this.TaxesIncluded = false;
            this.Currency = string.Empty;
            this.FinancialStatus = string.Empty;
            this.Confirmed = false;
            this.TotalDiscounts = 0.0m;
            this.TotalLineItemsPrice = 0.0m;
            this.CartToken = string.Empty;
            this.BuyerAcceptsMarketing = false;
            this.Name = string.Empty;
            this.ReferringSite = string.Empty;
            this.LandingSite = string.Empty;
            this.CancelledAt = null;
            this.CancelReason = string.Empty;
            this.TotalPriceUsd = 0.0m;
            this.CheckoutToken = string.Empty;
            this.Reference = string.Empty;
            this.UserId = 0;
            this.LocationId = 0;
            this.SourceIdentifier = string.Empty;
            this.SourceUrl = string.Empty;
            this.ProcessedAt = null;
            this.DeviceId = string.Empty;
            this.PhoneNumber = string.Empty;
            this.CustomerLocale = string.Empty;
            this.AppId = 0;
            this.BrowserIP = string.Empty;
            this.LandingSiteRef = string.Empty;
            this.OrderNumber = 0;
            this.DiscountCodes = new List<ShopifyOrderDiscountModel>();
            this.NoteAttributes = new Dictionary<string, string>();
            this.PaymentGatewayNames = new List<string>();
            this.ProcessingMethod = string.Empty;
            this.CheckoutId = 0;
            this.SourceName = string.Empty;
            this.FulfillmentStatus = string.Empty;
            this.TaxLines = new List<ShopifyTaxLineModel>();
            this.Tags = string.Empty;
            this.ContactEmail = string.Empty; 
            this.OrderStatusUrl = string.Empty;
            this.LineItems = new List<ShopifyOrderLineItemModel>();
            this.ShippingLines = new List<ShopifyOrderShippingModel>();
            this.BillingAddress = new AddressModel();
            this.ShippingAddress = new AddressModel();
            this.Fulfillments = new List<ShopifyOrderFulfillmentModel>();
            this.ClientDetails = new ShopifyClientDetailModel();
            this.PaymentDetails = new ShopifyPaymentDetailModel();
            this.Customer = new CustomerModel();
        }

        public string Email { get; set; }
        public DateTimeOffset? ClosedAt { get; set; }
        public long Number { get; set; }
        public string Note { get; set; }
        public string Token { get; set; }
        public string Gateway { get; set; }
        public string Test { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal SubtotalPrice { get; set; }
        public decimal TotalWeight { get; set; }
        public decimal TotalTax { get; set; }
        public bool TaxesIncluded { get; set; }
        public string Currency { get; set; }
        public string FinancialStatus { get; set; }
        public bool Confirmed { get; set; }
        public decimal TotalDiscounts { get; set; }
        public decimal TotalLineItemsPrice { get; set; }
        public string CartToken { get; set; }
        public bool BuyerAcceptsMarketing { get; set; }
        public string Name { get; set; }
        public string ReferringSite { get; set; }
        public string LandingSite { get; set; }
        public DateTimeOffset? CancelledAt { get; set; }
        public string CancelReason { get; set; }
        public decimal TotalPriceUsd { get; set; }
        public string CheckoutToken { get; set; }
        public string Reference { get; set; }
        public long UserId { get; set; }
        public long LocationId { get; set; }
        public string SourceIdentifier { get; set; }
        public string SourceUrl { get; set; }
        public DateTimeOffset? ProcessedAt { get; set; }
        public string DeviceId { get; set; }
        public string PhoneNumber { get; set; }
        public string CustomerLocale { get; set; }
        public long AppId { get; set; }
        public string BrowserIP { get; set; }
        public string LandingSiteRef { get; set; }
        public long OrderNumber { get; set; }
        public List<ShopifyOrderDiscountModel> DiscountCodes { get; set; }
        public Dictionary<string, string> NoteAttributes { get; set; }
        public List<string> PaymentGatewayNames { get; set; }
        public string ProcessingMethod { get; set; }
        public long CheckoutId { get; set; }
        public string SourceName { get; set; }
        public string FulfillmentStatus { get; set; }
        public List<ShopifyTaxLineModel> TaxLines { get; set; }
        public string Tags { get; set; }
        public string ContactEmail { get; set; }
        public string OrderStatusUrl { get; set; }
        public List<ShopifyOrderLineItemModel> LineItems { get; set; }
        public List<ShopifyOrderShippingModel> ShippingLines { get; set; }
        public AddressModel BillingAddress { get; set; }
        public AddressModel ShippingAddress { get; set; }
        public List<ShopifyOrderFulfillmentModel> Fulfillments { get; set; }
        public ShopifyClientDetailModel ClientDetails { get; set; }
        public ShopifyPaymentDetailModel PaymentDetails { get; set; }
        public CustomerModel Customer { get; set; }
    }

    public class ShopifyOrderLineItemModel : BaseModel
    {
        public ShopifyOrderLineItemModel()
        {
            this.VariantId = 0;
            this.Title = string.Empty;
            this.Quantity = 0;
            this.Price = 0.0m;
            this.Grams = 0;
            this.Sku = string.Empty;
            this.VariantTitle = string.Empty;
            this.Vendor = string.Empty;
            this.FulfillmentService = string.Empty;
            this.ProductId = 0;
            this.RequiresShipping = false;
            this.IsTaxable = false;
            this.IsGiftCard = false;
            this.PreTaxPrice = 0.0m;
            this.Name = string.Empty;
            this.VariantInventoryManagement = string.Empty;
            this.Properties = new List<Dictionary<string, string>>();
            this.ProductExists = false;
            this.FulfillmentQuantity = 0;
            this.TotalDiscount = 0.0m;
            this.FulfillmentStatus = string.Empty;
            this.TaxLines = new List<ShopifyTaxLineModel>();
            this.OriginLocation = new AddressModel();
            this.DestinationLocation = new AddressModel();
        }

        public long VariantId { get; set; }
        public string Title { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public int Grams { get; set; }
        public string Sku { get; set; }
        public string VariantTitle { get; set; }
        public string Vendor { get; set; }
        public string FulfillmentService { get; set; }
        public long ProductId { get; set; }
        public bool RequiresShipping { get; set; }
        public bool IsTaxable { get; set; }
        public bool IsGiftCard { get; set; }
        public decimal PreTaxPrice { get; set; }
        public string Name { get; set; }
        public string VariantInventoryManagement { get; set; }
        public List<Dictionary<string, string>> Properties { get; set; }
        public bool ProductExists { get; set; }
        public int FulfillmentQuantity { get; set; }
        public decimal TotalDiscount { get; set; }
        public string FulfillmentStatus { get; set; }
        public List<ShopifyTaxLineModel> TaxLines { get; set; }
        public AddressModel OriginLocation { get; set; }
        public AddressModel DestinationLocation { get; set; }
    }

    public class ShopifyOrderTransactionModel : BaseModel
    {
        public ShopifyOrderTransactionModel()
        {
            this.OrderId = 0;
            this.GiftCardId = 0;
            this.LocationId = 0;
            this.UserId = 0;
            this.ParentId = 0;
            this.DeviceId = 0;
            this.Kind = string.Empty;
            this.Gateway = string.Empty;
            this.Status = string.Empty;
            this.Message = string.Empty;
            this.Authorization = string.Empty;
            this.Currency = string.Empty;
            this.ErrorCode = string.Empty;
            this.SourceName = string.Empty;
            this.Amount = 0.0m;
            this.Test = false;
        }

        public long OrderId { get; set; }
        public long GiftCardId { get; set; }
        public long LocationId { get; set; }
        public long UserId { get; set; }
        public long ParentId { get; set; }
        public long DeviceId { get; set; }
        public string Kind { get; set; }
        public string Gateway { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public string Authorization { get; set; }
        public string Currency { get; set; }
        public string ErrorCode { get; set; }
        public string SourceName { get; set; }
        public decimal Amount { get; set; }
        public bool Test { get; set; }
    }

    public class ShopifyOrderDiscountModel
    {
        public ShopifyOrderDiscountModel()
        {
            this.Code = string.Empty;
            this.Type = string.Empty;
            this.Amount = 0.0m;
        }

        public string Code { get; set; }
        public string Type { get; set; }
        public decimal Amount { get; set; }
    }

    public class ShopifyOrderFulfillmentModel : BaseModel
    {
        public ShopifyOrderFulfillmentModel()
        {
            this.OrderId = 0;
            this.Status = string.Empty;
            this.TrackingCompany = string.Empty;
            this.TrackingNumber = string.Empty;
        }

        public long OrderId { get; set; }
        public string Status { get; set; }
        public string TrackingCompany { get; set; }
        public string TrackingNumber { get; set; }
    }

    public class ShopifyTaxLineModel
    {
        public ShopifyTaxLineModel()
        {
            this.Price = 0.0m;
            this.Rate = 0.0m;
            this.Title = string.Empty;
        }

        public decimal Price { get; set; }
        public decimal Rate { get; set; }
        public string Title { get; set; }
    }

    public class ShopifyOrderShippingModel : BaseModel
    {
        public ShopifyOrderShippingModel()
        {
            this.Title = string.Empty;
            this.Code = string.Empty;
            this.Source = string.Empty;
            this.PhoneNumber = string.Empty;
            this.RequestedFulfillmentServiceId = string.Empty;
            this.DeliveryCategory = string.Empty;
            this.CarrierIdentifier = string.Empty;
            this.Price = 0.0m;
            this.DiscountedPrice = 0.0m;
        }

        public string Title { get; set; }
        public string Code { get; set; }
        public string Source { get; set; }
        public string PhoneNumber { get; set; }
        public string RequestedFulfillmentServiceId { get; set; }
        public string DeliveryCategory { get; set; }
        public string CarrierIdentifier { get; set; }
        public decimal Price { get; set; }
        public decimal DiscountedPrice { get; set; }
        public List<ShopifyTaxLineModel> TaxLines { get; set; }
    }

    public class ShopifyPaymentDetailModel
    {
        public ShopifyPaymentDetailModel()
        {
            this.AVSResultCode = string.Empty;
            this.CreditCardBin = string.Empty;
            this.CVVResultCode = string.Empty;
            this.CreditCardNumber = string.Empty;
            this.CreditCardCompany = string.Empty;
        }

        public string AVSResultCode { get; set; }
        public string CreditCardBin { get; set; }
        public string CVVResultCode { get; set; }
        public string CreditCardNumber { get; set; }
        public string CreditCardCompany { get; set; }
    }

    public class ShopifyClientDetailModel
    {
        public ShopifyClientDetailModel()
        {
            this.BrowserIp = string.Empty;
            this.AcceptLanguage = string.Empty;
            this.UserAgent = string.Empty;
            this.SessionHash = string.Empty;
            this.BrowserWidth = 0;
            this.BrowserHeight = 0;
        }

        public string BrowserIp { get; set; }
        public string AcceptLanguage { get; set; }
        public string UserAgent { get; set; }
        public string SessionHash { get; set; }
        public int BrowserWidth { get; set; }
        public int BrowserHeight { get; set; }
    }
}