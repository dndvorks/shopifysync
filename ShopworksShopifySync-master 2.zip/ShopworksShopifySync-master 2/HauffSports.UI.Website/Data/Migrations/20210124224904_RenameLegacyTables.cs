﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class RenameLegacyTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Contacts",
                newName: "LegacyContact");

            migrationBuilder.RenameTable(
                name: "Customers",
                newName: "LegacyCustomer");

            migrationBuilder.RenameTable(
                name: "DesignThumbnails",
                newName: "LegacyDesignThumbnail");

            migrationBuilder.RenameTable(
                name: "Products",
                newName: "LegacyProduct");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "LegacyContact",
                newName: "Contacts");

            migrationBuilder.RenameTable(
                name: "LegacyCustomer",
                newName: "Customers");

            migrationBuilder.RenameTable(
                name: "LegacyDesignThumbnail",
                newName: "DesignThumbnails");

            migrationBuilder.RenameTable(
                name: "LegacyProduct",
                newName: "Products");
        }
    }
}
