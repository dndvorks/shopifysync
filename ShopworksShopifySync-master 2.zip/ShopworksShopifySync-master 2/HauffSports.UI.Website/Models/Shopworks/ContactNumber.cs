﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("ContactNumber", Schema = "shopworks")]
    public class ContactNumber : BaseShopworks
    {
        public string ContactId { get; set; }
        public Contact Contact { get; set; }

        public string Label { get; set; }
        public string Number { get; set; }
        public string Email { get; set; }

        [ForeignKey("IsPhone")]
        public string PhoneStatus { get; set; }
        public Status IsPhone { get; set; }

        [ForeignKey("IsFax")]
        public string FaxStatus { get; set; }
        public Status IsFax { get; set; }

        [ForeignKey("IsEmail")]
        public string EmailStatus { get; set; }
        public Status IsEmail { get; set; }

        [ForeignKey("IsPrimary")]
        public string PrimaryStatus { get; set; }
        public Status IsPrimary { get; set; }
    }
}
