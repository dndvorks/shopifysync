﻿using System;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.IO;
using System.Drawing;

namespace HauffSports.Common.Models.Shopify
{
    public class ProductModel
    {
        public ProductModel()
        {
            this.Id = 0;
            this.PartNumber = null;
            this.Title = string.Empty;
            this.BodyHtml = string.Empty;
            this.Vendor = string.Empty;
            this.ProductType = string.Empty;
            this.Tags = string.Empty;
            this.Metafields = new List<MetafieldModel>();
            this.Options = new List<OptionModel>();
            this.Images = new List<ProductImageModel>();
            this.ImageUrls = new List<string>();
            this.Variants = new List<ProductVariantModel>();
        }

        [JsonIgnore]
        public List<string> Skus { get { return Variants.Select(v => v.Sku).ToList(); } }
        [JsonIgnore]
        public string PartNumber {
            get {
                return partNumber ?? Variants[0].Sku.Replace(string.Format("-{0}-{1}", Variants[0].Color, Variants[0].Size), "");
            }
            set {
                partNumber = value;
            }
        }
        private string partNumber;

        [JsonProperty(PropertyName = "id", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        public long Id { get; set; }
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
        [JsonProperty(PropertyName = "body_html")]
        public string BodyHtml { get; set; }
        [JsonProperty(PropertyName = "vendor")]
        public string Vendor { get; set; }
        [JsonProperty(PropertyName = "product_type")]
        public string ProductType { get; set; }
        [JsonProperty(PropertyName = "tags")]
        public string Tags { get; set; }
        [JsonProperty(PropertyName = "handle")]
        public string Handle { get; set; }
        [JsonProperty(PropertyName = "template_suffix")]
        public string TemplateSuffix { get; set; }
        [JsonProperty(PropertyName = "published_scope")]
        public string PublishedScope { get; set; }
        [JsonProperty(PropertyName = "published_at")]
        public DateTimeOffset? PublishedAt { get; set; }
        [JsonProperty(PropertyName = "metafields")]
        public List<MetafieldModel> Metafields { get; set; }
        [JsonProperty(PropertyName = "options")]
        public List<OptionModel> Options { get; set; }
        [JsonProperty(PropertyName = "variants")]
        public List<ProductVariantModel> Variants { get; set; }
        [JsonProperty(PropertyName = "images")]
        public List<ProductImageModel> Images { get; set; }
        [JsonIgnore()]
        public List<string> ImageUrls { get; set; }
    }

    public class ProductVariantModel
    {
        public ProductVariantModel()
        {
            this.Id = 0;
            this.Sku = string.Empty;
            this.Barcode = null;
            this.Color = string.Empty;
            this.Size = string.Empty;
            this.Option3 = null;
            this.InventoryManagement = "shopify";
            this.InventoryQuantity = 0;
            this.InventoryPolicy = "continue";
            this.InventoryItemId = 0;
            this.Price = 0.0m;
            this.Taxable = false;
            this.ProductId = 0;
            this.ImageId = null;

        }

        [JsonProperty(PropertyName = "id", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        public long Id { get; set; }
        [JsonProperty(PropertyName = "sku")]
        public string Sku { get; set; }
        [JsonProperty(PropertyName = "barcode", NullValueHandling = NullValueHandling.Ignore)]
        public string Barcode { get; set; }
        [JsonProperty(PropertyName = "option1")]
        public string Color { get; set; }
        [JsonProperty(PropertyName = "option2")]
        public string Size { get; set; }
        [JsonProperty(PropertyName = "option3", NullValueHandling = NullValueHandling.Ignore)]
        public string Option3 { get; set; }
        [JsonProperty(PropertyName = "inventory_management", NullValueHandling = NullValueHandling.Ignore)]
        public string InventoryManagement { get; set; }
        [JsonProperty(PropertyName = "inventory_quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int InventoryQuantity { internal get; set; }
        [JsonProperty(PropertyName = "inventory_policy", NullValueHandling = NullValueHandling.Ignore)]
        public string InventoryPolicy { get; set; }
        [JsonProperty(PropertyName = "inventory_item_id", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        public long InventoryItemId { internal get; set; }
        [JsonProperty(PropertyName = "price")]
        public decimal Price { get; set; }
        [JsonProperty(PropertyName = "taxable")]
        public bool Taxable { get; set; }
        [JsonProperty(PropertyName = "product_id", DefaultValueHandling = DefaultValueHandling.Ignore)]
        public long ProductId { get; set; }
        [JsonProperty(PropertyName = "image_id", DefaultValueHandling = DefaultValueHandling.Ignore)]
        public long? ImageId { get; set; }
        [JsonProperty(PropertyName = "title", NullValueHandling = NullValueHandling.Ignore)]
        public string Title { get; set; }
        [JsonProperty(PropertyName = "fulfillment_service", NullValueHandling = NullValueHandling.Ignore)]
        public string FulfillmentService { get; set; }
        [JsonProperty(PropertyName = "weight_unit", NullValueHandling = NullValueHandling.Ignore)]
        public string WeightUnit { get; set; }
        [JsonProperty(PropertyName = "position")]
        public int Position { get; set; }
        [JsonProperty(PropertyName = "grams")]
        public int Grams { get; set; }
        [JsonProperty(PropertyName = "old_inventory_quantity")]
        public int OldInventoryQuantity { internal get; set; }
        [JsonProperty(PropertyName = "compare_at_price", NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CompareAtPrice { get; set; }
        [JsonProperty(PropertyName = "weight", NullValueHandling = NullValueHandling.Ignore)]
        public decimal? Weight { get; set; }
        [JsonProperty(PropertyName = "requires_shipping")]
        public bool RequiresShipping { get; set; }
    }

    public class ProductImageModel
    {
        public ProductImageModel()
        {
            this.Attachment = string.Empty;
        }

        [JsonProperty(PropertyName = "attachment")]
        public string Attachment { get; set; }
    }

    public class OptionModel
    {
        public OptionModel()
        {
            this.Name = string.Empty;
            this.Values = new List<string>();
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        [JsonProperty(PropertyName = "values")]
        public List<string> Values { get; set; }
    }
}