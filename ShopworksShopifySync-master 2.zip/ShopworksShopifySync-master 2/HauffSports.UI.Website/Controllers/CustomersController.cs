﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HauffSports.UI.Website.Data;
using HauffSports.UI.Website.Models;
using Microsoft.AspNetCore.Authorization;

namespace HauffSports.UI.Website.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CustomersController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("Search")]
        public IEnumerable<LegacyCustomer> GetCustomers()
        {
            if (Request.Query.Keys.Contains("q"))
            {
                var q = Request.Query["q"];

                return _context.LegacyCustomers.Where(
                    c => c.CompanyName.Contains(q) || c.EmailMain.Contains(q));
            }

            return new List<LegacyCustomer>();
        }

        [HttpGet]
        [Route("{id:int}")]
        public LegacyCustomer GetCustomerById(int id)
        {
            return _context.LegacyCustomers.Where(c => c.Id == id).FirstOrDefault();
        }

        [HttpGet]
        [Route("{id:int}/Contacts")]
        public IEnumerable<LegacyContact> GetContacts(int id)
        {
            return _context.LegacyContacts.Where(c => c.CustomerId == id);
        }        
        
        [HttpGet]
        [Route("Contacts/{id:int}")]
        public LegacyContact GetContactById(int id)
        {
            return _context.LegacyContacts.Where(c => c.Id == id).FirstOrDefault();
        }

        [HttpGet]
        [Route("{id:int}/Designs")]
        public IEnumerable<LegacyDesignThumbnail> GetDesigns(int id)
        {
            return _context.LegacyDesignThumbnails.Where(c => c.CustomerId == id);
        }

        [HttpGet]
        [Route("Designs/{id:int}")]
        public LegacyDesignThumbnail GetDesignById(int id)
        {
            return _context.LegacyDesignThumbnails.Where(c => c.Id == id).FirstOrDefault();
        }
    }
}