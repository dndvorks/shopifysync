﻿using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using System;
using System.Collections.Generic;
using HauffSports.Common.Mappers;
using HauffSports.Common.Enums;
using System.Linq;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;
using System.IO;

namespace HauffSports.Common.Clients.Shopify
{
    public class ShopifyWebhookClient : ShopifyBaseClient
    {
        public string ShopifyWebhookUrl { get; set; }

        public ShopifyWebhookClient(string apiPublicKey, string apiSecretKey, string url, string shopifyWebhookUrl="") : 
            base(apiPublicKey, apiSecretKey, url)
        {
            this.ShopifyWebhookUrl = shopifyWebhookUrl;
        }

        // From shopify: The /admin/webhooks.json endpoint only returns the webhooks that 
        //               you have registered with that API key. There is no way to retrieve 
        //               admin-created webhooks using the API at this time.

        /// <summary>
        ///     Gets all of the shopify webhooks for a certain date range.
        /// </summary>
        /// <param name="request">GetRecordsRequest</param>
        /// <returns>GetOrdersResponse</returns>
        public GetWebhooksResponse GetWebhooks(GetRecordsRequest request)
        {
            try
            {
                var response = new GetWebhooksResponse();
                
                request.ResourceType = ShopifyResourceType.webhooks;
                var baseResponse = GetRecords(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                response.Webhooks = GetWebhookList();
                if (baseResponse.Data.Count != 0)
                {
                    var activeWebhooks = ShopifyMapper.MapToList<WebhookModel>(baseResponse.Data, ShopifyResourceType.webhooks);
                    foreach (var webhook in activeWebhooks)
                    {
                        var existingWebhook = response.Webhooks.FirstOrDefault(w => w.Topic.Equals(webhook.Topic, StringComparison.CurrentCultureIgnoreCase));
                        if (existingWebhook == null) response.Webhooks.Add(webhook);
                        else
                        {
                            existingWebhook.Id = webhook.Id;
                            existingWebhook.Url = webhook.Url;
                            existingWebhook.Format = webhook.Format;
                            existingWebhook.IsActive = webhook.IsActive;
                            existingWebhook.CreatedAt = webhook.CreatedAt;
                            existingWebhook.UpdatedAt = webhook.UpdatedAt;
                        }
                    }
                }
                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new GetWebhooksResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new GetWebhooksResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Activates a new webhook or updates and existing webhook.
        /// </summary>
        /// <param name="request">ActivateWebhookRequest</param>
        /// <returns>ActivateWebhookResponse</returns>
        public ActivateWebhookResponse ActivateWebhook(ActivateWebhookRequest request)
        {
            try
            {
                var response = new ActivateWebhookResponse();
                
                var baseRequest = new SaveRecordRequest { ResourceType = ShopifyResourceType.webhooks };

                if (request.Webhook.Id == 0)
                {
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    var baseResponse = AddRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                }
                else
                {
                    baseRequest.PostData = JsonConvert.SerializeObject(new { webhook = JObject.Parse(JsonConvert.SerializeObject(request)) });
                    baseRequest.RecordId = request.Webhook.Id;
                    var baseResponse = UpdateRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                }

                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new ActivateWebhookResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new ActivateWebhookResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Deletes a specific webhook based on an id.
        /// </summary>
        /// <param name="request">DeleteRecordRequest</param>
        /// <returns>DeleteWebhookResponse</returns>
        public DeleteWebhookResponse DeleteWebhook(DeleteWebhookRequest request)
        {
            try
            {
                var response = new DeleteWebhookResponse();
                
                var baseRequest = new DeleteRecordRequest { RecordId = request.WebhookId, ResourceType = ShopifyResourceType.webhooks };
                var baseResponse = DeleteRecord(baseRequest);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new DeleteWebhookResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new DeleteWebhookResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        /// Gets a complete list of all the possible webhooks in shopify.
        /// </summary>
        /// <returns>List<WebhookModel></returns>
        private List<WebhookModel> GetWebhookList()
        {
            var lst = new List<WebhookModel>();
            lst.Add(new WebhookModel { Url = ShopifyWebhookUrl, Event = "Order", Topic = "orders/create" });
            return lst;
        }
    }
}