﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HauffSports.UI.Website.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class ConfirmAccountConfirmationModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
