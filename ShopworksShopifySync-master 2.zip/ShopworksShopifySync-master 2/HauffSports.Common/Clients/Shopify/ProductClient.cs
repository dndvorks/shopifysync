﻿using HauffSports.Common.Enums;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Net;

namespace HauffSports.Common.Clients.Shopify
{
    public class ShopifyProductClient : ShopifyBaseClient
    {
        public ShopifyProductClient(string apiPublicKey, string apiSecretKey, string url) : 
            base(apiPublicKey, apiSecretKey, url)
        {
        }

        /// <summary>
        ///     Gets a shopify product for a specific product id.
        /// </summary>
        /// <param name="request">GetShopifyRecordRequest</param>
        /// <returns>GetProductResponse</returns>
        public GetProductResponse GetProduct(GetRecordRequest request)
        {
            try
            {                
                request.ResourceType = ShopifyResourceType.products;

                var baseResponse = GetRecord(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                var response = baseResponse.Data.ToObject<GetProductResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetProductResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets a shopify product for specific values.
        /// </summary>
        /// <param name="request">GetShopifyRecordByQueryRequest</param>
        /// <returns>GetProductResponse</returns>
        public GetProductResponse GetProductByQuery(GetRecordByQueryRequest request)
        {
            try
            {                
                request.ResourceType = ShopifyResourceType.products;

                var baseResponse = GetRecordByQuery(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                var response = baseResponse.Data.ToObject<GetProductsResponse>();

                var titleSearch = request.SearchFields.FirstOrDefault(s => s.Key.Equals("title", StringComparison.CurrentCultureIgnoreCase));

                var product = response.Products.FirstOrDefault(p => p.Title.Equals(titleSearch.Value, StringComparison.CurrentCultureIgnoreCase));

                var productResponse = new GetProductResponse()
                {
                    Product = product,
                    IsSuccess = true
                };

                return productResponse;
            }
            catch (Exception ex)
            {
                return new GetProductResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets all of the shopify products for a certain date range.
        /// </summary>
        /// <param name="request">GetRecordsRequest</param>
        /// <returns>GetProductsResponse</returns>
        public GetProductsResponse GetProducts(GetRecordsRequest request)
        {
            try
            {
                request.ResourceType = ShopifyResourceType.products;

                var baseResponse = GetRecords(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetProductsResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetProductsResponse { ErrorMessage = ex.Message };
            }
        }
        
        /// <summary>
        ///     Gets a shopify product for a specific product id.
        /// </summary>
        /// <param name="request">GetShopifyRecordRequest</param>
        /// <returns>GetProductResponse</returns>
        public GetProductMetafieldsResponse GetProductMetafields(GetRecordRequest request)
        {
            try
            {                
                request.ResourceType = ShopifyResourceType.products;

                var baseResponse = GetMetafieldRecords(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                var response = baseResponse.Data.ToObject<GetProductMetafieldsResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetProductMetafieldsResponse { ErrorMessage = ex.Message };
            }
        }
        
        /// <summary>
        ///     Creates or updates a shopify product.
        /// </summary>
        /// <param name="request">SaveProductRequest</param>
        /// <returns>SaveShopifyRecordResponse</returns>
        public SaveProductResponse SaveProduct(SaveProductRequest request)
        {
            try
            {                
                var baseRequest = new SaveRecordRequest { ResourceType = ShopifyResourceType.products };
                var jsonSettings = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                var jobject = JObject.Parse(JsonConvert.SerializeObject(request, Formatting.None, jsonSettings));
                if (jobject["product"]["images"].ToString() == "[]")
                    jobject["product"]["images"].Parent.Remove();

                if (request.Product.Id == 0)
                {
                    baseRequest.PostData = jobject.ToString();
                    var baseResponse = AddRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                    var response = baseResponse.Data.ToObject<SaveProductResponse>();
                    response.IsSuccess = true;
                    return response;
                }
                else
                {                    
                    baseRequest.PostData = jobject.ToString();
                    baseRequest.RecordId = request.Product.Id;
                    var baseResponse = UpdateRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                    var response = baseResponse.Data.ToObject<SaveProductResponse>();
                    response.IsSuccess = true;
                    return response;
                }
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new SaveProductResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new SaveProductResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates or updates a shopify product variant.
        /// </summary>
        /// <param name="request">SaveProductVariantRequest</param>
        /// <returns>SaveProductVariantResponse</returns>
        public SaveProductVariantResponse SaveProductVariant(SaveProductVariantRequest request)
        {
            try
            {                
                var baseRequest = new SaveRecordRequest();

                if (request.ProductVariant.Id == 0)
                {
                    baseRequest.ResourceType = ShopifyResourceType.products;
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.ExtendedUrl = "/" + request.ProductId + "/variants";
                    var baseResponse = AddRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                    var response = baseResponse.Data.ToObject<SaveProductVariantResponse>();
                    response.IsSuccess = true;
                    return response;
                }
                else
                {
                    baseRequest.ResourceType = ShopifyResourceType.variants;
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.RecordId = request.ProductVariant.Id;
                    var baseResponse = UpdateRecord(baseRequest);

                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                    var response = baseResponse.Data.ToObject<SaveProductVariantResponse>();
                    response.IsSuccess = true;
                    return response;
                }
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new SaveProductVariantResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new SaveProductVariantResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates or updates a shopify product metafield.
        /// </summary>
        /// <param name="request">SaveProductMetafieldRequest</param>
        /// <returns>SaveProductMetafieldResponse</returns>
        public SaveProductMetafieldResponse SaveProductMetafield(SaveProductMetafieldRequest request)
        {
            try
            {                
                var baseRequest = new SaveRecordRequest();

                if (request.ProductMetafield.Id == 0)
                {
                    baseRequest.ResourceType = ShopifyResourceType.products;
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.ExtendedUrl = "/" + request.ProductId + "/metafields";
                    var baseResponse = AddRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                    var response = baseResponse.Data.ToObject<SaveProductMetafieldResponse>();
                    response.IsSuccess = true;
                    return response;
                }
                else
                {
                    baseRequest.ResourceType = ShopifyResourceType.products;
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.ExtendedUrl = "/" + request.ProductId + "/metafields";
                    var baseResponse = UpdateRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                    var response = baseResponse.Data.ToObject<SaveProductMetafieldResponse>();
                    response.IsSuccess = true;
                    return response;
                }
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new SaveProductMetafieldResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new SaveProductMetafieldResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Deletes a shopify product.
        /// </summary>
        /// <param name="request">DeleteProductRequest</param>
        /// <returns>DeleteProductResponse</returns>
        public DeleteProductResponse DeleteProduct(DeleteProductRequest request)
        {
            try
            {
                
                var baseRequest = new DeleteRecordRequest();
                baseRequest.RecordId = request.ProductId;
                baseRequest.ResourceType = ShopifyResourceType.products;
                var baseResponse = DeleteRecord(baseRequest);
                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = new DeleteProductResponse();
                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new DeleteProductResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new DeleteProductResponse { ErrorMessage = ex.Message };
            }
        }
    }
}