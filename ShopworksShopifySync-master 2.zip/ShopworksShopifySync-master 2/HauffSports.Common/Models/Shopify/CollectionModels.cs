﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace HauffSports.Common.Models.Shopify
{
    public class CustomCollectionCreateModel
    {
        public CustomCollectionCreateModel()
        {
            this.Title = string.Empty;
        }

        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
    }

    public class CustomCollectionModel : BaseModel
    {
        public CustomCollectionModel()
        {
            this.Handle = string.Empty;
            this.Title = string.Empty;
            this.BodyHtml = string.Empty;
            this.SortOrder = string.Empty;
            this.TemplateSuffix = string.Empty;
            this.Image = string.Empty;
            this.PublishedScope = string.Empty;
            this.Published = false;
            this.PublishedAt = null;
        }

        public string Handle { get; set; }
        public string Title { get; set; }
        public string BodyHtml { get; set; }
        public string SortOrder { get; set; }
        public string TemplateSuffix { get; set; }
        public string Image { get; set; }
        public string PublishedScope { get; set; }
        public bool Published { get; set; }
        public DateTimeOffset? PublishedAt { get; set; }
    }

    public class CollectModel : BaseModel
    {
        public CollectModel()
        {
            this.CollectionId = 0;
            this.ProductId = 0;
            this.SortValue = string.Empty;
            this.Position = 0;
            this.Featured = false;
        }

        [JsonProperty(PropertyName = "collection_id")]
        public long CollectionId { get; set; }

        [JsonProperty(PropertyName = "product_id")]
        public long ProductId { get; set; }

        [JsonProperty(PropertyName = "sort_value")]
        public string SortValue { get; set; }

        [JsonProperty(PropertyName = "position")]
        public int Position { get; set; }

        [JsonProperty(PropertyName = "featured")]
        public bool Featured { get; set; }
    }

    public class SmartCollectionModel : BaseModel
    {
        public SmartCollectionModel()
        {
            this.Handle = null;
            this.Title = string.Empty;
            this.BodyHtml = string.Empty;
            this.SortOrder = null;
            this.TemplateSuffix = null;
            this.Disjunctive = false;
            this.Rules = new List<Rule>();
            this.PublishedScope = "web";
        }

        public class Rule
        {
            [JsonProperty(PropertyName = "column")]
            public string Column { get; set; }

            [JsonProperty(PropertyName = "relation")]
            public string Relation { get; set; }

            [JsonProperty(PropertyName = "condition")]
            public string Condition { get; set; }
        }

        [JsonProperty(PropertyName = "handle", NullValueHandling = NullValueHandling.Ignore)]
        public string Handle { get; set; }

        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }

        [JsonProperty(PropertyName = "body_html")]
        public string BodyHtml { get; set; }

        [JsonProperty(PropertyName = "sort_order", NullValueHandling = NullValueHandling.Ignore)]
        public string SortOrder { get; set; }

        [JsonProperty(PropertyName = "template_suffix", NullValueHandling = NullValueHandling.Ignore)]
        public string TemplateSuffix { get; set; }
        
        [JsonProperty(PropertyName = "disjunctive")]
        public bool Disjunctive { get; set; }

        [JsonProperty(PropertyName = "rules")]
        public List<Rule> Rules { get; set; }

        [JsonProperty(PropertyName = "published_scope", NullValueHandling = NullValueHandling.Ignore)]
        public string PublishedScope { get; set; }
    }
}
 