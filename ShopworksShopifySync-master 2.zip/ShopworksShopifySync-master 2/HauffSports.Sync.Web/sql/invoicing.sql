﻿with orders as (
    select 
        o.*,
        o.Id as OrderId,
        case 
            when e.NameFull is not null then
                case
                    when dbo.ValidateEmail(e.EmailAddress, null) is not null then e.NameFull + ' <' + dbo.ValidateEmail(e.EmailAddress, null) + '>'
                    else null
                end
            else dbo.ValidateEmail(e.EmailAddress, null) 
        end as SalesRepEmailFull,
        case 
            when o.ContactFirst is not null or o.ContactLast is not null then
                case
                    when dbo.ValidateEmail(o.ContactEmail, null) is not null then ltrim(rtrim(coalesce(o.ContactFirst, '') + ' ' + coalesce(o.ContactLast, ''))) + ' <' + dbo.ValidateEmail(o.ContactEmail, null) + '>'
                    else null
                end
            else dbo.ValidateEmail(o.ContactEmail, null) 
        end as ContactEmailFull
	from shopworks.[Order] o        
    left join shopworks.Employee e on
        e.NameFull = o.CustomerServiceRep and
        e.EmailAddress is not null
    left join shopworks.Customer c on
        c.Id = o.CustomerId
	where 
		o.InvoicedStatus = '1' and
		o.PaidStatus in ('0', '0.5') and
        coalesce(o.SalesStatusId, '') != '9' and -- 'No'
        coalesce(c.CustomField02, '') != 'No' and
        coalesce(o.Balance, 0) > 10
),
invoice_reminder_30_days as (
	select 
        OrderId,
        coalesce(ContactEmailFull, SalesRepEmailFull) as Email,
        '' as Bcc,
        'Invoice-Reminder-30-Days' as EventType,
        UpdatedAt as OrderUpdatedAt
	from orders
	where 
		InvoicedAt < dateadd(day, -45, dbo.getcstdate()) and
		InvoicedAt >= dateadd(day, -60, dbo.getcstdate())
),
invoice_reminder_60_days as (
	select
        OrderId,
        coalesce(ContactEmailFull, SalesRepEmailFull) as Email,
        '' as Bcc,
        'Invoice-Reminder-60-Days' as EventType,
        UpdatedAt as OrderUpdatedAt
	from orders
	where 
		InvoicedAt < dateadd(day, -60, dbo.getcstdate()) and
		InvoicedAt >= dateadd(day, -90, dbo.getcstdate())
),
invoice_reminder_80_days as (
	select
        OrderId,
        coalesce(ContactEmailFull, SalesRepEmailFull) as Email,
        SalesRepEmailFull as Bcc,
        'Invoice-Reminder-80-Days' as EventType,
        UpdatedAt as OrderUpdatedAt
	from orders
	where 
		InvoicedAt < dateadd(day, -90, dbo.getcstdate()) and
		InvoicedAt >= dateadd(day, -110, dbo.getcstdate())
),
invoice_reminder_120_days as (
	select
        OrderId,
        coalesce(ContactEmailFull, SalesRepEmailFull) as Email,
        concat(SalesRepEmailFull, ',', 'Curt Hauff <curt@dakotalettering.com>') as Bcc,
        'Invoice-Reminder-120-Days' as EventType,
        UpdatedAt as OrderUpdatedAt
	from orders
	where 
		InvoicedAt < dateadd(day, -110, dbo.getcstdate()) and
		InvoicedAt >= dateadd(day, -150, dbo.getcstdate())
)
insert into dbo.OrderNotification(OrderId, EventType, Email, Bcc, OrderUpdatedAt, CreatedAt, UpdatedAt)
(
    select OrderId, 
        EventType, 
        Email, 
        Bcc, 
        OrderUpdatedAt, 
        dbo.getcstdate() as CreatedAt, 
        dbo.getcstdate() as UpdatedAt
    from (
              select * from invoice_reminder_30_days
        union select * from invoice_reminder_60_days
        union select * from invoice_reminder_80_days
        union select * from invoice_reminder_120_days
    ) as new
    where not exists (
        select 1 
        from dbo.OrderNotification as o 
        where o.OrderId = new.OrderId and o.EventType = new.EventType
    )
);
