﻿using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;
using HauffSports.Common.Clients.ManageOrders;

namespace HauffSports.Sync.Mailman
{
    public partial class MailSync
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly AppSettings _settings;

        public MailSync(AppSettings settings)
        {
            this._settings = settings;

            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateCertificate);
        }
        
        static bool ValidateCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }

        private class Notification
        {
            public string Id { get; set; }
            public string Email { get; set; }
            public string Bcc { get; set; }
            public string EventType { get; set; }
            public string OrderId { get; set; }
        }

        private string ValidateString(object input)
        {
            if (input != DBNull.Value)
            {
                try
                {
                    return Convert.ToString(input);
                }
                catch
                {

                }
            }

            return null;
        }

        private MailAddress GetMailAddress(string email)
        {
            string pat = @"(.*) <(.*)>";

            // Instantiate the regular expression object.
            var r = new Regex(pat, RegexOptions.IgnoreCase);

            // Match the regular expression pattern against a text string.
            Match m = r.Match(email);

            if (m.Success)
            {
                return new MailAddress(m.Groups[2].Captures[0].Value.Trim(), m.Groups[1].Captures[0].Value.Trim());
            }

            return new MailAddress(email.Trim());
        }

        private string FillTemplate(string template, Dictionary<string, string> variables)
        {
            return new Regex(@"({{([a-zA-Z]+)}})")
                .Replace(
                    template, 
                    new MatchEvaluator(m => variables.GetValueOrDefault(m.Groups[2].Value, "")));
        }

        private void SyncMail()
        {
            var templates = new[] {
                new
                {
                    Name = "Confirmation",
                    Subject = "Order Confirmation #{{OrderId}}",
                    Body =  File.ReadAllText("templates/confirmation.html")
                },
                new
                {
                    Name = "Completion-Other",
                    Subject = "Order Ready (No Ship Method) #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-other.html"),
                },
                new
                {
                    Name = "Completion-Ready-To-Ship",
                    Subject = "Order Ready For Shipping #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-ready-to-ship.html"),
                },
                new
                {
                    Name = "Completion-Shipped",
                    Subject = "Order Shipped #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-shipped.html"),
                },
                new
                {
                    Name = "Completion-Wholesale-Pickup",
                    Subject = "Order Ready for Pickup #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-wholesale-pickup.html")
                },
                new
                {
                    Name = "Completion-Pickup",
                    Subject = "Order Ready for Pickup #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-pickup.html")
                },
                new
                {
                    Name = "Completion-Pickup-7-Days",
                    Subject = "Order Ready for Pickup #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-pickup-07.html")
                },
                new
                {
                    Name = "Completion-Pickup-14-Days",
                    Subject = "Order Ready for Pickup #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-pickup-14.html")
                },
                new
                {
                    Name = "Completion-Pickup-21-Days",
                    Subject = "FINAL NOTICE: Order Ready for Pickup #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-pickup-21.html")
                },
                new
                {
                    Name = "Completion-Delivery",
                    Subject = "Order Ready for Delivery #{{OrderId}}",
                    Body = File.ReadAllText("templates/completion-delivery.html")
                },
                new
                {
                    Name = "Completion-Delivery-7-Days",
                    Subject = "Order Ready for Delivery #{{OrderId}} (7 Day Reminder)",
                    Body = File.ReadAllText("templates/completion-delivery.html")
                },
                new
                {
                    Name = "Completion-Delivery-14-Days",
                    Subject = "Order Ready for Delivery #{{OrderId}} (14 Day Reminder)",
                    Body = File.ReadAllText("templates/completion-delivery.html")
                },
                new
                {
                    Name = "Completion-Delivery-21-Days",
                    Subject = "Order Ready for Delivery #{{OrderId}} (Final Reminder)",
                    Body = File.ReadAllText("templates/completion-delivery.html")
                },
                new
                {
                    Name = "Invoice-Reminder-30-Days",
                    Subject = "Invoice Reminder #{{OrderId}}",
                    Body = File.ReadAllText("templates/invoice-reminder-30.html")
                },
                new
                {
                    Name = "Invoice-Reminder-60-Days",
                    Subject = "Invoice Reminder #{{OrderId}}",
                    Body = File.ReadAllText("templates/invoice-reminder-60.html")
                },
                new
                {
                    Name = "Invoice-Reminder-80-Days",
                    Subject = "Invoice Reminder #{{OrderId}}",
                    Body = File.ReadAllText("templates/invoice-reminder-80.html")
                },
                new
                {
                    Name = "Invoice-Reminder-120-Days",
                    Subject = "Invoice Reminder #{{OrderId}}",
                    Body = File.ReadAllText("templates/invoice-reminder-120.html")
                }
            };

            var renderPath = Directory.CreateDirectory(_settings.General.RenderPath).FullName;

            var smtpClient = new SmtpClient(_settings.Email.Server)
            {
                Port = _settings.Email.Port,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(_settings.Email.Address, _settings.Email.Password),
                EnableSsl = _settings.Email.EnableSsl,
                Timeout = 20000
            };

            var manageOrdersClient = new ManageOrdersClient(_settings.ManageOrders.UserName, _settings.ManageOrders.Password);

            var from = new MailAddress(_settings.Email.Address, _settings.Email.DisplayName);
            var notifications = new List<Dictionary<string, string>>();

            // get list of notifications from the database
            using (var conn = new SqlConnection(_settings.General.Website))
            {
                conn.Open();

                var emailsQuery = File.ReadAllText(@"sql\emails.sql");
                var emailsCmd = new SqlCommand(emailsQuery, conn);
                emailsCmd.Parameters.Add(new SqlParameter("@hours", -_settings.General.LookbackHours));
                emailsCmd.CommandTimeout = 0;

                using (var reader = emailsCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var variables = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; ++i)
                        {
                            variables.Add(reader.GetName(i), ValidateString(reader.GetValue(i)));
                        }
                        notifications.Add(variables);
                    }
                }
            }

            Log.Info($"Found {notifications.Count} notifications");

            var skips = new HashSet<string>();

            foreach (var notification in notifications)
            {
                var id = notification["Id"];
                var eventType = notification["EventType"];
                var email = notification["Email"];
                var bcc = notification["Bcc"];
                var orderId = notification["OrderId"];

                var eventFilter = new Regex(_settings.General.EventFilter);

                if (!eventFilter.IsMatch(eventType))
                {
                    skips.Add(eventType);
                    continue;
                }

                var emailFilter = new Regex(_settings.General.EmailFilter);
                var subjectMessage = "";

                if (string.IsNullOrEmpty(email))
                {
                    email = _settings.General.AdminAddress;
                    subjectMessage += " (no email address)";
                } 
                else if (!emailFilter.IsMatch(email))
                {
                    skips.Add(email);
                    continue;
                }

                var template = templates.Where(t => t.Name == eventType).FirstOrDefault();

                if (template == null)
                {
                    skips.Add("Event-Unknown");
                    continue;
                }

                MailMessage msg = null;

                try
                {
                    
                    var toAddress = GetMailAddress(email);

                    if (!string.IsNullOrEmpty(_settings.General.DebugAddress))
                    {
                        var debugAddress = GetMailAddress(_settings.General.DebugAddress);
                        Log.Info($"Sending {eventType} notification to {email} ({_settings.General.DebugAddress})");
                        msg = new MailMessage(from, debugAddress);
                        subjectMessage += " (debug)";
                    }
                    else
                    {
                        Log.Info($"Sending {eventType} notification to {email}");
                        msg = new MailMessage(from, toAddress);

                        if (!string.IsNullOrEmpty(bcc))
                        {
                            msg.Bcc.Add(GetMailAddress(bcc));
                        }
                    }
                }
                catch (FormatException )
                {
                    Log.Error($"Could not parse address: {email} {bcc}");
                    skips.Add(email);
                    continue;
                }

                notification.Add("OrderLink", "https://manageorders.com/#/access/signin");

                var orderInfo = manageOrdersClient.GetOrder(orderId);

                if (orderInfo != null && orderInfo["status"].ToString() == "success" && orderInfo["result"].Count() > 0)
                {
                    notification["OrderLink"] = $"https://manageorders.com/#/order/detail/{orderInfo["result"][0]["id_URL"].ToString()}";
                }
                
                if (_settings.General.EnableRender)
                {
                    var debugNotification = new Dictionary<string, string>(notification);
                    debugNotification.Add("DEBUGHEADER", $"<table>" +
                        $"<tr><td>From:</td><td>{msg.From.DisplayName} &lt;{msg.From.Address}&gt;</td></tr>" +
                        $"<tr><td>To:</td><td>{WebUtility.HtmlEncode(email)}</td></tr>" +
                        $"<tr><td>Bcc:</td><td>{WebUtility.HtmlEncode(bcc)}</td></tr>" +
                        $"<tr><td>Subject:</td><td>{FillTemplate(template.Subject, notification)}</td></tr>" +
                        $"</table>");
                    var renderFileName = Path.Combine(renderPath, $"{id}_{orderId}_{eventType}.html");
                    File.WriteAllText(renderFileName, FillTemplate(template.Body, debugNotification));
                }

                msg.Subject = FillTemplate(template.Subject, notification);
                msg.Body = FillTemplate(template.Body, notification);
                msg.IsBodyHtml = true;
                msg.ReplyToList.Add(from);
                msg.Sender = from;
                msg.Priority = MailPriority.Normal;

                try
                {
                    if (_settings.General.EnableSend)
                    {
                        smtpClient.Send(msg);
                    }

                    if (_settings.General.WriteSentFlag)
                    {
                        // set this notification as sent
                        using (var conn = new SqlConnection(_settings.General.Website))
                        {
                            conn.Open();

                            var updateCmd = new SqlCommand(@"
                                                    update dbo.OrderNotification
                                                    set SentAt = dbo.getcstdate()
                                                    where id = @id
                                                ", conn);
                            updateCmd.Parameters.Add(new SqlParameter("@id", id));
                            updateCmd.CommandTimeout = 0;
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error($"Error sending email: {ex}");
                }
            }

            if (skips.Count > 0)
            {
                Log.Info($"Skipped [ {string.Join(", ", skips)} ] notifications");
            }
        }

        public int Sync(ManualResetEvent stopRequest = null)
        {
            try
            {
                Log.Info("Mailman Starting");

                SyncMail();

                Log.Info("Mailman Ended");
            }
            catch (Exception ex)
            {
                Log.Fatal(ex.Message, ex);
                return -1;
            }

            return 0;
        }
    }
}
