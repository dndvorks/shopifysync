﻿// *https://www.registers.service.gov.uk/registers/country/use-the-api*
import fetch from 'cross-fetch';
import * as React from 'react';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CircularProgress from '@material-ui/core/CircularProgress';

interface AutoCompleteProps {
    label: string;
}

const AutoComplete: React.FC<AutoCompleteProps> = ({ label }) => {
    const [options, setOptions] = React.useState([]);
    const [loading, setLoading] = React.useState(false);

    return (
        <Autocomplete
            style={{ width: 300 }}
            getOptionSelected={(option, value) => option.name === value.name}
            getOptionLabel={(option) => option.name}
            options={options}
            loading={loading}
            onInputChange={async (event, value) => {
                setLoading(true);
                const response = await fetch(`api/Shopworks/Vendors?q=${value}`);
                const results = await response.json();
                console.log(results);
                //setOptions(Object.keys(countries).map((key) => countries[key].item[0]));
                setLoading(false);
            }}
            renderInput={(params) => (
                <TextField
                    {...params}
                    label={ label }
                    variant="outlined"
                    InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                            <React.Fragment>
                                {loading ? <CircularProgress color="inherit" size={20} /> : null}
                                {params.InputProps.endAdornment}
                            </React.Fragment>
                        ),
                    }}
                />
            )}
        />
    );
}

export default AutoComplete