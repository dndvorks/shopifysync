﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Customer", Schema = "shopworks")]
    public class Customer : BaseShopworks
    {
        public string CompanyName { get; set; }
        public string EmailMain { get; set; }
        public string PhoneMain { get; set; }
        public string FaxMain { get; set; }

        public string CustomField01 { get; set; }
        public string CustomField02 { get; set; }
        public string CustomField03 { get; set; }

        [ForeignKey("Active")]
        public string ActiveStatus { get; set; }
        public Status Active { get; set; }

        public List<Contact> Contacts { get; set; }
        public List<Address> Addresses { get; set; }
        public List<Order> Orders { get; set; }
    }
}
