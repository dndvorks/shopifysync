﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace HauffSports.UI.Website.Models
{
    [NotMapped]
    public static class Util
    {
        public static int GetInt(string val)
        {
            int result;
            if (int.TryParse(val, out result))
            {
                return result;
            }
            return 0;
        }

        public static int? GetIntOrNull(string val)
        {
            int result;
            if (int.TryParse(val, out result))
            {
                return result;
            }
            return null;
        }

        public static decimal GetDecimal(string val)
        {
            decimal result;
            if (decimal.TryParse(val, out result))
            {
                return result;
            }
            return 0;
        }
    }

    public class SalesOrder
    {
        public SalesOrder() { }

        public SalesOrder(IFormCollection collection)
        {
            Id = int.Parse(collection["salesOrderId"]);

            SalesRep = collection["salesRep"];
            SalesRepLocation = int.Parse(collection["salesRepLocation"]);
            SalesRepEmail = collection["salesRepEmail"];

            CustomerId = int.Parse(collection["customerId"]);
            CustomerCompanyName = collection["customerCompanyName"];
            CustomerFirstName = collection["customerFirstName"];
            CustomerLastName = collection["customerLastName"];
            CustomerEmail = collection["customerEmail"];
            CustomerPhone = collection["customerPhone"];
            CustomerPurchaseOrder = collection["customerPurchaseOrder"];

            CreateContact = collection["createContact"] == "on";
            ContactId = Util.GetIntOrNull(collection["contactId"]);

            OrderType = int.Parse(collection["orderType"]);
            OrderDate = collection["orderDate"];

            ShippingMethod = collection["shippingMethod"];
            RequestedShippingDate = collection["requestedShippingDate"];
            DropDeadDate = collection["dropDeadDate"];

            NotesToProduction = collection["notesToProduction"];
            NotesToReceiving = collection["notesToReceiving"];
            NotesToPurchasing = collection["notesToPurchasing"];
            NotesToShipping = collection["notesToShipping"];
            NotesToAccounting = collection["notesToAccounting"];

            Shipping = collection["orderShipping"];

            Products = collection.Keys
                .Where(k => k.StartsWith("product_"))
                .Select(k => k.Replace("product_", "")
                .Split("_")[0])
                .Distinct()
                .Select(id => new SalesOrderProduct()
                {
                    Id = int.Parse(collection[string.Format("product_{0}_id", id)]),
                    IsCustom = collection[string.Format("product_{0}_custom", id)] == "on",
                    PartNumber = collection[string.Format("product_{0}_partNumber", id)],
                    PartDescription = collection[string.Format("product_{0}_partDescription", id)],
                    ProductClassId = collection[string.Format("product_{0}_productClassId", id)],
                    Cost = collection[string.Format("product_{0}_cost", id)],
                    AdjustedCost = collection[string.Format("product_{0}_adjustedCost", id)],
                    Price = collection[string.Format("product_{0}_price", id)],
                    AdjustedPrice = collection[string.Format("product_{0}_adjustedPrice", id)],
                    Color = collection[string.Format("product_{0}_color", id)],
                    ColorOther = collection[string.Format("product_{0}_colorOther", id)],
                    Size01 = collection[string.Format("product_{0}_size01", id)],
                    Size02 = collection[string.Format("product_{0}_size02", id)],
                    Size03 = collection[string.Format("product_{0}_size03", id)],
                    Size04 = collection[string.Format("product_{0}_size04", id)],
                    Size05 = collection[string.Format("product_{0}_size05", id)],
                    Size06 = collection[string.Format("product_{0}_size06", id)],
                }).ToList();

            Logos = collection.Keys
                .Where(k => k.StartsWith("logo_"))
                .Select(k => k.Replace("logo_", "")
                .Split("_")[0])
                .Distinct()
                .Select(id => new SalesOrderLogoLocation()
                {
                    Id = int.Parse(collection[string.Format("logo_{0}_id", id)]),
                    Location = collection[string.Format("logo_{0}_location", id)],
                    Colors = collection[string.Format("logo_{0}_colors", id)],
                    Size = collection[string.Format("logo_{0}_size", id)],
                    DesignThumbnailId = Util.GetIntOrNull(collection[string.Format("logo_{0}_designThumbnail", id)]),
                    DesignId = Util.GetIntOrNull(collection[string.Format("logo_{0}_design", id)]),
                    NotesToArt = collection[string.Format("logo_{0}_notesToArt", id)],
                    Files = collection.Keys
                        .Where(k => k.StartsWith(string.Format("logo_{0}_file_", id)))
                        .Select(k => k.Replace(string.Format("logo_{0}_file_", id), "")
                        .Split("_")[0])
                        .Distinct()
                        .Select(fileId => new SalesOrderFile()
                        {
                            Id = int.Parse(collection[string.Format("logo_{0}_file_{1}_id", id, fileId)]),
                            FileId = collection[string.Format("logo_{0}_file_{1}_file_id", id, fileId)]
                        }).ToList()
                }).ToList();
        }

        public int Id { get; set; }

        public string SalesRep { get; set; }
        public int SalesRepLocation { get; set; }
        public string SalesRepEmail { get; set; }

        public int CustomerId { get; set; }
        public string CustomerCompanyName { get; set; }
        public string CustomerFirstName { get; set; }
        public string CustomerLastName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerPurchaseOrder { get; set; }
        public bool CreateContact { get; set; }

        public int? ContactId { get; set; }
        
        public int OrderType { get; set; }
        public string OrderDate { get; set; }
        
        public string ShippingMethod { get; set; }
        public string RequestedShippingDate { get; set; }
        public string DropDeadDate { get; set; }

        public string NotesToProduction { get; set; }
        public string NotesToReceiving { get; set; }
        public string NotesToPurchasing { get; set; }
        public string NotesToShipping { get; set; }
        public string NotesToAccounting { get; set; }

        public string Shipping { get; set; }

        public List<SalesOrderProduct> Products { get; set; }
        public List<SalesOrderLogoLocation> Logos { get; set; }

        [NotMapped]
        public int Quantity
        {
            get
            {
                return Products.Sum(p => p.Quantity);
            }
        }

        [NotMapped]
        public decimal SubtotalPrice
        {
            get
            {
                return Products.Sum(p => p.TotalPrice);
            }
        }

        [NotMapped]
        public decimal TotalPrice
        {
            get
            {
                return SubtotalPrice + Util.GetDecimal(Shipping);
            }
        }

        public DateTime? SentAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public DateTime? DeletedAt { get; set; }
    }

    public class SalesOrderProduct
    {
        public int Id { get; set; }
        public bool IsCustom { get; set; }
        public string PartNumber { get; set; }
        public string PartDescription { get; set; }
        public string ProductClassId { get; set; }
        public string Cost { get; set; }
        public string AdjustedCost { get; set; }
        public string Price { get; set; }
        public string AdjustedPrice { get; set; }
        public string Color { get; set; }
        public string ColorOther { get; set; }
        public string Size01 { get; set; }
        public string Size02 { get; set; }
        public string Size03 { get; set; }
        public string Size04 { get; set; }
        public string Size05 { get; set; }
        public string Size06 { get; set; }

        [NotMapped]
        public int Quantity
        {
            get
            {
                return Util.GetInt(Size01) + Util.GetInt(Size02) + Util.GetInt(Size03) +
                    Util.GetInt(Size04) + Util.GetInt(Size05) + Util.GetInt(Size06);
            }
        }

        [NotMapped]
        public decimal TotalPrice
        {
            get
            {
                return Quantity * Util.GetDecimal(AdjustedPrice);
            }
        }
    }

    public class SalesOrderLogoLocation
    {
        public int Id { get; set; }
        public string Location { get; set; }
        public string Colors { get; set; }
        public string Size { get; set; }
        public string NotesToArt { get; set; }

        public int? DesignThumbnailId { get; set; }
        public int? DesignId { get; set; }

        public List<SalesOrderFile> Files { get; set; }
    }

    public class SalesOrderFile
    {
        public int Id { get; set; }
        public string FileId { get; set; }
        public File File { get; set; }
    }
}
