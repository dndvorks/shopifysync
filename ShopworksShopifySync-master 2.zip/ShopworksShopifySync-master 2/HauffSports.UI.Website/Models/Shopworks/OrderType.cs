﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("OrderType", Schema = "shopworks")]
    public class OrderType : BaseShopworks
    {
        public string Name { get; set; }
    }
}
