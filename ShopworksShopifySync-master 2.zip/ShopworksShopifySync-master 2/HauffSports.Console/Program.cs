﻿using System;
using System.IO;
using System.Windows.Forms;
using log4net.Config;
using Microsoft.Extensions.Configuration;

namespace HauffSports.Console
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            XmlConfigurator.Configure(new FileInfo("log4net.config"));

            var builder = new ConfigurationBuilder()
                .AddJsonFile($"appsettings.json", true, true);

            var settings = builder.Build().Get(typeof(AppSettings)) as AppSettings;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ShopifyTool(settings));
        }
    }
}
