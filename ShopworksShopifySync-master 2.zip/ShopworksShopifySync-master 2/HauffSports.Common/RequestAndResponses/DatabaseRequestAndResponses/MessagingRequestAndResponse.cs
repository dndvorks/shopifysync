﻿using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.DatabaseRequestAndResponses
{
    public class SendEmailRequest : BaseRequest
    {
        public SendEmailRequest()
        {
            this.Subject = string.Empty;
            this.Body = string.Empty;
        }

        public string Subject { get; set; }
        public string Body { get; set; }

    }

    public class SendEmailResponse : BaseResponse { }
}