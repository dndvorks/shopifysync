﻿using log4net;
using System;
using System.Linq;
using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses;
using HauffSports.Common.Clients.Shopify;
using HauffSports.Common.Clients.ShopWorks;
using System.Threading;
using System.Collections.Generic;

namespace HauffSports.Common.Services
{
    public class CustomerService : BaseService
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private ShopWorksCustomerClient _shopWorksCustomerService { get; set; }
        private ShopifyCustomerClient _shopifyCustomerService { get; set; }

        public CustomerService(
            string shopworksConnectionString,
            string shopifyPublicKey,
            string shopifySecretKey,
            string shopifyUrl) : base()
        {
            this._shopWorksCustomerService = new ShopWorksCustomerClient(shopworksConnectionString);
            this._shopifyCustomerService = new ShopifyCustomerClient(shopifyPublicKey, shopifySecretKey, shopifyUrl);
        }

        public void SyncCustomers(ManualResetEvent stopRequest)
        {
            log.Info("Getting customers from shopify");
            var existingCustomersResponse = this._shopifyCustomerService.GetCustomers(new GetRecordsRequest() { ResourceType = Enums.ShopifyResourceType.customers });

            if (!existingCustomersResponse.IsSuccess)
                throw new ApplicationException("[Get Customers Error: " + existingCustomersResponse.ErrorMessage + "]");

            log.Info("Got " + existingCustomersResponse.Customers.Count + " customers from shopify");
            
            log.Info("Getting customers from shopworks");
            var response = this._shopWorksCustomerService.GetCustomers(new GetCustomersRequest());

            if (!response.IsSuccess)
                throw new ApplicationException("[Get Customers Error: " + response.ErrorMessage + "]");
            
            var customers = response.Customers.GroupBy(x => x.Email, (key, group) => group.First(), StringComparer.CurrentCultureIgnoreCase).ToList();

            log.Info("Got " + customers.Count + " unique customers from shopworks");

            var customersToUpdate = new List<CustomerCreateModel>();
            foreach (var customer in customers)
            {
                if (UpdateCustomer(customer, existingCustomersResponse.Customers))
                {
                    customersToUpdate.Add(customer);
                }
            }
            
            log.Info("Adding / updating " + customersToUpdate.Count + " customers from shopworks");
            foreach (var customer in customersToUpdate)
            {
                if (stopRequest.WaitOne(0))
                {
                    log.Warn("Stop Requested");
                    return;
                }

                DoUpdateCustomer(customer);
            }

            log.Info("Finished Getting customers from shopworks");
        }

        private bool UpdateCustomer(CustomerCreateModel customer, List<CustomerModel> existingCustomers)
        {
            try
            {
                if (string.IsNullOrEmpty(customer.Email.Trim()))
                    return false;
                if (!customer.Email.Contains("@"))
                    return false;

                var getCustomerRequest = new GetRecordByQueryRequest { };

                if (string.IsNullOrEmpty(customer.Email))
                {
                    throw new ApplicationException("Customer email does not exist");
                }
                else
                {
                    var existingCustomer = existingCustomers.Where(c => c.Email.Equals(customer.Email, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                    var updateCustomer = true;

                    if (existingCustomer != null)
                    {
                        customer.Id = existingCustomer.Id;

                        updateCustomer =
                            customer.FirstName != existingCustomer.FirstName ||
                            customer.LastName != existingCustomer.LastName;
                    }

                    return updateCustomer;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.ToString());
                return false;
            }
        }
   
        private bool DoUpdateCustomer(CustomerCreateModel customer)
        {
            try
            { 
                customer.SendEmailInvite = false;
                var response = _shopifyCustomerService.SaveCustomer(new SaveCustomerRequest { Customer = customer });
                if (!response.IsSuccess)
                {
                    log.ErrorFormat("Error Saving Customer [Email: {0}, Error: {1}]", customer.Email, response.ErrorMessage);
                    Thread.Sleep(500);
                    return false;
                }
                else
                {
                    log.InfoFormat("Saved Customer [Email: {0}]", customer.Email);
                    customer.Id = response.Customer.Id;
                    foreach (var metafield in customer.Metafields)
                    {
                        var metaRequest = new SaveCustomerMetafieldRequest { CustomerId = customer.Id, CustomerMetafield = metafield };
                        var metaResponse = _shopifyCustomerService.SaveCustomerMetafield(metaRequest);
                        if (metaResponse.IsSuccess)
                        {
                            log.InfoFormat("Saved Metafield [Key: {0}, Value: {1}]", metafield.Key, metafield.Value);
                        }
                        else
                        {
                            log.ErrorFormat("Error Saving Metafield [Key: {0}, Value: {1}, Error: {2}]", metafield.Key, metafield.Value, metaResponse.ErrorMessage);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Error Saving Customer [Email: {0}, Error: {1}]", customer.Email, ex.Message);
                return false;
            }

            return true;
        }
    }
}
