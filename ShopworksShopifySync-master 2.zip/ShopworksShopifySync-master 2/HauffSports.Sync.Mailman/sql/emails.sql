﻿with input as (
    select dateadd(hour, @hours, dbo.getcstdate()) as LookbackDate
)
select
    n.Id, 
    n.OrderId, 
    n.Email,
    n.Bcc,
    n.EventType,
    ltrim(rtrim(coalesce(o.CompanyName, 'our customer'))) as CompanyName, 
    ltrim(rtrim(coalesce(l.LocationName, ''))) as LocationName,
    ltrim(rtrim(coalesce(o.ContactFirst, ''))) as ContactFirst,
    ltrim(rtrim(coalesce(o.ContactLast, ''))) as ContactLast,
    ltrim(rtrim(coalesce(o.CustomerServiceRep, 'Customer Service'))) as CustomerServiceRep,
    ltrim(rtrim(coalesce(e.EmailAddress, 'customerservice@hauffsports.com'))) as CustomerServiceRepEmail,
    ltrim(rtrim(coalesce(d.DesignName, ''))) as DesignName,
    case
        when p.TrackingNumber is not null then
            case
                when o.ShippingStatusId = '20' or p.TrackingNumber like '1Z________________'
                    then '<a href="https://www.ups.com/track?tracknum=' + p.TrackingNumber + '">' + p.TrackingNumber + '</a>'
                when o.ShippingStatusId = '21' or  p.TrackingNumber like '9_____________________'
                    then '<a href="https://tools.usps.com/go/TrackConfirmAction?tLabels=' + p.TrackingNumber + '">' + p.TrackingNumber + '</a>'
                when o.ShippingStatusId = '22' 
                    then '<a href="https://www.fdex.com/fedextrack/?trknbr=' + p.TrackingNumber + '">' + p.TrackingNumber + '</a>'
                when o.ShippingStatusId = '23' or p.TrackingNumber like 'SP__________________'
                    then '<a href="https://speedeedelivery.com/track-a-shipment/?barcode=' + p.TrackingNumber + '">' + p.TrackingNumber + '</a>'
                when o.ShippingStatusId = '24' 
                    then '<a href="https://rudeweb.roadvision.com/' + '">RUDE Tracking</a>'
                else p.TrackingNumber
            end
        else '(tracking not available)'
    end as TrackingLink
from input, [dbo].[OrderNotification] n 
join [shopworks].[Order] o on
    o.Id = n.OrderId
join [shopworks].[Location] l on
    l.Id = o.LocationId
join [shopworks].[Employee] e on
    o.CustomerServiceRep = e.NameFull
left join [shopworks].[PackImport] p on
    p.OrderId = n.OrderId
outer apply (select top 1 * from [shopworks].[OrderDesign] where OrderId = n.OrderId) od
left join [shopworks].[Design] d on
    d.Id = od.DesignId
where 
    n.SentAt is null and 
    n.CreatedAt >= input.LookbackDate
