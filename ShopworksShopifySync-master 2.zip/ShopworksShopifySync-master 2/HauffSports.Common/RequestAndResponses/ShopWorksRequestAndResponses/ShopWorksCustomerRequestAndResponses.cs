﻿using HauffSports.Common.Models.Shopify;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses
{
    public class GetCustomersRequest : ShopWorksBaseRequest { }

    public class GetCustomersResponse : ShopWorksBaseResponse
    {
        public GetCustomersResponse()
        {
            this.Customers = new List<CustomerCreateModel>();
        }

        public List<CustomerCreateModel> Customers { get; set; }
    }
}