﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("InventoryTransaction", Schema = "shopworks")]
    public class InventoryTransaction : BaseShopworks
    {
        public string PartNumber { get; set; }
        public string PartColorRange { get; set; }
        public string PartColor { get; set; }
        public string PartDescription { get; set; }

        public string OrderId { get; set; }
        public string OrderLineId { get; set; }
        public string PurchaseOrderId { get; set; }
        public string PurchaseOrderLineId { get; set; }

        public int? Size01 { get; set; }
        public int? Size01_Rem { get; set; }

        public int? Size02 { get; set; }
        public int? Size02_Rem { get; set; }

        public int? Size03 { get; set; }
        public int? Size03_Rem { get; set; }

        public int? Size04 { get; set; }
        public int? Size04_Rem { get; set; }

        public int? Size05 { get; set; }
        public int? Size05_Rem { get; set; }

        public int? Size06 { get; set; }
        public int? Size06_Rem { get; set; }
    }
}
