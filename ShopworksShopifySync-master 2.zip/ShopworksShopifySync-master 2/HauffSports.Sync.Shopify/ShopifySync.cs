﻿using log4net;
using HauffSports.Common.Services;
using System;
using System.Threading;

namespace HauffSports.Sync.Shopify
{
    public partial class ShopifySync
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly ProductService _productService;
        private readonly ShopifySettings _settings;

        public ShopifySync(
            string shopworksConnectionString,
            string onSiteImagesPath,
            ShopifySettings shopifySettings)
        {
            _settings = shopifySettings;
            _productService = new ProductService(
                    shopworksConnectionString, 
                    onSiteImagesPath, 
                    shopifySettings.UseAlternatePrice, 
                    shopifySettings.PublicKey, 
                    shopifySettings.SecretKey, 
                    shopifySettings.Url);
        }

        public void Sync(ManualResetEvent stopRequest = null)
        {
            try
            {
                Log.Info($"Product Sync {_settings.Name} Starting");

                _productService.SyncProducts(stopRequest);

                Log.Info($"Product Sync {_settings.Name} Ended");
            }
            catch (Exception ex)
            {
                Log.Fatal(ex.Message, ex);
                throw;
            }
        }
    }
}
