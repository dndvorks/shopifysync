﻿namespace HauffSports.Common.Enums
{
    public enum ShopifyResourceType
    {
        unknown,
        collects,
        custom_collections,
        customers,
        gift_cards,
        metafields,
        order,
        orders,
        products,
        transactions,
        users,
        variants,
        webhooks,
        locations,
        inventory_levels,
        smart_collections
    }
}