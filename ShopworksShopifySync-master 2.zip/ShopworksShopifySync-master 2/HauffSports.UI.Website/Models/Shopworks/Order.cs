﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Order", Schema ="shopworks")]
    public class Order : BaseShopworks
    {
        public string CustomerId { get; set; }
        public Customer Customer { get; set; }

        public string ContactId { get; set; }
        public Contact Contact { get; set; }
        
        public string OrderTypeId { get; set; }
        public OrderType OrderType { get; set; }

        public string LocationId { get; set; }
        public Location Location { get; set; }

        public string ShippingStatusId { get; set; }
        public ShippingStatus ShippingStatus { get; set; }

        public string SalesStatusId { get; set; }

        public string CustomerServiceRep { get; set; }

        public string CompanyName { get; set; }

        public string ContactFirst { get; set; }
        public string ContactLast { get; set; }
        public string ContactEmail { get; set; }

        public DateTime? PlacedAt { get; set; }
        public DateTime? ShipRequestedAt { get; set; }
        public DateTime? DropDeadAt { get; set; }
        public DateTime? InvoicedAt { get; set; }

        public string TermsDays { get; set; }

        [ForeignKey("Paid")]
        public string PaidStatus { get; set; }
        public Status Paid { get; set; }

        [ForeignKey("Invoiced")]
        public string InvoicedStatus { get; set; }
        public Status Invoiced { get; set; }

        [ForeignKey("Received")]
        public string ReceivedStatus { get; set; }
        public Status Received { get; set; }

        [ForeignKey("Produced")]
        public string ProducedStatus { get; set; }
        public Status Produced { get; set; }

        [ForeignKey("Shipped")]
        public string ShippedStatus { get; set; }
        public Status Shipped { get; set; }

        public string HoldOrderText { get; set; }

        public decimal? TotalInvoice { get; set; }
        public decimal? Payments { get; set; }
        public decimal? Balance { get; set; }

        public ICollection<Address> Addresses { get; set; }
        public ICollection<OrderDesign> OrderDesigns { get; set; }
        public ICollection<OrderDesignLocation> OrderDesignLocations { get; set; }
    }
}
