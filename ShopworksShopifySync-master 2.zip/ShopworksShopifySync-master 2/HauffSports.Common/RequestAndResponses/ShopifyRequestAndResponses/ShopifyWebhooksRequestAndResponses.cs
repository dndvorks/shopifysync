﻿using HauffSports.Common.Models.Shopify;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses
{
    public class GetWebhookResponse : BaseResponse
    {
        public GetWebhookResponse()
        {
            this.Webhook = new WebhookModel();
        }

        public WebhookModel Webhook { get; set; }
    }

    public class GetWebhooksResponse : BaseResponse
    {
        public GetWebhooksResponse()
        {
            this.Webhooks = new List<WebhookModel>();
        }

        public List<WebhookModel> Webhooks { get; set; }
    }

    public class ActivateWebhookRequest : BaseRequest
    {
        public ActivateWebhookRequest()
        {
            this.Webhook = new WebhookModel();
        }

        [JsonProperty(PropertyName = "webhook")]
        public WebhookModel Webhook { get; set; }
    }

    public class ActivateWebhookResponse : BaseResponse { }

    public class DeleteWebhookRequest : BaseRequest
    {
        public DeleteWebhookRequest()
        {
            this.WebhookId = 0;
        }

        public long WebhookId { get; set; }
    }

    public class DeleteWebhookResponse : BaseResponse { }
}