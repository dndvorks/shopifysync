﻿using System.IO;
using log4net.Config;
using Microsoft.Extensions.Configuration;

namespace HauffSports.Sync.Shopify
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static int Main(string[] args)
        {
            XmlConfigurator.Configure(new FileInfo("log4net.config"));

            var builder = new ConfigurationBuilder()
                .AddJsonFile($"appsettings.json", true, true);

            var settings = builder.Build().Get(typeof(AppSettings)) as AppSettings;

            try
            {
                foreach (var shopifySettings in settings.ShopifyList)
                {
                    var service = new ShopifySync(
                        settings.General.Shopworks,
                        settings.General.ImagesPath,
                        shopifySettings);
                    service.Sync();
                }

                return 0;
            }
            catch
            {
                return -1;
            }
        }
    }
}