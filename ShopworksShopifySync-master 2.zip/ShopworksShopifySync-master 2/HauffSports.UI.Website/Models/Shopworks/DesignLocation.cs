﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("DesignLocation", Schema = "shopworks")]
    public class DesignLocation : BaseShopworks
    {
        public string DesignId { get; set; }
        public Design Design { get; set; }

        public string Location { get; set; }

        public ICollection<Thumbnail> Thumbnails { get; set; }
        public ICollection<OrderDesignLocation> OrderDesignLocations { get; set; }
    }
}

