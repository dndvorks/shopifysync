﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HauffSports.Common")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HauffSports.Common")]
[assembly: AssemblyCopyright("Copyright ©2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("db62e073-e9ae-4153-84ea-eee77d8046c5")]
[assembly: AssemblyVersion("1.0.0")]