﻿using HauffSports.Common.Models.Shopify;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses
{
    public class GetProductResponse : BaseResponse
    {
        public GetProductResponse()
        {
            this.Product = new ProductModel();
        }
        
        [JsonProperty(PropertyName = "product")]
        public ProductModel Product { get; set; }
    }

    public class GetProductsResponse : BaseResponse
    {
        public GetProductsResponse()
        {
            this.Products = new List<ProductModel>();
        }

        [JsonProperty(PropertyName = "products")]
        public List<ProductModel> Products { get; set; }
    }

    public class GetProductMetafieldsResponse : BaseResponse
    {
        public GetProductMetafieldsResponse()
        {
            this.Metafields = new List<ShopifyMetafieldModel>();
        }

        [JsonProperty(PropertyName = "metafields")]
        public List<ShopifyMetafieldModel> Metafields { get; set; }
    }

    public class SaveProductRequest : BaseRequest
    {
        public SaveProductRequest()
        {
            this.Product = new ProductModel();
        }

        [JsonProperty(PropertyName = "product")]
        public ProductModel Product { get; set; }
    }

    public class SaveProductResponse : BaseResponse
    {
        public SaveProductResponse()
        {
            this.Product = new ProductModel();
        }

        [JsonProperty(PropertyName = "product")]
        public ProductModel Product { get; set; }
    }

    public class SaveProductVariantRequest : BaseRequest
    {
        public SaveProductVariantRequest()
        {
            this.ProductVariant = new ProductVariantModel();
            this.ProductId = 0;
        }

        [JsonProperty(PropertyName = "product_id")]
        public long ProductId { get; set; }
        [JsonProperty(PropertyName = "variant")]
        public ProductVariantModel ProductVariant { get; set; }
    }

    public class SaveProductVariantResponse : BaseResponse
    {
        public SaveProductVariantResponse()
        {
            this.ProductVariant = new ProductVariantModel();
        }
        
        [JsonProperty(PropertyName = "variant")]
        public ProductVariantModel ProductVariant { get; set; }
    }

    public class SaveProductMetafieldRequest : BaseRequest
    {
        public SaveProductMetafieldRequest()
        {
            this.ProductMetafield = new MetafieldModel();
            this.ProductId = 0;
        }

        public long ProductId { get; set; }
        [JsonProperty(PropertyName = "metafield")]
        public MetafieldModel ProductMetafield { get; set; }
    }

    public class SaveProductMetafieldResponse : BaseResponse
    {
        public SaveProductMetafieldResponse()
        {
            this.ProductMetafield = new ShopifyMetafieldModel();
        }

        [JsonProperty(PropertyName = "metafield")]
        public ShopifyMetafieldModel ProductMetafield { get; set; }
    }

    public class DeleteProductRequest : BaseRequest
    {
        public DeleteProductRequest()
        {
            this.ProductId = 0;
        }

        [JsonProperty(PropertyName = "product_id")]
        public long ProductId { get; set; }
    }

    public class DeleteProductResponse : BaseResponse
    {
        public DeleteProductResponse()
        {

        }
    }

    public class DeleteProductVariantRequest : BaseRequest
    {
        public DeleteProductVariantRequest()
        {
            this.VariantId = 0;
        }

        [JsonProperty(PropertyName = "variant_id")]
        public long VariantId { get; set; }
    }

    public class DeleteProductVariantResponse : BaseResponse
    {
        public DeleteProductVariantResponse()
        {

        }
    }
}