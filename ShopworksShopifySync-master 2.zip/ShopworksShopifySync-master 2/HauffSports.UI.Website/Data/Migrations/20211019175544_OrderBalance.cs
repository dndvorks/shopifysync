﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class OrderBalance : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "Balance",
                schema: "shopworks",
                table: "Order",
                type: "decimal(18,2)",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "Payments",
                schema: "shopworks",
                table: "Order",
                type: "decimal(18,2)",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "TotalInvoice",
                schema: "shopworks",
                table: "Order",
                type: "decimal(18,2)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Balance",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "Payments",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "TotalInvoice",
                schema: "shopworks",
                table: "Order");
        }
    }
}
