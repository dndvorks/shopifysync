﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class SaveAsQuote : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CustomerPurchaseOrder",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsCustom",
                table: "SalesOrderProduct",
                nullable: false,
                defaultValue: false);

            migrationBuilder.Sql("UPDATE dbo.SalesOrders SET SentAt = CreatedAt");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CustomerPurchaseOrder",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "IsCustom",
                table: "SalesOrderProduct");

            migrationBuilder.Sql("UPDATE dbo.SalesOrders SET SentAt = NULL");
        }
    }
}
