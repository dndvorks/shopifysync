﻿using HauffSports.Common.Models.Shopify;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses
{
    public class GetProductsRequest : ShopWorksBaseRequest { }

    public class GetProductsResponse : ShopWorksBaseResponse
    {
        public GetProductsResponse()
        {
            this.Products = new List<ProductModel>();
        }

        public List<ProductModel> Products { get; set; }
    }

    public class GetProductRequest : ShopWorksBaseRequest
    {
        public GetProductRequest()
        {
            this.PartNumber = string.Empty;
        }

        public string PartNumber { get; set; }
    }

    public class GetProductResponse : ShopWorksBaseResponse
    {
        public GetProductResponse()
        {
            this.Products = new List<ProductModel>();
        }

        public List<ProductModel> Products { get; set; }
    }
}