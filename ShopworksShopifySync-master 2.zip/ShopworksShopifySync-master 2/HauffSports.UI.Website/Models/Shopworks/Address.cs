﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Address", Schema = "shopworks")]
    public class Address : BaseShopworks
    {
        public string CustomerId { get; set; }
        public Customer Customer { get; set; }

        public string ContactId { get; set; }
        public Contact Contact { get; set; }

        public string EmployeeId { get; set; }
        public Employee Employee { get; set; }

        public string VendorId { get; set; }
        public Vendor Vendor { get; set; }

        public string OrderId { get; set; }
        public Order Order { get; set; }
        public string ShipMethod { get; set; }

        public string Company { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set;}
        public string State { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
    }
}
