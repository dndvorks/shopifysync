﻿using Newtonsoft.Json;
using System;

namespace HauffSports.Common.Models.Shopify
{
    public class BaseModel
    {
        public BaseModel()
        {
            this.Id = 0;
            this.UpdatedAt = DateTimeOffset.MinValue;
            this.CreatedAt = DateTimeOffset.MinValue;
        }

        [JsonProperty(PropertyName = "id")]
        public long Id { get; set; }

        [JsonProperty(PropertyName = "updated_at")]
        public DateTimeOffset UpdatedAt { get; set; }

        [JsonProperty(PropertyName = "created_at")]
        public DateTimeOffset CreatedAt { get; set; }
    }
}