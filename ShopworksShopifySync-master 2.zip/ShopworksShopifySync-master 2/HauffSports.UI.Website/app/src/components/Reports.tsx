﻿import * as React from "react";
import { AutoComplete } from "./inputs";

const Reports: React.FC<{}> = () => {

	return (
		<div>
			<AutoComplete
				label="Vendor"
			/>
		</div>
	);
};

export default Reports;

