﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("ProductClass", Schema = "shopworks")]
    public class ProductClass : BaseShopworks
    {
        public string Name { get; set; }
    }
}
