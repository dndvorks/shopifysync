﻿import * as React from "react";
import * as ReactDOM from "react-dom";

import Reports from "./components/Reports";

ReactDOM.render(
	<React.StrictMode>
		<Reports />
	</React.StrictMode>,
	document.getElementById("reports")
);
