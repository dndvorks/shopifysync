﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("InventoryLevel", Schema = "shopworks")]
    public class InventoryLevel : BaseShopworks
    {
        public string PartNumber { get; set; }
        public string PartColorRange { get; set; }
        public string PartColor { get; set; }
        public string PartDescription { get; set; }

        public int? Size01 { get; set; }
        public int? Size01_OnOrder { get; set; }
        public int? Size01_InProduction { get; set; }
        public int? Size01_Committed { get; set; }
        public int? Size01_Reconciled { get; set; }
        public int? Size01_ToReachMin { get; set; }
        public int? Size01_ToReachMax { get; set; }

        public int? Size02 { get; set; }
        public int? Size02_OnOrder { get; set; }
        public int? Size02_InProduction { get; set; }
        public int? Size02_Committed { get; set; }
        public int? Size02_Reconciled { get; set; }
        public int? Size02_ToReachMin { get; set; }
        public int? Size02_ToReachMax { get; set; }

        public int? Size03 { get; set; }
        public int? Size03_OnOrder { get; set; }
        public int? Size03_InProduction { get; set; }
        public int? Size03_Committed { get; set; }
        public int? Size03_Reconciled { get; set; }
        public int? Size03_ToReachMin { get; set; }
        public int? Size03_ToReachMax { get; set; }

        public int? Size04 { get; set; }
        public int? Size04_OnOrder { get; set; }
        public int? Size04_InProduction { get; set; }
        public int? Size04_Committed { get; set; }
        public int? Size04_Reconciled { get; set; }
        public int? Size04_ToReachMin { get; set; }
        public int? Size04_ToReachMax { get; set; }

        public int? Size05 { get; set; }
        public int? Size05_OnOrder { get; set; }
        public int? Size05_InProduction { get; set; }
        public int? Size05_Committed { get; set; }
        public int? Size05_Reconciled { get; set; }
        public int? Size05_ToReachMin { get; set; }
        public int? Size05_ToReachMax { get; set; }

        public int? Size06 { get; set; }
        public int? Size06_OnOrder { get; set; }
        public int? Size06_InProduction { get; set; }
        public int? Size06_Committed { get; set; }
        public int? Size06_Reconciled { get; set; }
        public int? Size06_ToReachMin { get; set; }
        public int? Size06_ToReachMax { get; set; }
    }
}
