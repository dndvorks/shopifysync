﻿using System.Collections.Generic;

namespace HauffSports.Sync.Web
{
    public class GeneralSettings
    {
        public string Shopworks { get; set; }
        public string Website { get; set; }
        public string Storage { get; set; }
        public string ImagesPath { get; set; }
        public bool WriteCache { get; set; }
        public bool ReadCache { get; set; }
        public string CachePath { get; set; }
        public string ClearTables { get; set; }
        public string ErrorEmail { get; set; }
        public bool SyncShopworks { get; set; }
        public bool SyncLegacy { get; set; }
        public bool SyncThumbnails { get; set; }
        public bool SyncInvoiceReminders { get; set; }
    }

    public class EmailSettings
    {
        public string DisplayName { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public string Server { get; set; }
        public int Port { get; set; }
        public bool EnableSsl { get; set; }
    }

    public class AppSettings
    {
        public GeneralSettings General { get; set; }
        public EmailSettings Email { get; set; }
    }
}
