﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using HauffSports.UI.Website.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Hosting;
using HauffSports.UI.Website.Data;
using HauffSports.UI.Website.Services;
using SelectPdf;

namespace HauffSports.UI.Website.Controllers
{
    [Authorize]
    public class SalesOrderController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        private readonly IEmailAttachmentSender _emailSender;
        private readonly IViewRenderService _renderService;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public SalesOrderController(
            UserManager<ApplicationUser> userManager, 
            ApplicationDbContext context, 
            IEmailAttachmentSender emailSender, 
            IViewRenderService renderService,
            IWebHostEnvironment env)
        {
            _userManager = userManager;
            _context = context;
            _emailSender = emailSender;
            _renderService = renderService;
            _webHostEnvironment = env;
        }

        private async Task<SalesOrder> GetSalesOrderForCurrentUser(int id)
        {
            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            SalesOrder salesOrder = null;

            if (await _userManager.IsInRoleAsync(user, "admin"))
            {
                salesOrder = _context.SalesOrders.Where(s => s.Id == id && s.DeletedAt == null).FirstOrDefault();
            }
            else
            {
                var userEmail = await _userManager.GetEmailAsync(user);
                salesOrder = _context.SalesOrders.Where(s => s.Id == id && s.DeletedAt == null && s.SalesRepEmail == userEmail).FirstOrDefault();
            }

            await _context.Entry(salesOrder).Collection(s => s.Products).LoadAsync();
            await _context.Entry(salesOrder).Collection(s => s.Logos).LoadAsync();

            foreach (var logo in salesOrder.Logos)
            {
                await _context.Entry(logo).Collection(l => l.Files).LoadAsync();

                foreach (var file in logo.Files)
                {
                    file.File = _context.Files.Where(f => f.Id == file.FileId).FirstOrDefault();
                }
            }

            return salesOrder;
        }
        private async Task<string> RenderViewAsync<TModel>(string viewName, TModel model, bool partial = false)
        {
            if (string.IsNullOrEmpty(viewName))
            {
                viewName = this.ControllerContext.ActionDescriptor.ActionName;
            }

            this.ViewData.Model = model;

            using (var writer = new StringWriter())
            {
                IViewEngine viewEngine = this.HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as ICompositeViewEngine;
                ViewEngineResult viewResult = viewEngine.FindView(this.ControllerContext, viewName, !partial);

                if (viewResult.Success == false)
                {
                    return $"A view with the name {viewName} could not be found";
                }

                ViewContext viewContext = new ViewContext(
                    this.ControllerContext,
                    viewResult.View,
                    this.ViewData,
                    this.TempData,
                    writer,
                    new HtmlHelperOptions()
                );

                await viewResult.View.RenderAsync(viewContext);

                return writer.GetStringBuilder().ToString();
            }
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View("CreateOrEdit");
        }

        [HttpGet]
        [Route("SalesOrder/Edit/{id:int}")]
        public async Task<IActionResult> Edit(int id)
        {
            var salesOrder = await GetSalesOrderForCurrentUser(id);

            if (salesOrder == null)
            {
                return NotFound();
            }

            return View("CreateOrEdit", salesOrder);
        }

        [HttpGet]
        [Route("SalesOrder/Quote/{id:int}")]
        public async Task<IActionResult> Quote(int id)
        {
            var salesOrder = await GetSalesOrderForCurrentUser(id);

            if (salesOrder == null)
            {
                return NotFound();
            }

            ViewBag.Customer = _context.LegacyCustomers.Where(c => c.Id == salesOrder.CustomerId).FirstOrDefault();

            return View("Quote", salesOrder);
        }

        [HttpGet]
        [Route("SalesOrder/QuotePdf/{id:int}")]
        public async Task<IActionResult> QuotePdf(int id)
        {
            var salesOrder = await GetSalesOrderForCurrentUser(id);

            if (salesOrder == null)
            {
                return NotFound();
            }

            ViewBag.Customer = _context.LegacyCustomers.Where(c => c.Id == salesOrder.CustomerId).FirstOrDefault();

            string html = await this.RenderViewAsync("Quote", salesOrder);

            // instantiate a html to pdf converter object
            HtmlToPdf converter = new HtmlToPdf();

            converter.Options.CssMediaType = HtmlToPdfCssMediaType.Print;

            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}";

            // create a new pdf document converting an url
            PdfDocument doc = converter.ConvertHtmlString(html, baseUrl);

            var bytes = doc.Save();

            // close pdf document
            doc.Close();

            return File(bytes, "application/pdf", id + ".pdf");
        }

        [HttpGet]
        [Route("SalesOrder/Shopworks/{id:int}")]
        public async Task<IActionResult> Shopworks(int id)
        {
            var salesOrder = await GetSalesOrderForCurrentUser(id);

            if (salesOrder == null)
            {
                return NotFound();
            }

            var text = CreateShopworksSalesOrder(salesOrder);
            var salesOrderId = string.Format("A{0:D5}", salesOrder.Id);

            return File(Encoding.UTF8.GetBytes(text), "text/plain", salesOrderId + ".txt");
        }

        [HttpGet]
        [Route("SalesOrder/Delete/{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var salesOrder = await GetSalesOrderForCurrentUser(id);

            if (salesOrder == null)
            {
                return NotFound();
            }
            
            salesOrder.DeletedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return RedirectToAction("List");
        }

        [HttpGet]
        public async Task<IActionResult> List([FromQuery(Name = "sent")] string sent, [FromQuery(Name = "deleted")] string deleted)
        {
            bool showSent = sent == "1";
            bool showDeleted = deleted == "1";
            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            var userEmail = await _userManager.GetEmailAsync(user);

            ViewData["Title"] = "Sales Orders " + (showSent ? " (Sent)" : " (Unsent)") + (showDeleted ? " (Deleted)" : "");

            if (await _userManager.IsInRoleAsync(user, "admin"))
            {
                return View("List", _context.SalesOrders.Where(s => (showSent || s.SentAt == null) && (showDeleted || s.DeletedAt == null)));
            }
            else
            {
                return View("List", _context.SalesOrders.Where(s => (showSent || s.SentAt == null) && (showDeleted || s.DeletedAt == null) && s.SalesRepEmail == userEmail));
            }
        }

        [HttpGet]
        public IActionResult Success()
        {
            return View("Success");
        }

        [HttpPost]
        public async Task<IActionResult> Save(IFormCollection collection)
        {
            SalesOrder salesOrder = new SalesOrder(collection);

            if (salesOrder.Id != 0)
            {
                _context.SalesOrders.Update(salesOrder);
            }
            else
            {
                _context.SalesOrders.Add(salesOrder);
            }

            await _context.SaveChangesAsync();

            salesOrder = await GetSalesOrderForCurrentUser(salesOrder.Id);

            if (collection["command"] == "SendSalesOrder")
            {
                var salesOrderShopworks = CreateShopworksSalesOrder(salesOrder);

                var salesOrderId = string.Format("A{0:D5}", salesOrder.Id);

                var msg = "Sales Order " + salesOrderId;
                var attachments = new List<Attachment>()
                    {
                        new Attachment()
                        {
                            Filename = salesOrderId + ".txt",
                            Type = "text/plain",
                            Disposition = "attachment",
                            Content = Convert.ToBase64String(Encoding.UTF8.GetBytes(salesOrderShopworks))
                        }
                    };

                await _emailSender.SendEmailAsync(
                    salesOrder.SalesRepEmail,
                    msg,
                    msg,
                    attachments
                );

                if (_webHostEnvironment.IsProduction())
                {
                    await _emailSender.SendEmailAsync(
                        "curt@dakotalettering.com",
                        msg,
                        msg,
                        attachments
                    );
                }

                salesOrder.SentAt = DateTime.UtcNow;
                await _context.SaveChangesAsync();
                return RedirectToAction("Success");
            }

            return RedirectToAction("List");
        }

        private static string line(string key, string value = null)
        {
            value = (value ?? "").Trim().Replace("\r\n", "<cr>").Replace("\r", "<cr>").Replace("\n", "<cr>");
            return string.Format("{0}>> {1}\n", key, value);
        }

        private string CreateShopworksSalesOrder(SalesOrder model)
        {
            var notesToArt = "";

            foreach (var logo in model.Logos)
            {
                notesToArt += string.Format(
                    "[Location: {0}, Colors: {1}, Size: {2}]\n",
                    logo.Location, logo.Colors, logo.Size
                );

                foreach (var file in logo.Files)
                {
                    notesToArt += Url.Action("Download", "Files", new { id = file.FileId }, Request.Scheme, Request.Host.ToString()) + "\n";
                }

                notesToArt += logo.NotesToArt;
            }

            var orderStr =
                "---- Start Order ----\n" +
                "\n" +

                line("ExtOrderID", string.Format("A{0:D5}", model.Id)) +
                line("ExtSource", "WebSite") +
                line("dateExternal", DateTime.Now.ToString("M/d/yyyy")) +
                line("id_OrderType", model.OrderType.ToString()) +
                "\n" +
                line("CustomerPurchaseOrder", model.CustomerPurchaseOrder) +
                line("TermsName") +
                line("CustomerServiceRep", model.SalesRep) +
                line("CustomerType") +
                line("id_CompanyLocation", model.SalesRepLocation.ToString()) +
                line("id_SalesStatus") +
                line("sts_CommishAllow", "0") +
                "\n" +
                line("date_OrderPlaced", model.OrderDate ?? "") +
                line("date_OrderRequestedToShip", model.RequestedShippingDate ?? "") +
                line("date_OrderDropDead", model.DropDeadDate ?? "") +
                "\n" +
                line("sts_Order_SalesTax_Override", "0") +
                line("sts_ApplySalesTax01", "1") +
                line("sts_ApplySalesTax02", "0") +
                line("sts_ApplySalesTax03", "0") +
                line("sts_ApplySalesTax04", "0") +
                line("sts_ShippingTaxable", "0") +
                "\n" +
                line("coa_AccountSalesTax01") +
                line("coa_AccountSalesTax02") +
                line("coa_AccountSalesTax03") +
                line("coa_AccountSalesTax04") +
                "\n" +
                line("ShipAddressDescription") +
                line("AddressCompany") +
                line("Address1") +
                line("Address2") +
                line("AddressCity") +
                line("AddressState") +
                line("AddressZip") +
                line("AddressCountry") +
                line("ShipMethod", model.ShippingMethod) +
                line("cur_Shipping", model.Shipping) +
                line("sts_Order_ShipAddress_Add", "1") +
                "\n" +
                line("NotesToArt", notesToArt) +
                line("NotesToProduction", model.NotesToProduction) +
                line("NotesToReceiving", model.NotesToReceiving) +
                line("NotesToPurchasing", model.NotesToPurchasing) +
                line("NotesToShipping", model.NotesToShipping) +
                line("NotesToAccounting", model.NotesToAccounting) +
                line("NotesToPurchasingSub") +
                "\n" +
                "---- End Order ----\n" +
                "\n" +
                "---- Start Customer ----\n" +
                "\n" +
                line("ExtCustomerID") +
                line("id_Customer", model.CustomerId.ToString()) +
                line("Company") +
                line("id_CompanyLocation") +
                line("Terms") +
                line("WebsiteURL") +
                line("EmailMain") +
                "\n" +
                line("AddressDescription") +
                line("AddressCompany") +
                line("Address1") +
                line("Address2") +
                line("AddressCity") +
                line("AddressState") +
                line("AddressZip") +
                line("AddressCountry") +
                "\n" +
                line("sts_ChargeSalesTax", "1") +
                line("TaxExemptNumber") +
                line("coa_AccountSalesTax01") +
                line("coa_AccountSalesTax02") +
                line("coa_AccountSalesTax03") +
                line("coa_AccountSalesTax04") +
                "\n" +
                line("id_DiscountLevel") +
                line("id_DefaultCalculator01") +
                line("id_DefaultCalculator02") +
                "\n" +
                line("CustomerServiceRep") +
                line("CustomerType") +
                line("CustomerSource") +
                line("ReferenceFrom") +
                line("SICCode") +
                line("SICDescription") +
                line("n_EmployeeCount") +
                "\n" +
                line("CustomField01") +
                line("CustomField02") +
                line("CustomField03") +
                line("CustomField04") +
                line("CustomField05") +
                line("CustomField06") +
                line("CustomField07") +
                line("CustomField08") +
                line("CustomField09") +
                line("CustomField10") +
                "\n" +
                "---- End Customer ----\n" +
                "\n" +
                "---- Start Contact ----\n" +
                "\n" +
                line("NameFirst", model.CustomerFirstName) +
                line("NameLast", model.CustomerLastName) +
                line("Department") +
                line("Title") +
                line("Phone", model.CustomerPhone) +
                line("Fax") +
                line("Email", model.CustomerEmail) +
                line("sts_Contact_Add", model.CreateContact ? "1": "0") +
                line("sts_EnableBulkEmail", "0") +
                "\n" +
                "---- End Contact ----\n";

            foreach (var logo in model.Logos)
            {
                if (logo.DesignId != null)
                {
                    orderStr +=
                        "\n" +
                        "---- Start Design ----\n" +
                        "\n" +
                        line("ExtDesignID") +
                        line("id_DesignType") +
                        line("DesignName") +
                        line("id_Design", logo.DesignId.ToString()) +
                        "\n" +
                        "---- Start Location ----\n" +
                        "\n" +
                        line("Location", logo.Location) +
                        "\n" +
                        "---- End Location ----\n" +
                        "\n" +
                        "---- End Design ----\n";
                }

                foreach (var logoFile in logo.Files)
                {
                    orderStr +=
                        "\n" +
                        "---- Start Design ----\n" +
                        "\n" +
                        line("ExtDesignID") +
                        line("id_DesignType") +
                        line("DesignName", logoFile.File.Name) +
                        line("id_Design") +
                        "\n" +
                        "---- Start Location ----\n" +
                        "\n" +
                        line("Location", logo.Location) +
                        "\n" +
                        "---- End Location ----\n" +
                        "\n" +
                        "---- End Design ----\n";
                }
            }

            foreach (var product in model.Products)
            {
                orderStr +=
                    "\n" +
                    "---- Start Product ----\n" +
                    "\n" +
                    line("PartNumber", product.PartNumber ?? "") +
                    line("PartColorRange") +
                    line("PartColor", string.IsNullOrEmpty(product.ColorOther) ? (product.Color ?? "") : product.ColorOther) +
                    line("cur_UnitPriceUserEntered", product.AdjustedPrice ?? "") +
                    line("OrderInstructions") +
                    "\n" +
                    line("Size01_Req", product.Size01 ?? "0") +
                    line("Size02_Req", product.Size02 ?? "0") +
                    line("Size03_Req", product.Size03 ?? "0") +
                    line("Size04_Req", product.Size04 ?? "0") +
                    line("Size05_Req", product.Size05 ?? "0") +
                    line("Size06_Req", product.Size06 ?? "0") +
                    "\n" +
                    line("sts_Prod_Product_Override", "1") +
                    line("PartDescription", product.PartDescription ?? "") +
                    line("cur_UnitCost", product.AdjustedCost ?? "") +
                    line("sts_EnableCommission", "0") +
                    line("id_ProductClass", product.ProductClassId ?? "") +
                    "\n" +
                    line("sts_Prod_SalesTax_Override", "0") +
                    line("sts_ApplySalesTax01", "1") +
                    line("sts_ApplySalesTax02", "0") +
                    line("sts_ApplySalesTax03", "0") +
                    line("sts_ApplySalesTax04", "0") +
                    "\n" +
                    line("sts_Prod_SecondaryUnits_Override", "0") +
                    line("sts_UseSecondaryUnits") +
                    line("Units_Qty") +
                    line("Units_Type") +
                    line("Units_Area1") +
                    line("Units_Area2") +
                    line("sts_UnitsPricing") +
                    line("sts_UnitsPurchasing") +
                    line("sts_UnitsPurchasingExtraPercent") +
                    line("sts_UnitsPurchasingExtraRound") +
                    "\n" +
                    line("sts_Prod_Behavior_Override", "0") +
                    line("sts_ProductSource_Supplied") +
                    line("sts_ProductSource_Purchase", "1") +
                    line("sts_ProductSource_Inventory", "1") +
                    "\n" +
                    "sts_Production_Designs>> " +
                        (
                            (
                                model.OrderType == 21 ||
                                model.OrderType == 11 ||
                                model.OrderType == 70 ||
                                model.OrderType == 83
                            ) ? "1" : ""
                        ) + "\n" +
                    line("sts_Production_Subcontract") +
                    line("sts_Production_Components") +
                    "\n" +
                    line("sts_Storage_Ship", "1") +
                    line("sts_Storage_Inventory") +
                    "\n" +
                    line("sts_Invoicing_Invoice") +
                    "\n" +
                    "---- End Product ----\n";
            }

            return orderStr;
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
