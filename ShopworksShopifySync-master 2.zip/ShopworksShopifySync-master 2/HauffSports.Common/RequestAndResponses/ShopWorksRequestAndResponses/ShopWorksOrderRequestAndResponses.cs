﻿using HauffSports.Common.Models.Shopify;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses
{
    public class CreateOrderFileRequest : ShopWorksBaseRequest
    {
        public CreateOrderFileRequest()
        {
            this.Order = new ShopifyOrderModel();
            this.CustomerMetafields = new List<ShopifyMetafieldModel>();

        }

        public ShopifyOrderModel Order { get; set; }
        public List<ShopifyMetafieldModel> CustomerMetafields { get; set; }
    }

    public class CreateOrderFileResponse : ShopWorksBaseResponse
    {
        public CreateOrderFileResponse()
        {
            this.FileName = string.Empty;
            this.File = null;
        }

        public string FileName { get; set; }
        public byte[] File { get; set; }

    }
}