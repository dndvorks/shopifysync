﻿using Microsoft.Extensions.Configuration;
using System.IO;
using log4net.Config;

namespace HauffSports.Sync.Web
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static int Main(string[] args)
        {
            XmlConfigurator.Configure(new FileInfo("log4net.config"));

            var builder = new ConfigurationBuilder()
                .AddJsonFile($"appsettings.json", true, true)
                .AddCommandLine(args);

            var settings = builder.Build().Get(typeof(AppSettings)) as AppSettings;

            var service = new WebSync(settings);

            return service.Sync();
        }
    }
}
