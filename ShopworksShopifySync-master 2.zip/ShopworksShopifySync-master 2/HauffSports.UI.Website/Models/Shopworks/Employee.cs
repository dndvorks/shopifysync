﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Employee", Schema = "shopworks")]
    public class Employee : BaseShopworks
    {
        public string NameFull { get; set; }
        public string EmailAddress { get; set; }

        [ForeignKey("Active")]
        public string ActiveStatus { get; set; }
        public Status Active { get; set; }

        public ICollection<Address> Addresses { get; set; }
    }
}
