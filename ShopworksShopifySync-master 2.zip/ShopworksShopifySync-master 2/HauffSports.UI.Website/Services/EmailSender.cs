﻿using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HauffSports.UI.Website.Services
{
    public class Attachment
    {
        public string Filename { get; set; }
        public string Content { get; set; }
        public string Disposition { get; set; }
        public string Type { get; set; }
    }

    public interface IEmailAttachmentSender : IEmailSender
    {
        Task SendEmailAsync(string email, string subject, string htmlMessage, List<Attachment> attachments);
    }

    public class EmailSender : IEmailAttachmentSender
    {
        public EmailSender(IOptions<AppSettings> optionsAccessor)
        {
            ApiKey = optionsAccessor.Value.SendGridApiKey;
        }

        public string ApiKey { get; }

        public Task SendEmailAsync(string email, string subject, string message)
        {
            return SendEmailAsync(email, subject, message, new List<Attachment>());
        }

        public Task SendEmailAsync(string email, string subject, string message, List<Attachment> attachments)
        {
            var client = new SendGridClient(ApiKey);
            var msg = new SendGridMessage()
            {
                From = new EmailAddress("no-reply@dakotalettering.azure.net", "Dakota Lettering"),
                Subject = subject,
                PlainTextContent = message,
                HtmlContent = message
            };

            if (attachments.Count() > 0)
            {
                msg.Attachments = attachments.Select(a => new SendGrid.Helpers.Mail.Attachment()
                {
                    Content = a.Content,
                    Filename = a.Filename,
                    Type = a.Type,
                    Disposition = a.Disposition
                }).ToList();
            }

            msg.AddTo(new EmailAddress(email));

            // Disable click tracking.
            // See https://sendgrid.com/docs/User_Guide/Settings/tracking.html
            msg.SetClickTracking(false, false);

            return client.SendEmailAsync(msg);
        }
    }
}
