﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("DesignVariation", Schema = "shopworks")]
    public class DesignVariation : BaseShopworks
    {
        public string DesignId { get; set; }
        public Design Design { get; set; }

        public string VariationName { get; set; }
    }
}

