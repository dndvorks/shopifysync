﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class ShopworksTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "shopworks");

            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "Customer",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CompanyName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailMain = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneMain = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FaxMain = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomField01 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomField02 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomField03 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    NameFull = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OrderType",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductClass",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductClass", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductColor",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductColor", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SalesStatus",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalesStatus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ShippingStatus",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ShippingStatus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Status",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Status", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Vendor",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    VendorName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VendorAbbreviationCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AccountNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vendor", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Design",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CustomerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DesignName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Design", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Design_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalSchema: "shopworks",
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Contact",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CustomerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    VendorId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    NameFirst = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NameLast = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Department = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailPrimary = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contact", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Contact_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalSchema: "shopworks",
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Contact_Vendor_VendorId",
                        column: x => x.VendorId,
                        principalSchema: "shopworks",
                        principalTable: "Vendor",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Product",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProductClassId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    VendorId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    PartNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Colors = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FindCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProductType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomField01 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomField02 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Product_ProductClass_ProductClassId",
                        column: x => x.ProductClassId,
                        principalSchema: "shopworks",
                        principalTable: "ProductClass",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_Vendor_VendorId",
                        column: x => x.VendorId,
                        principalSchema: "shopworks",
                        principalTable: "Vendor",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DesignLocation",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DesignId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DesignLocation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DesignLocation_Design_DesignId",
                        column: x => x.DesignId,
                        principalSchema: "shopworks",
                        principalTable: "Design",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DesignVariation",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DesignId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    VariationName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DesignVariation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DesignVariation_Design_DesignId",
                        column: x => x.DesignId,
                        principalSchema: "shopworks",
                        principalTable: "Design",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ContactNumber",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ContactId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Label = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Number = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    FaxStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    EmailStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    PrimaryStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContactNumber", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ContactNumber_Contact_ContactId",
                        column: x => x.ContactId,
                        principalSchema: "shopworks",
                        principalTable: "Contact",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ContactNumber_Status_EmailStatus",
                        column: x => x.EmailStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ContactNumber_Status_FaxStatus",
                        column: x => x.FaxStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ContactNumber_Status_PhoneStatus",
                        column: x => x.PhoneStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ContactNumber_Status_PrimaryStatus",
                        column: x => x.PrimaryStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Order",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CustomerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ContactId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    OrderTypeId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ShippingStatusId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    SalesStatusId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomerServiceRep = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContactEmail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PlacedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ShipRequestedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DropDeadAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    InvoicedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    TermsDays = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PaidStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    InvoicedStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ReceivedStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ProducedStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ShippedStatus = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Order", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Order_Contact_ContactId",
                        column: x => x.ContactId,
                        principalSchema: "shopworks",
                        principalTable: "Contact",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalSchema: "shopworks",
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_OrderType_OrderTypeId",
                        column: x => x.OrderTypeId,
                        principalSchema: "shopworks",
                        principalTable: "OrderType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_ShippingStatus_ShippingStatusId",
                        column: x => x.ShippingStatusId,
                        principalSchema: "shopworks",
                        principalTable: "ShippingStatus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_Status_InvoicedStatus",
                        column: x => x.InvoicedStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_Status_PaidStatus",
                        column: x => x.PaidStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_Status_ProducedStatus",
                        column: x => x.ProducedStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_Status_ReceivedStatus",
                        column: x => x.ReceivedStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Order_Status_ShippedStatus",
                        column: x => x.ShippedStatus,
                        principalSchema: "shopworks",
                        principalTable: "Status",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Address",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CustomerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ContactId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    EmployeeId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    VendorId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ShipMethod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Company = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Zip = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Address_Contact_ContactId",
                        column: x => x.ContactId,
                        principalSchema: "shopworks",
                        principalTable: "Contact",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Address_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalSchema: "shopworks",
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Address_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalSchema: "shopworks",
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Address_Order_OrderId",
                        column: x => x.OrderId,
                        principalSchema: "shopworks",
                        principalTable: "Order",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Address_Vendor_VendorId",
                        column: x => x.VendorId,
                        principalSchema: "shopworks",
                        principalTable: "Vendor",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OrderDesign",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    OrderId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DesignId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderDesign", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderDesign_Design_DesignId",
                        column: x => x.DesignId,
                        principalSchema: "shopworks",
                        principalTable: "Design",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_OrderDesign_Order_OrderId",
                        column: x => x.OrderId,
                        principalSchema: "shopworks",
                        principalTable: "Order",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OrderNotification",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    EventType = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Bcc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SentAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    OrderUpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderNotification", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderNotification_Order_OrderId",
                        column: x => x.OrderId,
                        principalSchema: "shopworks",
                        principalTable: "Order",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OrderDesignLocation",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    OrderId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    OrderDesignId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DesignLocationId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderDesignLocation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderDesignLocation_DesignLocation_DesignLocationId",
                        column: x => x.DesignLocationId,
                        principalSchema: "shopworks",
                        principalTable: "DesignLocation",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_OrderDesignLocation_Order_OrderId",
                        column: x => x.OrderId,
                        principalSchema: "shopworks",
                        principalTable: "Order",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_OrderDesignLocation_OrderDesign_OrderDesignId",
                        column: x => x.OrderDesignId,
                        principalSchema: "shopworks",
                        principalTable: "OrderDesign",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Thumbnail",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DesignLocationId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    OrderDesignLocationId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    FileName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileExtension = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileLocation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileWidth = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileHeight = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileStorageType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Thumbnail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Thumbnail_DesignLocation_DesignLocationId",
                        column: x => x.DesignLocationId,
                        principalSchema: "shopworks",
                        principalTable: "DesignLocation",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Thumbnail_OrderDesignLocation_OrderDesignLocationId",
                        column: x => x.OrderDesignLocationId,
                        principalSchema: "shopworks",
                        principalTable: "OrderDesignLocation",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Address_ContactId",
                schema: "shopworks",
                table: "Address",
                column: "ContactId");

            migrationBuilder.CreateIndex(
                name: "IX_Address_CustomerId",
                schema: "shopworks",
                table: "Address",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Address_EmployeeId",
                schema: "shopworks",
                table: "Address",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Address_OrderId",
                schema: "shopworks",
                table: "Address",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_Address_VendorId",
                schema: "shopworks",
                table: "Address",
                column: "VendorId");

            migrationBuilder.CreateIndex(
                name: "IX_Contact_CustomerId",
                schema: "shopworks",
                table: "Contact",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Contact_VendorId",
                schema: "shopworks",
                table: "Contact",
                column: "VendorId");

            migrationBuilder.CreateIndex(
                name: "IX_ContactNumber_ContactId",
                schema: "shopworks",
                table: "ContactNumber",
                column: "ContactId");

            migrationBuilder.CreateIndex(
                name: "IX_ContactNumber_EmailStatus",
                schema: "shopworks",
                table: "ContactNumber",
                column: "EmailStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ContactNumber_FaxStatus",
                schema: "shopworks",
                table: "ContactNumber",
                column: "FaxStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ContactNumber_PhoneStatus",
                schema: "shopworks",
                table: "ContactNumber",
                column: "PhoneStatus");

            migrationBuilder.CreateIndex(
                name: "IX_ContactNumber_PrimaryStatus",
                schema: "shopworks",
                table: "ContactNumber",
                column: "PrimaryStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Design_CustomerId",
                schema: "shopworks",
                table: "Design",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_DesignLocation_DesignId",
                schema: "shopworks",
                table: "DesignLocation",
                column: "DesignId");

            migrationBuilder.CreateIndex(
                name: "IX_DesignVariation_DesignId",
                schema: "shopworks",
                table: "DesignVariation",
                column: "DesignId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_ContactId",
                schema: "shopworks",
                table: "Order",
                column: "ContactId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_CustomerId",
                schema: "shopworks",
                table: "Order",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_InvoicedStatus",
                schema: "shopworks",
                table: "Order",
                column: "InvoicedStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Order_OrderTypeId",
                schema: "shopworks",
                table: "Order",
                column: "OrderTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Order_PaidStatus",
                schema: "shopworks",
                table: "Order",
                column: "PaidStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Order_ProducedStatus",
                schema: "shopworks",
                table: "Order",
                column: "ProducedStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Order_ReceivedStatus",
                schema: "shopworks",
                table: "Order",
                column: "ReceivedStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Order_ShippedStatus",
                schema: "shopworks",
                table: "Order",
                column: "ShippedStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Order_ShippingStatusId",
                schema: "shopworks",
                table: "Order",
                column: "ShippingStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDesign_DesignId",
                schema: "shopworks",
                table: "OrderDesign",
                column: "DesignId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDesign_OrderId",
                schema: "shopworks",
                table: "OrderDesign",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDesignLocation_DesignLocationId",
                schema: "shopworks",
                table: "OrderDesignLocation",
                column: "DesignLocationId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDesignLocation_OrderDesignId",
                schema: "shopworks",
                table: "OrderDesignLocation",
                column: "OrderDesignId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDesignLocation_OrderId",
                schema: "shopworks",
                table: "OrderDesignLocation",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderIdEventType",
                schema: "dbo",
                table: "OrderNotification",
                columns: new[] { "OrderId", "EventType" },
                unique: true,
                filter: "[OrderId] IS NOT NULL AND [EventType] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Product_ProductClassId",
                schema: "shopworks",
                table: "Product",
                column: "ProductClassId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_VendorId",
                schema: "shopworks",
                table: "Product",
                column: "VendorId");

            migrationBuilder.CreateIndex(
                name: "IX_Thumbnail_DesignLocationId",
                schema: "shopworks",
                table: "Thumbnail",
                column: "DesignLocationId");

            migrationBuilder.CreateIndex(
                name: "IX_Thumbnail_OrderDesignLocationId",
                schema: "shopworks",
                table: "Thumbnail",
                column: "OrderDesignLocationId");

            migrationBuilder.Sql(@"
CREATE FUNCTION dbo.ValidateEmail(@EMAIL varchar(450), @DEFAULTEMAIL varchar(450)) RETURNS varchar(450) as
BEGIN     
    DECLARE @bitEmailVal as Bit
    DECLARE @EmailText varchar(450)

    SET @EmailText=ltrim(rtrim(isnull(@EMAIL,'')))

    SET @bitEmailVal = 
        case when @EmailText = '' then 0
            when @EmailText like '% %' then 0
            when @EmailText like ('%[""(),:;<>\]% ') then 0
            when substring(@EmailText, charindex('@',@EmailText),len(@EmailText)) like('%[!#$%&*+/=?^`_{|]%') then 0
            when(left(@EmailText, 1) like('[-_.+]') or right(@EmailText, 1) like('[-_.+]')) then 0
            when(@EmailText like '%[%' or @EmailText like '%]%') then 0
            when @EmailText LIKE '%@%@%' then 0
            when @EmailText NOT LIKE '_%@_%._%' then 0
            else 1
        end

    RETURN case when @bitEmailVal = 1 then @EmailText else @DEFAULTEMAIL end
END
GO
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("drop function dbo.ValidateEmail");

            migrationBuilder.DropTable(
                name: "Address",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "ContactNumber",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "DesignVariation",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "OrderNotification",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Product",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "ProductColor",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "SalesStatus",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Thumbnail",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Employee",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "ProductClass",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "OrderDesignLocation",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "DesignLocation",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "OrderDesign",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Design",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Order",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Contact",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "OrderType",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "ShippingStatus",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Status",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Customer",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "Vendor",
                schema: "shopworks");
        }
    }
}
