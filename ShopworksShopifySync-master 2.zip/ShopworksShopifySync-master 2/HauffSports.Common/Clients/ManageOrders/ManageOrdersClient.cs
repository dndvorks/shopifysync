﻿using Newtonsoft.Json.Linq;
using System.IO;
using System.Net;
using System.Text;

namespace HauffSports.Common.Clients.ManageOrders
{
    public class ManageOrdersClient
    {
        private string username;
        private string password;
        private string baseUrl = "https://manageordersapi.com/v1";
        private string idToken = null;

        public ManageOrdersClient(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        protected string IdToken {
            get {
                if (idToken == null)
                {
                    var response = this.MakeRequest(
                        $"{baseUrl}/manageorders/signin",
                        "POST",
                        new JObject(new JProperty("username", this.username), new JProperty("password", this.password)),
                        false
                    );
                    idToken = response.Value<string>("id_token");
                }
                return idToken;
            }
        }

        protected JObject MakeRequest(string url, string method, JObject body = null, bool auth = true)
        {
            var webRequest = WebRequest.Create(url);

            if (auth)
            {
                webRequest.Headers.Add("Authorization", IdToken);
            }

            if (body is not null)
            {
                var encoded = Encoding.UTF8.GetBytes(body.ToString());

                webRequest.Method = method;
                webRequest.ContentType = "application/json";
                webRequest.ContentLength = encoded.Length;

                using (var dataStream = webRequest.GetRequestStream())
                    dataStream.Write(encoded, 0, encoded.Length);
            }

            using (var dataResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(dataResponse.GetResponseStream()))
                {
                    return JObject.Parse(reader.ReadToEnd());
                }
            }
        }

        public JObject GetOrder(string orderId)
        {
            return MakeRequest(
                 $"{baseUrl}/manageorders/orders/{orderId}",
                 "GET"
            );
        }
    }
}
