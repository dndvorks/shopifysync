﻿using System;

namespace HauffSports.Common.RequestAndResponses.DatabaseRequestAndResponses
{
    public class BaseRequest
    {
        public BaseRequest()
        {
            this.CompanySiteId = Guid.Empty;
            this.UserToken = null;
        }

        public string UserToken { get; set; }
        public Guid CompanySiteId { get; set; }
    }

    public class BaseAsyncRequest : BaseRequest
    {
        public BaseAsyncRequest()
        {
            this.SessionId = string.Empty;
        }

        public string SessionId { get; set; }
    }

    public class BaseActiveRequest
    {
        public BaseActiveRequest()
        {
            this.GetActiveAndInactive = false;
        }

        public bool GetActiveAndInactive { get; set; }
    }

    public class BaseResponse
    {
        public BaseResponse()
        {
            this.IsSuccess = false;
            this.ErrorMessage = string.Empty;
        }

        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
    }
}