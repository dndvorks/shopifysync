﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using HauffSports.UI.Website.Data;
using HauffSports.UI.Website.Models;
using Microsoft.AspNetCore.Authorization;

namespace HauffSports.UI.Website.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Products
        [HttpGet]
        public IEnumerable<LegacyProduct> GetProducts()
        {
            if (Request.Query.Keys.Contains("q"))
            {
                var q = Request.Query["q"];
                return _context.LegacyProducts.Where(
                    p => p.PartNumber.Contains(q) || p.Description.Contains(q));
            }

            return new List<LegacyProduct>();
        }

        // GET: api/Products
        [HttpGet]
        [Route("PartNumber/{partNumber}")]
        public LegacyProduct GetProductByPartNumber(string partNumber)
        {
            return _context.LegacyProducts.Where(p => p.PartNumber == partNumber).FirstOrDefault();
        }
    }
}