﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Vendor", Schema = "shopworks")]
    public class Vendor : BaseShopworks
    {
        public string VendorName { get; set; }
        public string VendorAbbreviationCode { get; set; }
        public string AccountNumber { get; set; }

        [ForeignKey("Active")]
        public string ActiveStatus { get; set; }
        public Status Active { get; set; }

        public List<Address> Addresses { get; set; }
        public List<Product> Products { get; set; }
    }
}
