﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class OrderFields : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CompanyName",
                schema: "shopworks",
                table: "Order",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ContactFirst",
                schema: "shopworks",
                table: "Order",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ContactLast",
                schema: "shopworks",
                table: "Order",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LocationId",
                schema: "shopworks",
                table: "Order",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Location",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CompanyName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LocationName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneMain = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailMain = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneTollFree = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    WebURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Location", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Order_LocationId",
                schema: "shopworks",
                table: "Order",
                column: "LocationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Order_Location_LocationId",
                schema: "shopworks",
                table: "Order",
                column: "LocationId",
                principalSchema: "shopworks",
                principalTable: "Location",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.Sql("update dbo.OrderNotification set EventType = 'Completion-Delivery' where EventType = 'Ready for Delivery'");
            migrationBuilder.Sql("update dbo.OrderNotification set EventType = 'Completion-Pickup' where EventType = 'Ready for Pick Up'");
            migrationBuilder.Sql("update dbo.OrderNotification set EventType = 'Completion-Shipped' where EventType = 'Shipped'");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Order_Location_LocationId",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropTable(
                name: "Location",
                schema: "shopworks");

            migrationBuilder.DropIndex(
                name: "IX_Order_LocationId",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "CompanyName",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "ContactFirst",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "ContactLast",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "LocationId",
                schema: "shopworks",
                table: "Order");

            migrationBuilder.Sql("update dbo.OrderNotification set EventType = 'Ready for Delivery' where EventType = 'Completion-Delivery'");
            migrationBuilder.Sql("update dbo.OrderNotification set EventType = 'Ready for Pick Up' where EventType = 'Completion-Pickup'");
            migrationBuilder.Sql("update dbo.OrderNotification set EventType = 'Shipped' where EventType = 'Completion-Shipped'");
        }
    }
}
