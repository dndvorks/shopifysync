﻿using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using System;
using HauffSports.Common.Enums;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;
using System.IO;

namespace HauffSports.Common.Clients.Shopify
{
    public class CollectionClient : ShopifyBaseClient
    {
        public CollectionClient(string apiPublicKey, string apiSecretKey, string url) : base(apiPublicKey, apiSecretKey, url)
        {
        }

        /// <summary>
        ///     Gets a shopify custom collection for a specific collection id.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetCustomCollectionResponse</returns>
        public GetCustomCollectionResponse GetCustomCollection(GetRecordRequest request)
        {
            try
            {                
                request.ResourceType = ShopifyResourceType.custom_collections;

                var baseResponse = GetRecord(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetCustomCollectionResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomCollectionResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets all of the shopify custom collections for a certain date range.
        /// </summary>
        /// <param name="request">GetCustomCollections</param>
        /// <returns>GetCustomCollectionsResponse</returns>
        public GetCustomCollectionsResponse GetCustomCollections(GetRecordsRequest request)
        {
            try
            {
                request.ResourceType = ShopifyResourceType.custom_collections;

                var baseResponse = GetRecords(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetCustomCollectionsResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomCollectionsResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates a new shopify custom collection.
        /// </summary>
        /// <param name="request">SaveCustomCollectionRequest</param>
        /// <returns>SaveCustomCollectionResponse</returns>
        public SaveCustomCollectionResponse SaveCustomCollection(SaveCustomCollectionRequest request)
        {
            try
            {                
                var baseRequest = new SaveRecordRequest { ResourceType = ShopifyResourceType.custom_collections };

                baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();

                var baseResponse = AddRecord(baseRequest);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<SaveCustomCollectionResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new SaveCustomCollectionResponse { ErrorMessage = ex.Message };
            }
        }
        
        /// <summary>
        ///     Gets shopify collects for a specific product id.
        /// </summary>
        /// <param name="request">GetRecordByQueryRequest</param>
        /// <returns>GetCollectsResponse</returns>
        public GetCollectsResponse GetCollectsByQuery(GetRecordByQueryRequest request)
        {
            try
            {                
                request.ResourceType = ShopifyResourceType.collects;

                var baseResponse = GetRecordByQuery(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetCollectsResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCollectsResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets all of the shopify collects
        /// </summary>
        /// <param name="request">GetRecordsRequest</param>
        /// <returns>GetCollectsResponse</returns>
        public GetCollectsResponse GetCollects(GetRecordsRequest request)
        {
            try
            {
                request.ResourceType = ShopifyResourceType.collects;

                var baseResponse = GetRecords(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetCollectsResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCollectsResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates a new shopify collect.
        /// </summary>
        /// <param name="request">SaveCollectRequest</param>
        /// <returns>SaveCollectResponse</returns>
        public SaveCollectResponse SaveCollect(SaveCollectRequest request)
        {
            try
            {                
                var baseRequest = new SaveRecordRequest { ResourceType = ShopifyResourceType.collects };
                baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(new { collect = request })).ToString();

                var baseResponse = AddRecord(baseRequest);
                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<SaveCollectResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new SaveCollectResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new SaveCollectResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets a shopify smart collection for a specific collection id.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetSmartCollectionResponse</returns>
        public GetSmartCollectionResponse GetSmartCollection(GetRecordRequest request)
        {
            try
            {
                request.ResourceType = ShopifyResourceType.smart_collections;

                var baseResponse = GetRecord(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetSmartCollectionResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetSmartCollectionResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets all of the shopify smart collections for a certain date range.
        /// </summary>
        /// <param name="request">GetSmartCollections</param>
        /// <returns>GetSmartCollectionsResponse</returns>
        public GetSmartCollectionsResponse GetSmartCollections(GetRecordsRequest request)
        {
            try
            {
                request.ResourceType = ShopifyResourceType.smart_collections;

                var baseResponse = GetRecords(request);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetSmartCollectionsResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetSmartCollectionsResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates a new shopify smart collection.
        /// </summary>
        /// <param name="request">SaveSmartCollectionRequest</param>
        /// <returns>SaveSmartCollectionResponse</returns>
        public SaveSmartCollectionResponse SaveSmartCollection(SaveSmartCollectionRequest request)
        {
            try
            {
                var baseRequest = new SaveRecordRequest { ResourceType = ShopifyResourceType.smart_collections };

                baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();

                var baseResponse = AddRecord(baseRequest);

                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<SaveSmartCollectionResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new SaveSmartCollectionResponse { ErrorMessage = ex.Message };
            }
        }
    }
}