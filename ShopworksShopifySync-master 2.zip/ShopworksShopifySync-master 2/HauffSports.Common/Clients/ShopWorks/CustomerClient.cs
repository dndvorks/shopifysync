﻿using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Threading;

namespace HauffSports.Common.Clients.ShopWorks
{
    public class ShopWorksCustomerClient : ShopWorksBaseClient
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected OdbcConnection FileMakerCoreConnection { get; private set; }

        public ShopWorksCustomerClient(string connectionString) : base(connectionString) {
            FileMakerCoreConnection = new OdbcConnection("DSN=FileMaker_Data_Core;" + ConnectionString);
        }

        public List<Dictionary<string, string>> GetCustomersSimple(ManualResetEvent stopRequest)
        {
            var results = new List<Dictionary<string, string>>();
            var query = "SELECT cu.ID_Customer, cu.CompanyName, cu.EmailMain, " + 
                "a.Address1, a.Address2, a.AddressCity, a.AddressState, a.AddressZip " +
                "FROM Cust cu join Addr a on cu.ID_Customer = a.id_customermain";

            using (var cmd = new OdbcCommand(query, FileMakerCoreConnection))
            {
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    while (reader.Read())
                    {
                        if (stopRequest != null && stopRequest.WaitOne(0))
                        {
                            log.Info("Stop Requested");
                            break;
                        }

                        var result = new Dictionary<string, string>();
                        
                        result.Add("CustomerId", ConvertToString(reader["ID_Customer"]));
                        result.Add("CompanyName", ConvertToString(reader["CompanyName"]));
                        result.Add("EmailMain", ConvertToString(reader["EmailMain"]));
                        result.Add("Address1", ConvertToString(reader["Address1"]));
                        result.Add("Address2", ConvertToString(reader["Address2"]));
                        result.Add("AddressCity", ConvertToString(reader["AddressCity"]));
                        result.Add("AddressState", ConvertToString(reader["AddressState"]));
                        result.Add("AddressZip", ConvertToString(reader["AddressZip"]));
                        
                        results.Add(result);
                    }
                }
            }

            return results;
        }

        public List<Dictionary<string, string>> GetContactsSimple(ManualResetEvent stopRequest)
        {
            var results = new List<Dictionary<string, string>>();
            var query = "SELECT ID_Contact AS Id, ID_Customer AS CustomerID, " +
                "NameFirst AS FirstName, NameLast AS LastName " +
                "FROM Cont WHERE ID_Customer IS NOT NULL";

            using (var cmd = new OdbcCommand(query, FileMakerCoreConnection))
            {
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    while (reader.Read())
                    {
                        if (stopRequest != null && stopRequest.WaitOne(0))
                        {
                            log.Info("Stop Requested");
                            break;
                        }

                        string firstName = ConvertToString(reader["FirstName"]);
                        string lastName = ConvertToString(reader["LastName"]);
                        
                        if (lastName == "")
                        {
                            if (firstName.Contains(" "))
                            {
                                var parts = new List<string>(firstName.Split(' '));
                                firstName = parts[0];
                                parts.RemoveAt(0);
                                lastName = string.Join(" ", parts);
                            }
                        }

                        var result = new Dictionary<string, string>();
                        result.Add("Id", ConvertToString(reader["Id"]));
                        result.Add("CustomerId", ConvertToString(reader["CustomerId"]));
                        result.Add("FirstName", firstName);
                        result.Add("LastName", lastName);
                        result.Add("Phone", "");
                        result.Add("Email", "");
                        results.Add(result);
                    }
                }
            }

            query = "SELECT ID_Contact AS Id, Number AS Phone, Email FROM ContNum " +
                "WHERE sts_Phone = 1 OR sts_Email = 1";

            using (var cmd = new OdbcCommand(query, FileMakerCoreConnection))
            {
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    while (reader.Read())
                    {
                        if (stopRequest != null && stopRequest.WaitOne(0))
                        {
                            log.Info("Stop Requested");
                            break;
                        }

                        string id = ConvertToString(reader["Id"]);
                        string phone = ConvertToString(reader["Phone"]);
                        string email = ConvertToString(reader["Email"]);

                        if (phone != "" || email != "" )
                        {
                            var row = results.Where(r => r["Id"] == id).FirstOrDefault();

                            if (row != null && phone != "")
                            {
                                row["Phone"] = phone;
                            }

                            if (row != null && email != "" && email != "//")
                            {
                                row["Email"] = email;
                            }
                        }
                    }
                }
            }

            return results;
        }

        public GetCustomersResponse GetCustomers(GetCustomersRequest request)
        {
            try
            {
                var response = new GetCustomersResponse();
                var cmdText = CreateCustomerCmdText();
                using (var cmd = new OdbcCommand(cmdText, this.FileMakerCoreConnection))
                {
                    cmd.Connection.Open();
                    using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (reader.Read())
                        {
                            //LogReader(reader);
                            response.Customers.Add(CreateCustomerModel(this, reader));
                        }
                }

                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomersResponse { ErrorMessage = ex.Message };
            }
        }

        private CustomerCreateModel CreateCustomerModel(ShopWorksBaseClient baseService, OdbcDataReader reader)
        {
            var shopifyCreateCustomerModel = new CustomerCreateModel { HasVerifiedEmail = false, SendEmailInvite = false };
            if (reader["Email"] != DBNull.Value) shopifyCreateCustomerModel.Email = Convert.ToString(reader["Email"]).Trim();
            if (reader["NameFirst"] != DBNull.Value) shopifyCreateCustomerModel.FirstName = Convert.ToString(reader["NameFirst"]).Trim();
            if (reader["NameLast"] != DBNull.Value) shopifyCreateCustomerModel.LastName = Convert.ToString(reader["NameLast"]).Trim();

            if (shopifyCreateCustomerModel.LastName == "")
            {
                if (shopifyCreateCustomerModel.FirstName.Contains(" "))
                {
                    var parts = new List<string>(shopifyCreateCustomerModel.FirstName.Split(' '));
                    shopifyCreateCustomerModel.FirstName = parts[0];
                    parts.RemoveAt(0);
                    shopifyCreateCustomerModel.LastName = string.Join(" ", parts);
                }

                if (shopifyCreateCustomerModel.LastName == "")
                {
                    shopifyCreateCustomerModel.LastName = shopifyCreateCustomerModel.Email.Split('@')[0];
                }
            }

            this.CreateMetafield(shopifyCreateCustomerModel, "original_id", Convert.ToString(reader["ID_Contact"]));
            this.CreateMetafield(shopifyCreateCustomerModel, "customer_id", Convert.ToString(reader["ID_Customer"]));
            this.CreateMetafield(shopifyCreateCustomerModel, "company_name", Convert.ToString(reader["CompanyName"]));
            return shopifyCreateCustomerModel;
        }

        private static string CreateCustomerCmdText()
        {
            return "SELECT cu.ID_Customer, cu.CompanyName, co.ID_Contact, co.NameFirst, co.NameLast, cn.Email " +
                   "FROM Cont co " +
                   "INNER JOIN Cust cu ON cu.ID_Customer = co.id_Customer " +
                   "INNER JOIN ContNum cn ON cn.id_Contact = co.ID_Contact AND cn.cn_sts_Email = 1";

            //return "SELECT * FROM ContNum cn WHERE cn.id_Contact = 13013";
            //       "INNER JOIN Cust cu ON cu.ID_Customer = co.id_Customer " + 
            //       "INNER JOIN ContNum cn ON cn.id_Contact = co.ID_Contact ";
        }

        private static void LogReader(OdbcDataReader reader)
        {
            try
            {
                var msg = "";
                for (int i = 0; i < reader.FieldCount; i++)
                    msg += "[" + reader.GetName(i) + ": " + Convert.ToString(reader[i]) + "]" + Environment.NewLine;
                Console.WriteLine(msg);
                Console.WriteLine("----------------------------------------------------------------------------------");
            }
            catch (Exception) { }
        }

        private void CreateMetafield(CustomerCreateModel customer, string key, string value)
        {
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    var metafield = new MetafieldModel { Namespace = "global", Key = key, Value = value.Trim(), ValueType = "string" };
                    customer.Metafields.Add(metafield);
                }
            }
            catch (Exception) { }
        }
    }
}