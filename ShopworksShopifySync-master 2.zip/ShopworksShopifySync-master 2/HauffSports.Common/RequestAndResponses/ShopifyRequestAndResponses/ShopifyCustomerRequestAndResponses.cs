﻿using HauffSports.Common.Models.Shopify;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses
{
    public class GetCustomerResponse : BaseResponse
    {
        public GetCustomerResponse()
        {
            this.Customer = new CustomerModel();
        }

        public CustomerModel Customer { get; set; }
    }

    public class GetCustomersResponse : BaseResponse
    {
        public GetCustomersResponse()
        {
            this.Customers = new List<CustomerModel>();
        }

        public List<CustomerModel> Customers { get; set; }
    }

    public class GetCustomerMetafiledsResponse : BaseResponse
    {
        public GetCustomerMetafiledsResponse()
        {
            this.Metafields = new List<ShopifyMetafieldModel>();
        }

        public List<ShopifyMetafieldModel> Metafields { get; set; }
    }

    public class SaveCustomerRequest : BaseRequest
    {
        public SaveCustomerRequest()
        {
            this.Customer = new CustomerCreateModel();
        }

        [JsonProperty(PropertyName = "customer")]
        public CustomerCreateModel Customer { get; set; }
    }

    public class SaveCustomerResponse : BaseResponse
    {
        public SaveCustomerResponse()
        {
            this.Customer = new CustomerModel();
        }

        public CustomerModel Customer { get; set; }
    }

    public class SaveCustomerMetafieldRequest : BaseRequest
    {
        public SaveCustomerMetafieldRequest()
        {
            this.CustomerMetafield = new MetafieldModel();
            this.CustomerId = 0;
        }

        public long CustomerId { get; set; }
        [JsonProperty(PropertyName = "metafield")]
        public MetafieldModel CustomerMetafield { get; set; }
    }

    public class SaveCustomerMetafieldResponse : BaseResponse
    {
        public SaveCustomerMetafieldResponse()
        {
            this.CustomerMetafield = new ShopifyMetafieldModel();
        }

        public ShopifyMetafieldModel CustomerMetafield { get; set; }
    }
}