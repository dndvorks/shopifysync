﻿namespace HauffSports.Sync.Mailman
{
    public class GeneralSettings
    {
        public string Website { get; set; }
        public string AdminAddress { get; set; }
        public string DebugAddress { get; set; }
        public int LookbackHours { get; set; }
        public string RenderPath { get; set; }
        public bool EnableRender { get; set; }
        public bool EnableSend { get; set; }
        public bool WriteSentFlag { get; set; }
        public string EventFilter { get; set; }
        public string EmailFilter { get; set; }
    }

    public class EmailSettings
    {
        public string DisplayName { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public string Server { get; set; }
        public int Port { get; set; }
        public bool EnableSsl { get; set; }
    }

    public class ManageOrdersSettings
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class AppSettings
    {
        public GeneralSettings General { get; set; }
        public EmailSettings Email { get; set; }
        public ManageOrdersSettings ManageOrders { get; set; }
    }
}
