﻿using System.Collections.Generic;

namespace HauffSports.Sync.Service
{
    public class Job
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public string Cron { get; set; }
    }

    public class AppSettings
    {
        public ICollection<Job> Jobs { get; set; }
    }
}
