﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class SalesOrder : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "SalesOrders",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SalesRep = table.Column<string>(nullable: true),
                    SalesRepLocation = table.Column<int>(nullable: false),
                    SalesRepEmail = table.Column<string>(nullable: true),
                    CustomerId = table.Column<string>(nullable: true),
                    CustomerNameFirst = table.Column<string>(nullable: true),
                    CustomerNameLast = table.Column<string>(nullable: true),
                    CustomerPhone = table.Column<string>(nullable: true),
                    CustomerEmail = table.Column<string>(nullable: true),
                    OrderType = table.Column<int>(nullable: false),
                    OrderDate = table.Column<string>(nullable: true),
                    ShippingMethod = table.Column<string>(nullable: false),
                    RequestedShippingDate = table.Column<string>(nullable: false),
                    DropDeadDate = table.Column<string>(nullable: true),
                    NotesToProduction = table.Column<string>(nullable: true),
                    NotesToReceiving = table.Column<string>(nullable: true),
                    NotesToPurchasing = table.Column<string>(nullable: true),
                    NotesToShipping = table.Column<string>(nullable: true),
                    NotesToAccounting = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalesOrders", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SalesOrderLogoLocation",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Location = table.Column<string>(nullable: true),
                    Colors = table.Column<string>(nullable: true),
                    Size = table.Column<string>(nullable: true),
                    NotesToArt = table.Column<string>(nullable: true),
                    SalesOrderId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalesOrderLogoLocation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SalesOrderLogoLocation_SalesOrders_SalesOrderId",
                        column: x => x.SalesOrderId,
                        principalTable: "SalesOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SalesOrderProduct",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    PartNumber = table.Column<string>(nullable: true),
                    PartDescription = table.Column<string>(nullable: true),
                    ProductClassId = table.Column<string>(nullable: true),
                    Cost = table.Column<string>(nullable: true),
                    Price = table.Column<string>(nullable: false),
                    Color = table.Column<string>(nullable: true),
                    ColorOther = table.Column<string>(nullable: true),
                    Size01 = table.Column<string>(nullable: true),
                    Size02 = table.Column<string>(nullable: true),
                    Size03 = table.Column<string>(nullable: true),
                    Size04 = table.Column<string>(nullable: true),
                    Size05 = table.Column<string>(nullable: true),
                    Size06 = table.Column<string>(nullable: true),
                    SalesOrderId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalesOrderProduct", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SalesOrderProduct_SalesOrders_SalesOrderId",
                        column: x => x.SalesOrderId,
                        principalTable: "SalesOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SalesOrderLogoFiles",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    FileName = table.Column<string>(nullable: true),
                    Data = table.Column<byte[]>(nullable: true),
                    SalesOrderLogoLocationId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalesOrderLogoFiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SalesOrderLogoFiles_SalesOrderLogoLocation_SalesOrderLogoLocationId",
                        column: x => x.SalesOrderLogoLocationId,
                        principalTable: "SalesOrderLogoLocation",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderLogoFiles_SalesOrderLogoLocationId",
                table: "SalesOrderLogoFiles",
                column: "SalesOrderLogoLocationId");

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderLogoLocation_SalesOrderId",
                table: "SalesOrderLogoLocation",
                column: "SalesOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderProduct_SalesOrderId",
                table: "SalesOrderProduct",
                column: "SalesOrderId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SalesOrderLogoFiles");

            migrationBuilder.DropTable(
                name: "SalesOrderProduct");

            migrationBuilder.DropTable(
                name: "SalesOrderLogoLocation");

            migrationBuilder.DropTable(
                name: "SalesOrders");
        }
    }
}
