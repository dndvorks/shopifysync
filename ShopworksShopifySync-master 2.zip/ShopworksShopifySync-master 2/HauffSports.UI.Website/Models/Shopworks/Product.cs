﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Product", Schema = "shopworks")]
    public class Product : BaseShopworks
    {
        public string ProductClassId { get; set; }
        public ProductClass ProductClass { get; set; }
        public string VendorId { get; set; }
        public Vendor Vendor { get; set; }
        public string PartNumber { get; set; }
        public string Description { get; set; }
        public string Notes { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal? Cost { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal? Price { get; set; }
        public string Colors { get; set; }
        public string FindCode { get; set; }
        public string ProductType { get; set; }
        public string PreprintGroup { get; set; }
        public string CustomField01 { get; set; }
        public string CustomField02 { get; set; }

        public bool HasSize01 { get; set; }
        public bool HasSize02 { get; set; }
        public bool HasSize03 { get; set; }
        public bool HasSize04 { get; set; }
        public bool HasSize05 { get; set; }
        public bool HasSize06 { get; set; }

        [ForeignKey("Active")]
        public string ActiveStatus { get; set; }
        public Status Active { get; set; }

        [ForeignKey("AllowUpdate")]
        public string AllowUpdateStatus { get; set; }
        public Status AllowUpdate { get; set; }
    }
}
