﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("SalesStatus", Schema = "shopworks")]
    public class SalesStatus : BaseShopworks
    {
        public string Name { get; set; }
    }
}