﻿using HauffSports.Common.Services;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Newtonsoft.Json;

namespace HauffSports.Console
{
    public partial class ShopifyTool : Form
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private class ShopifyInstance
        {
            public ShopifySettings Settings { get; set; }
            public ProductService ProductService { get; set; }
            public CustomerService CustomerService { get; set; }
            public WebhookService WebhookService { get; set; }

            public ToolStripMenuItem Menu { get; set; }
        }

        private readonly IEnumerable<ShopifyInstance> _shopifyInstances;

        private Thread _thread;
        private readonly ManualResetEvent _stopRequest = new(false);
        private string _partNumber = null;
        private bool _force = false;

        public ShopifyTool(AppSettings settings)
        {
            InitializeComponent();

            _shopifyInstances = settings.ShopifyList.Select(
                shopifySettings => new ShopifyInstance()
                {
                    Settings = shopifySettings,
                    CustomerService = new CustomerService(settings.General.Shopworks,
                        shopifySettings.PublicKey, shopifySettings.SecretKey, shopifySettings.Url),
                    ProductService = new ProductService(settings.General.Shopworks,
                        settings.General.ImagesPath, shopifySettings.UseAlternatePrice, shopifySettings.PublicKey,
                        shopifySettings.SecretKey, shopifySettings.Url),
                    WebhookService = new WebhookService(shopifySettings.PublicKey, shopifySettings.SecretKey,
                        shopifySettings.Url),
                    Menu = new ToolStripMenuItem(
                        shopifySettings.Name,
                        null,
                        new ToolStripMenuItem("Sync Product...", null, syncProductToolStripMenuItem_Click),
                        new ToolStripMenuItem("Sync Product (Force)...", null, syncProductToolStripMenuItem_Click),
                        new ToolStripMenuItem("Sync All Products", null, syncProductsMainToolStripMenuItem_Click),
                        new ToolStripMenuItem("Sync All Customers", null, syncCustomersToolStripMenuItem_Click),
                        new ToolStripSeparator(),
                        new ToolStripMenuItem(
                            "Webhook",
                            null,
                            new ToolStripMenuItem("View", null, viewToolStripMenuItem_Click),
                            new ToolStripMenuItem("Activate...", null, activateToolStripMenuItem_Click),
                            new ToolStripMenuItem("Delete", null, deleteToolStripMenuItem_Click),
                            new ToolStripMenuItem("Test Dropbox", null, testDropboxToolStripMenuItem_Click))
                    )
                }
            );
            
            this.menuStrip1.Items.AddRange(_shopifyInstances.Select(instance => (ToolStripItem)instance.Menu).ToArray());
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void syncProductsMainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem senderMenuItem)
            {
                StartTask(SyncProducts, senderMenuItem.OwnerItem.Text);
            }
        }

        private void SyncProducts(object data)
        {
            try
            {
                if (data is ShopifyInstance instance)
                {
                    Log.InfoFormat("{0} Product Sync Starting", instance.Settings.Name);

                    instance.ProductService.SyncProducts(_stopRequest);

                    Log.InfoFormat("{0} Product Sync Ended", instance.Settings.Name);
                }
            }
            catch (Exception ex)
            {
                Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
            }
        }

        private void syncCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem senderMenuItem)
            {
                StartTask(SyncCustomers, senderMenuItem.OwnerItem.Text);
            }
        }

        private void SyncCustomers(object data)
        {
            try
            {
                if (data is ShopifyInstance instance)
                {
                    Log.InfoFormat("{0} Customer Sync Starting", instance.Settings.Name);

                    instance.CustomerService.SyncCustomers(_stopRequest);

                    Log.InfoFormat("{0} Customer Sync Ended", instance.Settings.Name);
                }
            }
            catch (Exception ex)
            {
                Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
            }
        }

        private void syncProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem senderMenuItem)
            {
                _partNumber = Interaction.InputBox("Enter Part Number", "Sync Product");
                _force = senderMenuItem.Text.Contains("Force");

                try
                {
                    if (!string.IsNullOrEmpty(_partNumber))
                    {
                        StartTask(SyncProduct, senderMenuItem.OwnerItem.Text);
                    }
                    else
                    {
                        Log.Info("Product Sync Cancelled");
                    }
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
                }
            }
        }

        private void SyncProduct(object data)
        {
            try
            {
                if (data is ShopifyInstance instance)
                {
                    Log.InfoFormat("{0} Product Sync Starting", instance.Settings.Name);

                    instance.ProductService.SyncProduct(_partNumber, _force);

                    Log.InfoFormat("{0} Product Sync Ended", instance.Settings.Name);
                }
            }
            catch (Exception ex)
            {
                Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
            }
        }

        private void StartTask(ParameterizedThreadStart threadStart, string serviceName)
        {
            if (_thread == null)
            {
                try
                {
                    Log.InfoFormat("Starting {0} Shopify Sync Service", serviceName);
                    
                    threadStart += (object data) =>
                    {
                        EndTask();
                    };

                    _stopRequest.Reset();
                    _thread = new Thread(threadStart);
                    _thread.Start(_shopifyInstances.First(i => i.Settings.Name == serviceName));
                    ToggleControls();
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex.Message);
                    throw;
                }
            }
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EndTask();
        }

        private void EndTask()
        {
            if (_thread != null)
            {
                try
                {
                    if (_thread != Thread.CurrentThread)
                    {
                        _stopRequest.Set();
                        return;
                    }
                    Log.Info("Stopped Shopify Sync Service");
                    _thread = null;
                    ToggleControls();
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex.Message);
                    throw;
                }
            }
        }

        private void ToggleControls()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(ToggleControls));
                return;
            }
                
            if (_thread == null)
            {
                cancelToolStripMenuItem.Visible = false;
                foreach (var i in _shopifyInstances)
                {
                    i.Menu.Visible = true;
                }
            }
            else
            {
                cancelToolStripMenuItem.Visible = true;
                foreach (var i in _shopifyInstances)
                {
                    i.Menu.Visible = false;
                }
            }
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem senderMenuItem)
            {
                try
                {

                    var instance = _shopifyInstances.First(i => i.Settings.Name == senderMenuItem.OwnerItem.OwnerItem.Text);

                    if (instance != null)
                    {
                        Log.InfoFormat("{0} Get Webhooks Starting", instance.Settings.Name);

                        var webHooks = instance.WebhookService.GetWebhooks();

                        foreach (var webhook in webHooks)
                        {
                            Log.InfoFormat("Got webhook [Data: {0}]", JsonConvert.SerializeObject(webhook));
                        }

                        Log.InfoFormat("{0} Get Webhooks Ended", instance.Settings.Name);
                    }
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
                }
            }
        }

        private void activateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem senderMenuItem)
            {
                try
                {

                    var instance = _shopifyInstances.First(i => i.Settings.Name == senderMenuItem.OwnerItem.OwnerItem.Text);

                    if (instance != null)
                    {
                        Log.InfoFormat("{0} Activate Webhook Starting", instance.Settings.Name);

                        var webhookUrl = Interaction.InputBox("Enter Webhook Url", "Activate Webhook",
                            instance.WebhookService.WebhookUrl);

                        if (!string.IsNullOrEmpty(webhookUrl))
                        {
                            instance.WebhookService.ActivateWebhook(webhookUrl);
                        }

                        Log.InfoFormat("{0} Activate Webhook Ended", instance.Settings.Name);
                    }
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender is ToolStripMenuItem senderMenuItem)
            {
                try
                {

                    var instance = _shopifyInstances.First(i => i.Settings.Name == senderMenuItem.OwnerItem.OwnerItem.Text);

                    if (instance != null)
                    {
                        Log.InfoFormat("{0} Delete Webhook Starting", instance.Settings.Name);

                            instance.WebhookService.DeleteWebhook();

                        Log.InfoFormat("{0} Delete Webhook Ended", instance.Settings.Name);
                    }
                }
                catch (Exception ex)
                {
                    Log.Fatal(ex.Message + (ex.InnerException == null ? "" : ex.InnerException.Message));
                }
            }
        }

        private void testDropboxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //var db = new Common.Helpers.DropboxHelper(_dropboxAccessToken, _dropboxFolder);
        }

        private void ShopifyTool_Load(object sender, EventArgs e)
        {
        }

        private void ShopifyTool_FormClosing(object sender, FormClosingEventArgs e)
        {
            EndTask();
        }
    }
}
