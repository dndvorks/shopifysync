﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("PackImport", Schema = "shopworks")]
    public class PackImport : BaseShopworks
    {
        public string OrderId { get; set; }
        public Order Order { get; set; }

        public string Weight { get; set; }
        public string Cost { get; set; }
        public string TrackingNumber { get; set; }

        public string Description { get; set; }
        public string Company { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
    }
}
