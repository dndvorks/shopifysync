﻿using HauffSports.Common.Models.Shopify;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses
{
    public class GetCustomCollectionResponse : BaseResponse
    {
        public GetCustomCollectionResponse()
        {
            this.Collection = new CustomCollectionModel();
        }

        [JsonProperty(PropertyName = "custom_collection")]
        public CustomCollectionModel Collection { get; set; }
    }

    public class GetCustomCollectionsResponse: BaseResponse
    {
        public GetCustomCollectionsResponse()
        {
            this.Collections = new List<CustomCollectionModel>();
        }

        [JsonProperty(PropertyName = "custom_collections")]
        public List<CustomCollectionModel> Collections { get; set; }
    }

    public class SaveCustomCollectionRequest : BaseRequest
    {
        public SaveCustomCollectionRequest()
        {
            this.Collection = new CustomCollectionCreateModel();
        }

        [JsonProperty(PropertyName = "custom_collection")]
        public CustomCollectionCreateModel Collection { get; set; }
    }

    public class SaveCustomCollectionResponse : SaveRecordResponse
    {
        public SaveCustomCollectionResponse()
        {
            this.Collection = new CustomCollectionModel();
        }

        [JsonProperty(PropertyName = "custom_collection")]
        public CustomCollectionModel Collection { get; set; }
    }

    public class GetCollectsResponse : SaveRecordResponse
    {
        public GetCollectsResponse()
        {
            this.Collects = new List<CollectModel>();
        }

        [JsonProperty(PropertyName = "collects")]
        public List<CollectModel> Collects { get; set; }
    }

    public class SaveCollectRequest : BaseRequest
    {
        public SaveCollectRequest()
        {
            this.ProductId = 0;
            this.CollectionId = 0;
        }

        [JsonProperty(PropertyName = "product_id")]
        public long ProductId { get; set; }
        [JsonProperty(PropertyName = "collection_id")]
        public long CollectionId { get; set; }
    }

    public class SaveCollectResponse : SaveRecordResponse
    {
        public SaveCollectResponse()
        {
            this.Collect = new CollectModel();
        }

        [JsonProperty(PropertyName = "collect")]
        public CollectModel Collect { get; set; }
    }

    public class GetSmartCollectionResponse : BaseResponse
    {
        public GetSmartCollectionResponse()
        {
            this.Collection = new SmartCollectionModel();
        }

        [JsonProperty(PropertyName = "smart_collection")]
        public SmartCollectionModel Collection { get; set; }
    }

    public class GetSmartCollectionsResponse : BaseResponse
    {
        public GetSmartCollectionsResponse()
        {
            this.Collections = new List<SmartCollectionModel>();
        }

        [JsonProperty(PropertyName = "smart_collections")]
        public List<SmartCollectionModel> Collections { get; set; }
    }

    public class SaveSmartCollectionRequest : BaseRequest
    {
        public SaveSmartCollectionRequest()
        {
            this.Collection = new SmartCollectionModel();
        }

        [JsonProperty(PropertyName = "smart_collection")]
        public SmartCollectionModel Collection { get; set; }
    }

    public class SaveSmartCollectionResponse : SaveRecordResponse
    {
        public SaveSmartCollectionResponse()
        {
            this.Collection = new SmartCollectionModel();
        }

        [JsonProperty(PropertyName = "smart_collection")]
        public SmartCollectionModel Collection { get; set; }
    }
}