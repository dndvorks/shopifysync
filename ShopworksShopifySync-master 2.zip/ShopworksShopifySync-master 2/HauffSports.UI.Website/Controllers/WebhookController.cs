﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using HauffSports.Common.Clients.Shopify;
using HauffSports.Common.Clients.ShopWorks;
using HauffSports.Common.Helpers;
using HauffSports.Common.Mappers;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;

namespace HauffSports.UI.Website.Controllers
{
    public class WebhookController : Controller
    {
        private readonly ICollection<ShopifySettings> _shopifyList;
        private readonly string _shopworksConnectionString;

        public WebhookController(IOptions<AppSettings> optionsAccessor)
        {
            _shopifyList = optionsAccessor.Value.ShopifyList;
            _shopworksConnectionString = optionsAccessor.Value.Shopworks;
        }

        [HttpGet]
        public void Health()
        {
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("Shopify/{name}")]
        public IActionResult Shopify(string name)
        {
            var instance = _shopifyList.FirstOrDefault(s => s.Name == name);

            if (instance != null)
            {
                try
                {
                    using (var reader = new StreamReader(Request.Body))
                    {
                        var json = JObject.Parse(reader.ReadToEnd());
                        Task.Factory.StartNew(() =>
                            ProcessWebHook(instance, _shopworksConnectionString, Request.Headers["x-shopify-topic"].ToString(), json));
                    }

                    return Ok();
                }
                catch (Exception)
                {
                    return Problem();
                }
            }

            return NotFound();
        }

        /// <summary>
        ///     Process the webhook accoring to the event
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="shopworksConnectionString"></param>
        /// <param name="topic">The event of the webhook.</param>
        /// <param name="json">The full json object of the webhook.</param>
        private static void ProcessWebHook(
            ShopifySettings settings, 
            string shopworksConnectionString, 
            string topic, 
            JObject json)
        {
            var parts = topic.Split('/');

            var evt = parts[0].Trim().ToLower();
            var top = parts[1].Trim().ToLower();

            if (!evt.Equals("orders") && !top.Equals("create"))
                return;

            var shopifyOrder = ShopifyMapper.Map<Common.Models.Shopify.ShopifyOrderModel>(json);
            var metafieldRequest = new GetRecordRequest { RecordId = shopifyOrder.Customer.Id };

            var customerService = new ShopifyCustomerClient(
                settings.PublicKey, 
                settings.SecretKey,
                settings.Url);

            var metafieldResponse = customerService.GetCustomerMetafields(metafieldRequest);

            var createOrderFileRequest = new CreateOrderFileRequest
            {
                Order = shopifyOrder, 
                CustomerMetafields = metafieldResponse.Metafields
            };
            var shopWorksOrderClient = new ShopWorksOrderClient(shopworksConnectionString);
            var createOrderFileResponse = shopWorksOrderClient.CreateShopworksOrderFile(createOrderFileRequest);
            if (createOrderFileResponse.IsSuccess)
            {
                var db = new DropboxHelper(settings.Dropbox.AccessToken, settings.Dropbox.Folder);
                db.UpdateFile(createOrderFileResponse.FileName, createOrderFileResponse.File, true);
            }
        }
    }
}