﻿using HauffSports.Common.Enums;
using HauffSports.Common.Helpers;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using log4net;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace HauffSports.Common.Clients.Shopify
{
    public class ShopifyBaseClient
    {
        protected static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private string apiPublicKey;
        private string apiSecretKey;
        private string url;

        public ShopifyBaseClient(string apiPublicKey, string apiSecretKey, string url)
        {
            this.apiPublicKey = apiPublicKey;
            this.apiSecretKey = apiSecretKey;
            this.url = url.TrimEnd('/');
        }
        
        /// <summary>
        ///     Gets the url from the company;
        /// </summary>
        /// <returns></returns>
        protected string CreateUrl(ShopifyResourceType resourceType)
        {
            return $"{url}/admin/api/2020-01/{resourceType}";
        }

        protected string GetNextLink(WebResponse response)
        {
            var linkMap = new Dictionary<string, string>();
            var values = response.Headers.GetValues("Link");

            if (values != null)
            {
                var links = 
                    values[0].Split(',').Select(
                        link => link.Trim().Split(';').Select(
                            linkPart => linkPart.Trim()
                        ).ToList()
                    ).ToList();
                string pattern = @"rel=""(.*)""";

                foreach (var link in links)
                {
                    linkMap.Add(Regex.Match(link[1], pattern).Groups[1].Captures[0].Value, link[0].TrimStart('<').TrimEnd('>'));
                }
            }

            if (linkMap.ContainsKey("next"))
            {
                return linkMap["next"];
            }

            return null;
        }

        /// <summary>
        ///     Gets all the records for a specified shopify resource and a specified date range.
        /// </summary>
        /// <param name="request">GetRecordsRequest</param>
        /// <returns>GetRecordsResponse</returns>
        /// 
        protected string GetRequest(string url, ref JObject responseObject)
        {
            var webRequest = WebRequest.Create(url);
            SetBasicAuthHeader(webRequest, "GET");
            using (var dataResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(dataResponse.GetResponseStream()))
                {
                    var objText = reader.ReadToEnd();
                    responseObject.Merge(JObject.Parse(objText), new JsonMergeSettings { MergeArrayHandling = MergeArrayHandling.Union });
                    AdjustForNextCall(dataResponse);
                }
                return GetNextLink(dataResponse);
            }
        }

        public GetRecordsResponse GetRecords(GetRecordsRequest request)
        {
            var jsonObject = new JObject();
            string url = $"{CreateUrl(request.ResourceType)}.json?limit={request.NumberPerPage}";
            var nextUrl = GetRequest(url, ref jsonObject);

            while (nextUrl != null)
            {
                nextUrl = GetRequest(nextUrl, ref jsonObject);
            }

            var response = new GetRecordsResponse
            {
                Data = jsonObject,
                IsSuccess = true
            };
            return response;
        }

        /// <summary>
        ///     Gets a specific record from shopify.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetRecordResponse</returns>
        protected GetRecordResponse GetRecord(GetRecordRequest request)
        {
            var response = new GetRecordResponse();
            string url = this.CreateUrl(request.ResourceType) + "/" + request.RecordId.ToString() + ".json?";
            var webRequest = WebRequest.Create(url);
            this.SetBasicAuthHeader(webRequest, "GET");
            using (var dataResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(dataResponse.GetResponseStream()))
                {
                    this.AdjustForNextCall(dataResponse);
                    response.Data = JObject.Parse(reader.ReadToEnd());
                    response.IsSuccess = true;
                    return response;
                }
            }
        }

        /// <summary>
        ///     Gets a specific record from shopify with certain values.
        /// </summary>
        /// <param name="request">GetRecordByQueryRequest</param>
        /// <returns>GetRecordResponse</returns>
        protected GetRecordResponse GetRecordByQuery(GetRecordByQueryRequest request)
        {
            var response = new GetRecordResponse();
            string url = this.CreateUrl(request.ResourceType) + ".json";
            if (request.SearchFields.Count > 0) url += "?";
            foreach (var pair in request.SearchFields)
                url += pair.Key + "=" + pair.Value + "&&";
            var webRequest = WebRequest.Create(url.Trim('&'));
            this.SetBasicAuthHeader(webRequest, "GET");
            using (var dataResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(dataResponse.GetResponseStream()))
                {
                    this.AdjustForNextCall(dataResponse);
                    response.Data = JObject.Parse(reader.ReadToEnd());
                    response.IsSuccess = true;
                    return response;
                }
            }
        }

        /// <summary>
        ///     Gets the metafields for a specific record from shopify.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetRecordsResponse</returns>
        protected GetRecordsResponse GetMetafieldRecords(GetRecordRequest request)
        {
            var response = new GetRecordsResponse();
            string url = this.CreateUrl(request.ResourceType) + "/" + request.RecordId.ToString() + "/metafields.json?";
            var webRequest = WebRequest.Create(url);
            this.SetBasicAuthHeader(webRequest, "GET");
            using (var dataResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(dataResponse.GetResponseStream()))
                {
                    this.AdjustForNextCall(dataResponse);
                    response.Data = JObject.Parse(reader.ReadToEnd());
                    response.IsSuccess = true;
                    return response;
                }
            }
        }

        /// <summary>
        ///     Adds a new shopify record.
        /// </summary>
        /// <param name="request">SaveRecordRequest</param>
        /// <returns>SaveRecordResponse</returns>
        public SaveRecordResponse AddRecord(SaveRecordRequest request)
        {
            var response = new SaveRecordResponse();
            byte[] byteArray = Encoding.UTF8.GetBytes(request.PostData);

            var extendedUrl = string.IsNullOrEmpty(request.ExtendedUrl) ? "" : request.ExtendedUrl.Trim();
            string url = this.CreateUrl(request.ResourceType) + extendedUrl + ".json";
            var webRequest = WebRequest.Create(url);
            webRequest.ContentLength = byteArray.Length;
            this.SetBasicAuthHeader(webRequest, "POST");
            using (var dataStream = webRequest.GetRequestStream())
                dataStream.Write(byteArray, 0, byteArray.Length);
            using (var addResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(addResponse.GetResponseStream()))
                {
                    this.AdjustForNextCall(addResponse);
                    response.Data = JObject.Parse(reader.ReadToEnd());
                    response.IsSuccess = true;
                    return response;
                }
            }
        }

        /// <summary>
        ///     Updates a current shopify record.
        /// </summary>
        /// <param name="request">SaveRecordRequest</param>
        /// <returns>SaveRecordResponse</returns>
        protected SaveRecordResponse UpdateRecord(SaveRecordRequest request)
        {
            var response = new SaveRecordResponse();
            byte[] byteArray = Encoding.UTF8.GetBytes(request.PostData);

            string url = this.CreateUrl(request.ResourceType) + "/" + request.RecordId.ToString() + ".json";
            var webRequest = WebRequest.Create(url);
            webRequest.ContentLength = byteArray.Length;
            this.SetBasicAuthHeader(webRequest, "PUT");
            using (var dataStream = webRequest.GetRequestStream())
                dataStream.Write(byteArray, 0, byteArray.Length);
            using (var updateResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(updateResponse.GetResponseStream()))
                {
                    this.AdjustForNextCall(updateResponse);
                    response.Data = JObject.Parse(reader.ReadToEnd());
                    response.IsSuccess = true;
                    return response;
                }
            }
        }

        /// <summary>
        ///     Deletes a specific record base on an id.
        /// </summary>
        /// <param name="request">DeleteRecordRequest</param>
        /// <returns>BaseResponse</returns>
        protected BaseResponse DeleteRecord(DeleteRecordRequest request)
        {
            var response = new BaseResponse();
            string url = this.CreateUrl(request.ResourceType) + "/" + request.RecordId + ".json";
            var webRequest = WebRequest.Create(url);
            this.SetBasicAuthHeader(webRequest, "DELETE");
            using (var deleteResponse = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(deleteResponse.GetResponseStream()))
                {
                    this.AdjustForNextCall(deleteResponse);
                    response.IsSuccess = true;
                    return response;
                }
            }
        }

        /// <summary>
        ///     Sets the authorization for the web request
        /// </summary>
        /// <param name="request"></param>
        protected void SetBasicAuthHeader(WebRequest request, string method)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var authInfo = apiPublicKey.Trim() + ":" + apiSecretKey.Trim();
            authInfo = Convert.ToBase64String(Encoding.Default.GetBytes(authInfo));
            request.Headers["Authorization"] = "Basic " + authInfo;
            request.ContentType = "application/json";
            request.Method = method;
        }

        /// <summary>
        ///     Slows down the api call to avoid the 429 error.
        /// </summary>
        /// <param name="response"></param>
        protected void AdjustForNextCall(WebResponse response)
        {
            try
            {
                var rates = response.Headers["X-Shopify-Shop-Api-Call-Limit"].Split('/');
                var current = int.Parse(rates[0]);
                var max = int.Parse(rates[1]);
                
                if (current > (max * 0.75))
                {
                    log.WarnFormat("Three-quarters quota reached, waiting 60 seconds [Current: {0}, Max: {1}]", current, max);
                    Thread.Sleep(60000);
                }
                else if (current > (max * 0.5))
                {
                    log.WarnFormat("Half quota reached, waiting 10 seconsd [Current: {0}, Max: {1}]", current, max);
                    Thread.Sleep(10000);
                }
                else
                {
                    Thread.Sleep(500);
                }
            }
            catch
            {
                Thread.Sleep(1000);
                throw;
            }
        }
    }
}