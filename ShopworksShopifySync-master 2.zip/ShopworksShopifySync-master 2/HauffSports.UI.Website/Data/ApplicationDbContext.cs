﻿using HauffSports.UI.Website.Models;
using HauffSports.UI.Website.Models.Shopworks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace HauffSports.UI.Website.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        
        public DbSet<LegacyCustomer> LegacyCustomers { get; set; }
        public DbSet<LegacyContact> LegacyContacts { get; set; }
        public DbSet<LegacyDesignThumbnail> LegacyDesignThumbnails { get; set; }
        public DbSet<LegacyProduct> LegacyProducts { get; set; }

        public DbSet<SalesOrder> SalesOrders { get; set; }
        public DbSet<File> Files { get; set; }
        public DbSet<OrderNotification> OrderNotifications { get; set;  }

        // Shopworks Models
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Contact> Contacts { get; set; }
        public DbSet<ContactNumber> ContactNumbers { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Design> Designs { get; set; }
        public DbSet<DesignLocation> DesignLocations { get; set; }
        public DbSet<DesignVariation> DesignVariations { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<InventoryLevel> InventoryLevels { get; set; }
        public DbSet<InventoryTransaction> InventoryTransactions { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDesign> OrderDesigns { get; set; }
        public DbSet<OrderDesignLocation> OrderDesignLocations { get; set; }
        public DbSet<OrderType> OrderTypes { get; set; }
        public DbSet<PackImport> PackImports { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductClass> ProductClasses { get; set; }
        public DbSet<ProductColor> ProductColors { get; set; }
        public DbSet<SalesStatus> SalesStatus { get; set; }
        public DbSet<ShippingStatus> ShippingStatus { get; set; }
        public DbSet<Status> Status { get; set; }
        public DbSet<Thumbnail> Thumbnails { get; set; }
        public DbSet<Vendor> Vendors { get; set; }
    }
}
