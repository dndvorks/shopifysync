﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Location", Schema = "shopworks")]
    public class Location : BaseShopworks
    {
        public string CompanyName { get; set; }
        public string LocationName { get; set; }
        public string PhoneMain { get; set; }
        public string EmailMain { get; set; }
        public string PhoneTollFree { get; set; }
        public string WebURL { get; set; }
    }
}
