﻿using log4net;
using System;
using System.Data;
using System.Data.Odbc;
using System.Linq;

namespace HauffSports.Common.Services
{
    public class BaseService
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public BaseService()
        {
        }

        public void GetDatabaseSchema(string database, OdbcConnection connection)
        {
            log.Info(database + " Schema");
            using (var cmd = new OdbcCommand("", connection))
            {
                cmd.Connection.Open();
                cmd.Connection.GetSchema("Tables").AsEnumerable().Select(r => r.Field<string>(2)).ToList().ForEach(r => log.Info(Convert.ToString(r)));
            }
        }

        public void GetTableSchema(string table, OdbcConnection connection)
        {
            log.Info(table + " Schema");
            using (var cmd = new OdbcCommand("SELECT * FROM " + table, connection))
            {
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.SchemaOnly))
                {
                    var tableSchema = reader.GetSchemaTable();
                    foreach (DataRow row in tableSchema.Rows)
                        log.Info(Convert.ToString(row["ColumnName"]));
                }
            }
        }
    }
}