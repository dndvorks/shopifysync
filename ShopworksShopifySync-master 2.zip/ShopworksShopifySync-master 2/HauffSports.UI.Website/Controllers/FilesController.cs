﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HauffSports.UI.Website.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HauffSports.UI.Website.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FilesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public FilesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("Download/{id}")]
        public IActionResult Download(string id)
        {
            var file = _context.Files.Where(f => f.Id == id).FirstOrDefault();

            if (file != null)
            {
                return File(file.Data, file.ContentType, file.Name);
            }

            return NotFound();
        }

        [HttpPost]
        [Route("Upload")]
        public IActionResult Upload(IFormCollection collection)
        {
            var files = collection.Files.Select((f, j) =>
            {
                using (var stream = f.OpenReadStream())
                {
                    var fileModel = new Models.File()
                    {
                        Name = f.FileName,
                        ContentType = f.ContentType,
                        Data = new byte[stream.Length]
                    };
                    var bytesRead = stream.Read(fileModel.Data);

                    return fileModel;
                }
            }).ToList();

            _context.Files.AddRange(files);
            _context.SaveChanges();

            return CreatedAtAction("Download", files);
        }
    }
}