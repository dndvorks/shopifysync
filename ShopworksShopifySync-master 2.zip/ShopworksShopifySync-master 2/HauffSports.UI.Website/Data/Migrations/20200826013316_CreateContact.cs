﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class CreateContact : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "CustomerOrderedBy",
                newName: "CustomerFirstName",
                table: "SalesOrders");

            migrationBuilder.AddColumn<bool>(
                name: "CreateContact",
                table: "SalesOrders",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "CustomerLastName",
                table: "SalesOrders",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreateContact",
                table: "SalesOrders");

            migrationBuilder.RenameColumn(
                name: "CustomerFirstName",
                newName: "CustomerOrderedBy",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "CustomerLastName",
                table: "SalesOrders");
        }
    }
}
