﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("OrderDesignLocation", Schema = "shopworks")]
    public class OrderDesignLocation : BaseShopworks
    {
        public string OrderId { get; set; }
        public Order Order { get; set; }

        public string OrderDesignId { get; set; }
        public OrderDesign OrderDesign { get; set; }

        public string DesignLocationId { get; set; }
        public DesignLocation DesignLocation { get; set; }

        public string Location { get; set; }
    }
}

