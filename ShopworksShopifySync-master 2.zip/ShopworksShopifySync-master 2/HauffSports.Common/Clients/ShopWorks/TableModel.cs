﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Linq;

namespace HauffSports.Common.Clients.ShopWorks
{
    public partial class TableModel
    {
        [JsonProperty("Tables")]
        public Table[] Tables { get; set; }

        public static TableModel FromJson(string json) => JsonConvert.DeserializeObject<TableModel>(json);
    }

    public partial class Table
    {
        [JsonProperty("SrcName")]
        public string SrcName { get; set; }

        [JsonProperty("DstName")]
        public string DstName { get; set; }

        [JsonProperty("Connection")]
        public string Connection { get; set; }

        [JsonProperty("Fields")]
        public string[][] Fields { get; set; }

        [DefaultValue("timestamp_Modification")]
        [JsonProperty("LastUpdated", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string LastUpdated { get; set; }

        [DefaultValue("")]
        [JsonProperty("Where", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Where { get; set; }

        [DefaultValue("")]
        [JsonProperty("GroupBy", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string GroupBy { get; set; }

        [DefaultValue(new string[0])]
        [JsonProperty("Clean", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string[] Clean { get; set; }
    }
}
