﻿using HauffSports.Common.Enums;
using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using HauffSports.Common.Mappers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace HauffSports.Common.Clients.Shopify
{
    public class ShopifyCustomerClient : ShopifyBaseClient
    {
        public ShopifyCustomerClient(string apiPublicKey, string apiSecretKey, string url) : base(apiPublicKey, apiSecretKey, url)
        {
        }

        /// <summary>
        ///     Gets a shopify customer for a specific customer id.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetCustomerResponse</returns>
        public GetCustomerResponse GetCustomer(GetRecordRequest request)
        {
            try
            {
                var response = new GetCustomerResponse();
                
                var baseResponse = GetRecord(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                response.Customer = Mappers.ShopifyMapper.Map<CustomerModel>(baseResponse.Data);
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomerResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets a shopify customer for specific values.
        /// </summary>
        /// <param name="request">GetRecordByQueryRequest</param>
        /// <returns>GetCustomerResponse</returns>
        public GetCustomerResponse GetCustomerByQuery(GetRecordByQueryRequest request)
        {
            try
            {
                var response = new GetCustomerResponse();
                
                request.ResourceType = ShopifyResourceType.customers;

                var baseResponse = GetRecordByQuery(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                var customers = ShopifyMapper.MapToList<CustomerModel>(baseResponse.Data, request.ResourceType);

                response.Customer = customers[0];
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomerResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets all of the shopify customers for a certain date range.
        /// </summary>
        /// <param name="request">GetRecordsRequest</param>
        /// <returns>GetCustomersResponse</returns>
        public GetCustomersResponse GetCustomers(GetRecordsRequest request)
        {
            try
            {                
                var baseResponse = GetRecords(request);
                if (!baseResponse.IsSuccess)
                {
                    throw new ApplicationException(baseResponse.ErrorMessage);
                }

                var response = baseResponse.Data.ToObject<GetCustomersResponse>();
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomersResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets a shopify metafields specific customer id.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetCustomerMetafiledsResponse</returns>
        public GetCustomerMetafiledsResponse GetCustomerMetafields(GetRecordRequest request)
        {
            try
            {
                var response = new GetCustomerMetafiledsResponse();
                
                request.ResourceType = ShopifyResourceType.customers;

                var baseResponse = GetMetafieldRecords(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);

                response.Metafields = ShopifyMapper.MapToList<ShopifyMetafieldModel>(baseResponse.Data, ShopifyResourceType.metafields);
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetCustomerMetafiledsResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates or updates a shopify customer.
        /// </summary>
        /// <param name="request">SaveCustomerRequest</param>
        /// <returns>SaveCustomerResponse</returns>
        public SaveCustomerResponse SaveCustomer(SaveCustomerRequest request)
        {
            try
            {
                var response = new SaveCustomerResponse();
                
                var baseRequest = new SaveRecordRequest { ResourceType = ShopifyResourceType.customers };

                if (request.Customer.Id == 0)
                {
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    var baseResponse = AddRecord(baseRequest);
                    if (!baseResponse.IsSuccess)
                        throw new ApplicationException(baseResponse.ErrorMessage);
                    response.Customer = ShopifyMapper.Map<CustomerModel>(baseResponse.Data["customer"]);
                }
                else
                {
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.RecordId = request.Customer.Id;
                    var baseResponse = UpdateRecord(baseRequest);
                    if (!baseResponse.IsSuccess)
                        throw new ApplicationException(baseResponse.ErrorMessage);
                    response.Customer = ShopifyMapper.Map<CustomerModel>(baseResponse.Data["customer"]);
                }

                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new SaveCustomerResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new SaveCustomerResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Creates or updates a shopify customer metafield.
        /// </summary>
        /// <param name="request">SaveCustomerMetafieldRequest</param>
        /// <returns>SaveCustomerMetafieldResponse</returns>
        public SaveCustomerMetafieldResponse SaveCustomerMetafield(SaveCustomerMetafieldRequest request)
        {
            try
            {
                var response = new SaveCustomerMetafieldResponse();
                
                var baseRequest = new SaveRecordRequest();
                baseRequest.ResourceType = ShopifyResourceType.customers;

                if (request.CustomerMetafield.Id == 0)
                {        
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.ExtendedUrl = "/" + request.CustomerId + "/metafields";
                    var baseResponse = AddRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                    response.CustomerMetafield = ShopifyMapper.Map<ShopifyMetafieldModel>(baseResponse.Data["metafield"]);
                }
                else
                {
                    baseRequest.PostData = JObject.Parse(JsonConvert.SerializeObject(request)).ToString();
                    baseRequest.RecordId = request.CustomerMetafield.Id;
                    var baseResponse = UpdateRecord(baseRequest);
                    if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                    response.CustomerMetafield = ShopifyMapper.Map<ShopifyMetafieldModel>(baseResponse.Data["metafield"]);
                }

                response.IsSuccess = true;
                return response;
            }
            catch (WebException wex)
            {
                var resp = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                return new SaveCustomerMetafieldResponse { ErrorMessage = resp };
            }
            catch (Exception ex)
            {
                return new SaveCustomerMetafieldResponse { ErrorMessage = ex.Message };
            }
        }
    }
}