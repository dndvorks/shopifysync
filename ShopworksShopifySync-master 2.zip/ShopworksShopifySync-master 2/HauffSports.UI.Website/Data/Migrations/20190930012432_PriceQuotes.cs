﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class PriceQuotes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                table: "SalesOrders",
                nullable: false,
                defaultValue: DateTime.UtcNow);

            migrationBuilder.AddColumn<DateTime>(
                name: "DeletedAt",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "SentAt",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Shipping",
                table: "SalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedAt",
                table: "SalesOrders",
                nullable: false,
                defaultValue: DateTime.UtcNow);

            migrationBuilder.AddColumn<string>(
                name: "AdjustedCost",
                table: "SalesOrderProduct",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AdjustedPrice",
                table: "SalesOrderProduct",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedAt",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "DeletedAt",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "SentAt",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "Shipping",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "UpdatedAt",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "AdjustedCost",
                table: "SalesOrderProduct");

            migrationBuilder.DropColumn(
                name: "AdjustedPrice",
                table: "SalesOrderProduct");
        }
    }
}
