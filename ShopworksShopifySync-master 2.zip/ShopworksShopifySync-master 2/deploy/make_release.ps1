Remove-Item "release" -Recurse -ErrorAction Ignore

New-Item -ItemType directory -Path "release\Sync\ShopifySync"
Copy-item -Force -Recurse "..\HauffSports.Sync.Shopify\bin\Release\net5.0\*" -Destination "release\Sync\ShopifySync"

New-Item -ItemType directory -Path "release\Sync\WebSync"
Copy-item -Force -Recurse "..\HauffSports.Sync.Web\bin\Release\net5.0\*" -Destination "release\Sync\WebSync"

New-Item -ItemType directory -Path "release\Sync\MailSync"
Copy-item -Force -Recurse "..\HauffSports.Sync.Mailman\bin\Release\net5.0\*" -Destination "release\Sync\MailSync"

New-Item -ItemType directory -Path "release\Sync\Service"
Copy-item -Force -Recurse "..\HauffSports.Sync.Service\bin\Release\net5.0\*" -Destination "release\Sync\Service"

New-Item -ItemType directory -Path "release\Tools\ShopifyTool"
Copy-item -Force -Recurse "..\HauffSports.Console\bin\Release\net5.0-windows\*" -Destination "release\Tools\ShopifyTool"

Compress-Archive -Path "release\Sync\ShopifySync" -DestinationPath "release\ShopifySync.zip"
Compress-Archive -Path "release\Sync\WebSync" -DestinationPath "release\WebSync.zip"
Compress-Archive -Path "release\Sync\MailSync" -DestinationPath "release\MailSync.zip"
Compress-Archive -Path "release\Sync\Service" -DestinationPath "release\Service.zip"
Compress-Archive -Path "release\Tools\ShopifyTool" -DestinationPath "release\ShopifyTool.zip"
