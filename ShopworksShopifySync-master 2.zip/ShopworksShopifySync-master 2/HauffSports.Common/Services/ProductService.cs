﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using HauffSports.Common.Enums;
using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses;
using HauffSports.Common.Clients.Shopify;
using HauffSports.Common.Clients.ShopWorks;
using System.Threading;
using System.IO;

namespace HauffSports.Common.Services
{
    public class ProductService : BaseService
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private ShopWorksProductClient _shopWorksProductService { get; set; }
        private ShopifyProductClient _shopifyProductService { get; set; }
        private CollectionClient _collectionClient { get; set; }

        public ProductService(
            string shopworksConnectionString,
            string onSiteImagePath,
            bool useAlternatePrice,
            string shopifyPublicKey,
            string shopifySecretKey,
            string shopifyUrl
            ) : base()
        {
            this._shopWorksProductService = new ShopWorksProductClient(
                shopworksConnectionString, 
                onSiteImagePath, 
                useAlternatePrice
            );

            this._shopifyProductService = new ShopifyProductClient(shopifyPublicKey, shopifySecretKey, shopifyUrl);
            this._collectionClient = new CollectionClient(shopifyPublicKey, shopifySecretKey, shopifyUrl);
        }

        public void SyncProducts(ManualResetEvent stopRequest, bool forceUpdate = false)
        {
            log.Info("Started Syncing Products");

            var locations = this.GetLocationList();
            var customCollections = this.GetCustomCollectionList();
            var collects = this.GetCollectList();
            var smartCollections = this.GetSmartCollectionList();
            var shopifyProducts = this.GetProductList();
            var shopworksProducts = this.GetShopworksProductList(stopRequest);

            log.Info("Determining Change Set");
            
            var productsToDelete = new HashSet<long>();

            var nonMatchingProducts = shopifyProducts.Where(
                p => !shopworksProducts.Any(p1 => p1.PartNumber.Equals(p.PartNumber, StringComparison.CurrentCultureIgnoreCase))).ToList();
            productsToDelete.UnionWith(nonMatchingProducts.Select(p => p.Id).ToList());
            shopifyProducts.RemoveAll(p => productsToDelete.Contains(p.Id));

            var variantInventory = new List<KeyValuePair<long, int>>();

            foreach (var product in shopworksProducts)
            {
                if (stopRequest != null && stopRequest.WaitOne(0))
                {
                    log.Warn("Stop Requested");
                    return;
                }

                UpdateProduct(product, shopifyProducts, locations, productsToDelete, customCollections, collects, smartCollections, forceUpdate);
            }

            log.InfoFormat("Deleting {0} products from Shopify", productsToDelete.Count);

            DeleteProducts(productsToDelete, stopRequest);

            log.Info("Finished syncing products from Shopworks");
        }

        public void SyncProduct(string partNumber, bool forceUpdate=false)
        {
            if (string.IsNullOrEmpty(partNumber))
            {
                throw new ApplicationException("Part number is empty");
            }

            log.InfoFormat("Started Syncing Product [PartNumber: {0}]", partNumber);

            var locations = this.GetLocationList();
            var customCollections = this.GetCustomCollectionList();
            var collects = this.GetCollectList();
            var smartCollections = this.GetSmartCollectionList();
            var shopifyProducts = this.GetProductList();
            var productsToDelete = new HashSet<long>();

            log.InfoFormat("Getting product from Shopworks [PartNumber: {0}]", partNumber);

            var response = this._shopWorksProductService.GetProduct(new GetProductRequest { PartNumber = partNumber });

            if (!response.IsSuccess)
            {
                throw new ApplicationException("Get Product Error [Error :" + response.ErrorMessage + "]");
            }

            log.Info(response.Products.Count.ToString() + " products received from Shopworks");

            foreach (var product in response.Products)
            {
                UpdateProduct(product, shopifyProducts, locations, productsToDelete, customCollections, collects, smartCollections, forceUpdate);
            }

            log.InfoFormat("Deleting {0} products from Shopify", productsToDelete.Count);

            DeleteProducts(productsToDelete);

            log.Info("Finished syncing product from Shopworks");
        }

        private void UpdateProduct(
            ProductModel product, 
            List<ProductModel> shopifyProducts, 
            List<long> locations, 
            HashSet<long> productsToDelete, 
            List<CustomCollectionModel> customCollections,
            List<CollectModel> collects,
            List<SmartCollectionModel> smartCollections,
            bool forceUpdate)
        {
            if (product.Variants.Count() > 100)
            {
                log.WarnFormat("Limiting Variants to 100 [NumVariants: {0}, PartNumber: {1}]", product.Variants.Count(), product.PartNumber);
                product.Variants = product.Variants.GetRange(0, 100);
            }

            var tags = new HashSet<string>();
            tags.UnionWith(product.Tags.Split(',').Select(s => s.Trim()).Where(s => !string.IsNullOrEmpty(s)));
            tags.UnionWith(product.Options.SelectMany(o => o.Values).Select(s => s.Trim()).Where(s => !string.IsNullOrEmpty(s)));
            tags.UnionWith(product.Metafields.Where(m => !(m.Key.Contains("price") || m.Key.Contains("days"))).Select(m => m.Value.Trim()).Where(s => !string.IsNullOrEmpty(s)));
            product.Tags = string.Join(",", tags.Select(t => t)).Trim().Trim(',');

            var matchingProducts = shopifyProducts.Where(p => product.PartNumber.Equals(p.PartNumber, StringComparison.CurrentCultureIgnoreCase)).ToList();
            var shopifyProduct = matchingProducts.FirstOrDefault();

            // if we have one or more matching products, we will update the existing product
            if (shopifyProduct != null)
            {
                product.Id = shopifyProduct.Id;

                var updateProduct = forceUpdate;

                var shopifyTags = new HashSet<string>();
                shopifyTags.UnionWith(shopifyProduct.Tags.Split(',').Select(s => s.Trim()).Where(s => !string.IsNullOrEmpty(s)));

                if (!shopifyTags.SetEquals(tags))
                {
                    updateProduct = true;
                }

                foreach (var variant in product.Variants)
                {
                    var shopifyVariant = shopifyProduct.Variants.FirstOrDefault(v => v.Sku.Equals(variant.Sku, StringComparison.CurrentCultureIgnoreCase));
                    if (shopifyVariant != null)
                    {
                        variant.Id = shopifyVariant.Id;

                        if (variant.Price != shopifyVariant.Price || variant.Taxable != shopifyVariant.Taxable)
                        {
                            updateProduct = true;
                        }
                    }
                    else
                    {
                        updateProduct = true;
                    }
                }

                if (updateProduct ||
                    shopifyProduct.ProductType != product.ProductType ||
                    shopifyProduct.Title != product.Title)
                {
                    product.Metafields.Clear();
                    shopifyProduct = SaveProduct(product);
                }

                foreach (var variant in product.Variants)
                {
                    var shopifyVariant = shopifyProduct.Variants.FirstOrDefault(v => v.Sku.Equals(variant.Sku, StringComparison.CurrentCultureIgnoreCase));
                    if (shopifyVariant != null)
                    {
                        if (forceUpdate || variant.InventoryQuantity != shopifyVariant.InventoryQuantity)
                        {
                            UpdateInventory(locations[0], shopifyVariant.InventoryItemId, variant.InventoryQuantity);
                            log.InfoFormat("Updated Inventory [Variant: {0}, OldQuantity: {1}, NewQuantity: {2}]",
                                variant.Sku, shopifyVariant.InventoryQuantity, variant.InventoryQuantity);
                        }
                    }
                }

                matchingProducts.RemoveAt(0);
                productsToDelete.UnionWith(matchingProducts.Select(p => p.Id).ToList());
                shopifyProducts.RemoveAll(p => productsToDelete.Contains(p.Id));
            }
            else
            {
                shopifyProduct = SaveProduct(product);
            }

            if (product.Id > 0)
            {
                SaveProductCollections(product, customCollections, collects, smartCollections);
            }
        }
        
        private ProductModel SaveProduct(ProductModel product)
        {
            var updated = (product.Id != 0);

            product.Images = new List<ProductImageModel>();

            foreach (var url in product.ImageUrls)
            {
                try
                {
                    product.Images.Add(
                        new ProductImageModel 
                        { 
                            Attachment = Convert.ToBase64String(
                                File.ReadAllBytes(url)
                            ) 
                        }
                    );
                }
                catch (Exception e)
                {
                    log.ErrorFormat("Failed to open image [FileName: {0}, Error: {1}]", url, e.GetType().ToString());
                }
            }

            var response = _shopifyProductService.SaveProduct(new SaveProductRequest { Product = product });

            if (!response.IsSuccess)
            {
                this.LogProduct(product, response.ErrorMessage, true);
            }
            else
            {
                log.InfoFormat("{0} product [Title: {1}, PartNumber: {2}]", updated ? "Updated" : "Saved", product.Title, product.PartNumber);
            }

            product.Id = response.Product.Id;

            return response.Product;
        }

        private ProductVariantModel SaveProductVariant(long productId, ProductVariantModel variant)
        {
            var response = _shopifyProductService.SaveProductVariant(new SaveProductVariantRequest { ProductId = productId, ProductVariant = variant });
            if (response.IsSuccess)
            {
                log.Info("-- Product variant " + variant.Sku + " saved successfully");
            }
            else
            {
                log.Info("-- Product variant " + variant.Sku + " error: " + response.ErrorMessage);
            }

            return response.ProductVariant;
        }

        public void SaveProductMetaFields(ProductModel product)
        {
            foreach (var metafield in product.Metafields)
            {
                var response = _shopifyProductService.SaveProductMetafield(
                        new SaveProductMetafieldRequest { ProductId = product.Id, ProductMetafield = metafield }
                    );

                if (response.IsSuccess)
                {
                    log.Info("-- Product metafield " + metafield.Key + " : " + metafield.Value + " saved successfully");
                }
                else
                {
                    log.Info("-- Product metafield " + metafield.Key + " : " + metafield.Value + " error: " + response.ErrorMessage);
                }
            }
        }

        public void SaveProductCollections(ProductModel product, List<CustomCollectionModel> collections, List<CollectModel> collects, List<SmartCollectionModel> smartCollections)
        {
            foreach (var metafield in product.Metafields)
            {
                // category
                // Equipment Any item that has EQUIPMENT in the PRODUCT CLASS field
                // Footwear Any item that has FOOTWEAR in the PRODUCT CLASS field
                // Apparel Any item that has APPAREL in the PRODUCT CLASS field

                // preprint_group
                // Team Stores Any item that has a value in the PREPRINT GROUP field(these will be the individual web stores we set up for high schools, etc)

                // Brands This will be taken from the information in the PART NUMBER field in PRODUCT file or the information in the CUSTOM field #10 IN VENDOR FILE
                // NOT SURE WHAT THIS MEANS

                // find_code
                // Clearance if FIND CODE field in product file = CLEARANCE

                var key = metafield.Key;
                var value = metafield.Value.Trim();

                if (key.Equals("sub_category") ||
                    key.Equals("category") ||
                    key.Equals("preprint_group") ||
                    key.Equals("find_code"))
                {
                    this.SaveCustomCollection(product, value, collections, collects);
                }
                else if (key.Equals("gender"))
                {
                    // Men Any item that has ADULT in the GENDER field
                    if (value.Equals("Adult", StringComparison.CurrentCultureIgnoreCase))
                    {
                        this.SaveCustomCollection(product, "Men", collections, collects);
                    }
                    // Ladies Any item that has LADIES in the GENDER field
                    else if (value.Equals("Ladies", StringComparison.CurrentCultureIgnoreCase))
                    {
                        this.SaveCustomCollection(product, "Ladies", collections, collects);
                    }
                    // Youth Any item that has YOUTH in the GENDER field
                    else if (value.Equals("Youth", StringComparison.CurrentCultureIgnoreCase))
                    {
                        this.SaveCustomCollection(product, "Youth", collections, collects);
                    }
                }
            }

            SaveSmartCollection(product, smartCollections);
        }

        public void DeleteProducts(HashSet<long> productIds, ManualResetEvent stopRequest = null)
        {
            foreach (var productId in productIds)
            {
                if (stopRequest != null && stopRequest.WaitOne(0))
                {
                    log.Warn("Stop Requested");
                    return;
                }

                var response = _shopifyProductService.DeleteProduct(new DeleteProductRequest { ProductId = productId } );
                if (!response.IsSuccess)
                {
                    log.ErrorFormat("Failed to delete product [Id: {0}]", productId);
                }
                else
                {
                    log.InfoFormat("Deleted product [Id: {0}]", productId);
                }
            }
        }

        private List<CustomCollectionModel> GetCustomCollectionList()
        {
            log.Info("Getting custom collections from Shopify");

            var response = _collectionClient.GetCustomCollections(new GetRecordsRequest());

            if (!response.IsSuccess)
            {
                throw new ApplicationException(response.ErrorMessage);
            }

            log.Info(response.Collections.Count.ToString() + " custom collections received from Shopify");

            return response.Collections;
        }

        private List<CollectModel> GetCollectList()
        {
            log.Info("Getting collects from Shopify");

            var response = _collectionClient.GetCollects(new GetRecordsRequest());

            if (!response.IsSuccess)
            {
                throw new ApplicationException(response.ErrorMessage);
            }

            log.Info(response.Collects.Count.ToString() + " collects received from Shopify");

            return response.Collects;
        }

        private List<SmartCollectionModel> GetSmartCollectionList()
        {
            log.Info("Getting smart collections from Shopify");

            var response = _collectionClient.GetSmartCollections(new GetRecordsRequest());

            if (!response.IsSuccess)
            {
                throw new ApplicationException(response.ErrorMessage);
            }

            log.Info(response.Collections.Count.ToString() + " smart collections received from Shopify");

            return response.Collections;
        }

        private List<ProductModel> GetProductList()
        {
            log.Info("Getting products from Shopify");

            var response = _shopifyProductService.GetProducts(new GetRecordsRequest
            {
                ResourceType = ShopifyResourceType.products,
            });

            if (!response.IsSuccess)
            {
                throw new ApplicationException(response.ErrorMessage);
            }

            log.Info(response.Products.Count.ToString() + " products received from Shopify");

            return response.Products;
        }

        private List<long> GetLocationList()
        {
            log.Info("Getting locations from Shopify");

            var response = _shopifyProductService.GetRecords(new GetRecordsRequest
            {
                ResourceType = ShopifyResourceType.locations,
            });

            if (!response.IsSuccess)
            {
                throw new ApplicationException(response.ErrorMessage);
            }

            log.Info(response.Data["locations"].Count() + " locations received from Shopify");

            return response.Data["locations"].Select(l => (long)l["id"]).ToList();
        }

        private void UpdateInventory(long locationId, long inventoryItemId, int quantity)
        {
            var response = _shopifyProductService.AddRecord(new SaveRecordRequest
            {
                ResourceType = ShopifyResourceType.inventory_levels,
                ExtendedUrl = "/set",
                PostData = "{\"location_id\": " + locationId + ", \"inventory_item_id\": " + inventoryItemId + ", \"available\": " + quantity + "}"
            });

            if (!response.IsSuccess)
            {
                throw new ApplicationException(response.ErrorMessage);
            }
        }

        private List<ProductModel> GetShopworksProductList(ManualResetEvent stopRequest)
        {
            log.Info("Getting products from ShopWorks");

            var response = this._shopWorksProductService.GetProducts(new GetProductsRequest(), stopRequest);

            if (!response.IsSuccess)
            {
                throw new ApplicationException("[Get Products Error: " + response.ErrorMessage + "]");
            }

            log.Info(response.Products.Count.ToString() + " products received from ShopWorks");

            return response.Products;
        }

        private void SaveCustomCollection(ProductModel product, string category, List<CustomCollectionModel> collections, List<CollectModel> collects)
        {
            try
            {
                if (string.IsNullOrEmpty(category))
                {
                    log.Info("-- Category value is null or empty");
                }
                var collection = collections.FirstOrDefault(c => c.Title.Equals(category, StringComparison.CurrentCultureIgnoreCase));
                if (collection == null)
                {
                    var customCollection = new CustomCollectionCreateModel { Title = category };
                    var saveCustomCollectionRequest = new SaveCustomCollectionRequest { Collection = customCollection};
                    var createCollectionResponse = _collectionClient.SaveCustomCollection(saveCustomCollectionRequest);
                    if (!createCollectionResponse.IsSuccess)
                    {
                        throw new ApplicationException("[CustomCollection: " + category + "][CustomCollection Error: " + createCollectionResponse.ErrorMessage + "]");
                    }

                    log.Info("-- Category " + category + " was added to custom collection");
                    collections.Add(createCollectionResponse.Collection);
                    collection = createCollectionResponse.Collection;
                }
                this.SaveCollect(collection.Id, product.Id, category, collects);
            }
            catch (Exception ex)
            {
                log.Error("-- Save collection error [Error: " + ex.Message + "]");
            }
        }

        private void SaveCollect(long collectionId, long productId, string category, List<CollectModel> collects)
        {
            try
            {
                var collect = collects.FirstOrDefault(c => c.ProductId == productId && c.CollectionId == collectionId);
                if (collect == null)
                {
                    var saveCollectRequest = new SaveCollectRequest { CollectionId = collectionId, ProductId = productId };
                    var saveCollectResponse = _collectionClient.SaveCollect(saveCollectRequest);
                    if (!saveCollectResponse.IsSuccess)
                    {
                        throw new ApplicationException("[CollectionId: " + collectionId.ToString() + "][ProductId: " + productId.ToString() + "][Error: " + saveCollectResponse.ErrorMessage + "]");
                    }

                    log.Info("-- Product was saved to collection " + category);
                    collects.Add(saveCollectResponse.Collect);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("-- Error saving product to collection {0} [Error: {1}]", category, ex.Message);
            }
        }

        private void SaveSmartCollection(ProductModel product, List<SmartCollectionModel> collections)
        {
            try
            {
                if (!String.IsNullOrEmpty(product.ProductType))
                {
                    var exists = collections.Exists(
                        c => (
                            c.Title == product.ProductType &&
                            c.Rules.Count == 1 &&
                            c.Rules[0].Column == "type" &&
                            c.Rules[0].Relation == "equals" &&
                            c.Rules[0].Condition == product.ProductType
                        )
                    );

                    if (!exists)
                    {
                        var request = new SaveSmartCollectionRequest();
                        request.Collection.Title = product.ProductType;
                        request.Collection.Rules.Add(
                            new SmartCollectionModel.Rule
                            {
                                Column = "type",
                                Relation = "equals",
                                Condition = product.ProductType
                            }
                        );

                        var response = _collectionClient.SaveSmartCollection(request);
                        if (!response.IsSuccess)
                        {
                            throw new ApplicationException("[ProductType: " + product.ProductType.ToString() + "][Error: " + response.ErrorMessage + "]");
                        }

                        log.Info("-- Smart Collection was saved: " + product.ProductType);
                        collections.Add(response.Collection);
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error("-- Save collection error [Error: " + ex.Message + "]");
            }
        }

        private void LogProduct(ProductModel product, string message, bool isError = false)
        {
            try
            {
                var msg = "";
                if (!string.IsNullOrEmpty(product.PartNumber)) msg += "[Part Number: " + product.PartNumber + "]";
                if (!string.IsNullOrEmpty(product.Title)) msg += "[Title: " + product.Title + "]";
                if (isError) log.Info(msg + "[Product Error: " + message + "]");
                else log.Info(msg + "[" + message + "]");
            }
            catch (Exception) { }
        }
    }
}