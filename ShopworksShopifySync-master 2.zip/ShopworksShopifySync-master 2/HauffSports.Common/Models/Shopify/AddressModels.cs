﻿using Newtonsoft.Json;

namespace HauffSports.Common.Models.Shopify
{
    public class AddressCreateModel
    {
        public AddressCreateModel()
        {
            this.Id = 0;
            this.FirstName = string.Empty;
            this.LastName = string.Empty;
            //this.PhoneNumber = string.Empty;
            this.Address1 = string.Empty;
            this.Address2 = string.Empty;
            this.City = string.Empty;
            this.Province = string.Empty;
            this.ZipCode = string.Empty;
            this.Country = string.Empty;
            this.IsDefault = false;
        }
        [JsonProperty(PropertyName = "id")]
        public long Id { get; set; }
        [JsonProperty(PropertyName = "first_name")]
        public string FirstName { get; set; }
        [JsonProperty(PropertyName = "last_name")]
        public string LastName { get; set; }
        //[JsonProperty(PropertyName = "phone")]
        //public string PhoneNumber { get; set; }
        [JsonProperty(PropertyName = "address1")]
        public string Address1 { get; set; }
        [JsonProperty(PropertyName = "address2")]
        public string Address2 { get; set; }
        [JsonProperty(PropertyName = "city")]
        public string City { get; set; }
        [JsonProperty(PropertyName = "province")]
        public string Province { get; set; }
        [JsonProperty(PropertyName = "phone")]
        public string ZipCode { get; set; }
        [JsonProperty(PropertyName = "zip")]
        public string Country { get; set; }
        [JsonProperty(PropertyName = "addresses")]
        public bool IsDefault { get; set; }
    }

    public class AddressModel : BaseModel
    {
        public AddressModel()
        {
            this.CustomerId = 0;
            this.Name = string.Empty;
            this.FirstName = string.Empty;
            this.LastName = string.Empty;
            this.Company = string.Empty;
            this.PhoneNumber = string.Empty;
            this.Address1 = string.Empty;
            this.Address2 = string.Empty;
            this.City = string.Empty;
            this.Province = string.Empty;
            this.ProvinceCode = string.Empty;
            this.ZipCode = string.Empty;
            this.Country = string.Empty;
            this.CountryCode = string.Empty;
            this.CountryName = string.Empty;
            this.Latitude = 0.0m;
            this.Longitude = 0.0m;
            this.IsDefault = false;
        }

        public long CustomerId { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string PhoneNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public string ProvinceCode { get; set; }
        public string ZipCode { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public bool IsDefault{ get; set; }
    }
}