﻿using Dropbox.Api;
using Dropbox.Api.Files;
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace HauffSports.Common.Helpers
{
    public class DropboxHelper
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public DropboxClient Client { get; private set; }
        public string FolderPath { get; private set; }

        /// <summary>
        /// Declares a new dropnet client.
        /// </summary>
        /// <param name="_folderPath">The folder path that will be used.</param>
        public DropboxHelper(string accessToken, string folderPath)
        {
            // access token from curt's dropbox account app called ShopifyOrders
            Client = new DropboxClient(accessToken);
            FolderPath = folderPath.TrimEnd('/');

            try
            {
                log.InfoFormat("Looking for folder [FolderPath: {0}]", FolderPath);

                //Client.Files.DeleteV2Async(FolderPath.TrimEnd('/')).Wait();
                Client.Files.GetMetadataAsync(FolderPath).Wait();

                log.InfoFormat("Found folder [FolderPath: {0}]", FolderPath);
            }
            catch (Exception ex)
            {
                log.Error(ex.ToString());

                log.InfoFormat("Creating folder [FolderPath: {0}]", FolderPath);

                Client.Files.CreateFolderV2Async(FolderPath).Wait();

                log.InfoFormat("Created folder [FolderPath: {0}]", FolderPath);
            }
        }

        /// <summary>
        /// Deletes all files in the specified folder
        /// </summary>
        /// <returns>A bool value if all files were successfully deleted.</returns>
        public void DeleteAllFilesInFolder()
        {
            log.InfoFormat("Deleting files in folder [FolderPath: {0}]", FolderPath);

            var filesResult = Client.Files.ListFolderAsync(FolderPath).Result;
            foreach (var file in filesResult.Entries)
            {
                Client.Files.DeleteV2Async(FolderPath + "/" + file.Name).Wait();

                log.InfoFormat("Deleted file [Filename: {0}]", FolderPath + "/" + file.Name);
            }

            log.InfoFormat("Deleted files in folder [FolderPath: {0}]", FolderPath);
        }

        /// <summary>
        /// Uploads a new file to the specified path
        /// </summary>
        /// <param name="fileName">The file name to be uploaded.</param>
        /// <param name="fileData">The file byte array to be uploaded.</param>
        /// <returns>A bool value if the file was successfully uploaded.</returns>
        public void UploadFile(string fileName, byte[] fileData)
        {
            log.InfoFormat("Uploading file [Filename: {0}]", FolderPath + "/" + fileName);

            using (var stream = new MemoryStream(fileData))
            {
                Client.Files.UploadAsync(FolderPath + "/" + fileName, WriteMode.Overwrite.Instance, body: stream).Wait();
            }

            log.InfoFormat("Uploaded file [Filename: {0}]", FolderPath + "/" + fileName);
        }

        /// <summary>
        /// Downloads a file from dropbox
        /// </summary>
        /// <param name="fileName">The file name to download</param>
        /// <returns>byte[]</returns>
        public byte[] DownloadFile(string fileName)
        {
            log.InfoFormat("Downloading file [Filename: {0}]", FolderPath + "/" + fileName);

            var result = Client.Files.DownloadAsync(FolderPath + "/" + fileName).Result;
            var fileArr = result.GetContentAsByteArrayAsync().Result;
            if (fileArr == null)
            {
                throw new ApplicationException("File does not exist.");
            }

            log.InfoFormat("Downloaded file [Filename: {0}]", FolderPath + "/" + fileName);

            return fileArr;
        }

        /// <summary>
        /// Updates the file in dropbox
        /// </summary>
        /// <param name="fileName">The file name to update</param>
        /// <param name="createFile">Whether or not to create the file if it does not exists.</param>
        /// <returns>bool</returns>
        public void UpdateFile(string fileName, byte[] fileData, bool createFile)
        {
            var file = GetAllFilesInFolder().FirstOrDefault(f => f.Equals(fileName, StringComparison.CurrentCultureIgnoreCase));
            if (file == null)
            {
                if (!createFile)
                {
                    throw new ApplicationException("File does not exist.");
                }

                log.InfoFormat("Creating new file [Filename: {0}]", FolderPath + "/" + fileName);

                using (var stream = new MemoryStream(fileData))
                {
                    Client.Files.UploadAsync(FolderPath + "/" + fileName, WriteMode.Overwrite.Instance, body: stream).Wait();
                }
            }
            else
            {
                log.InfoFormat("Updating file [Filename: {0}]", FolderPath + "/" + fileName);

                var downloadResult = Client.Files.DownloadAsync(FolderPath + "/" + fileName).Result;
                var currentArr = downloadResult.GetContentAsByteArrayAsync().Result;
                var newArr = currentArr.Concat(fileData).ToArray();
                using (var stream = new MemoryStream(newArr))
                {
                    Client.Files.UploadAsync(FolderPath + "/" + fileName, WriteMode.Overwrite.Instance, body: stream).Wait();
                }
            }
            
            log.InfoFormat("Uploaded file [Filename: {0}]", FolderPath + "/" + fileName);
        }

        /// <summary>
        /// Gets all files in the specified folder
        /// </summary>
        public List<string> GetAllFilesInFolder()
        {
            var filesResult = Client.Files.ListFolderAsync(FolderPath).Result;
            return filesResult.Entries.Where(f => f.IsFile).Select(f => f.Name).ToList();
        }

        /// <summary>
        /// Moves a file to a new folder location
        /// </summary>
        /// <returns>A bool value if all files were successfully moved.</returns>
        public void MoveFileToNewFolder(string fileName, string newPath)
        {
            var from = FolderPath + "/" + fileName;
            var to = FolderPath + "/" + newPath + fileName;
            Client.Files.MoveV2Async(from, to, autorename: true).Wait();
        }

        private byte[] Combine(params byte[][] arrays)
        {
            byte[] rv = new byte[arrays.Sum(a => a.Length)];
            int offset = 0;
            foreach (byte[] array in arrays)
            {
                System.Buffer.BlockCopy(array, 0, rv, offset, array.Length);
                offset += array.Length;
            }
            return rv;
        }
    }
}