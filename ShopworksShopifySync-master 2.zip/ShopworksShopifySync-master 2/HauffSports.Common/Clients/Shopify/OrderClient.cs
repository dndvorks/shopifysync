﻿using HauffSports.Common.Enums;
using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopifyRequestAndResponses;
using HauffSports.Common.Mappers;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Net;

namespace HauffSports.Common.Clients.Shopify
{
    public class ShopifyOrderClient : ShopifyBaseClient
    {
        public ShopifyOrderClient(string apiPublicKey, string apiSecretKey, string url) : base(apiPublicKey, apiSecretKey, url)
        {
        }

        /// <summary>
        ///     Gets a shopify order for a specific order id.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetOrderResponse</returns>
        public GetOrderResponse GetOrder(GetRecordRequest request)
        {
            try
            {
                var response = new GetOrderResponse();
                
                request.ResourceType = ShopifyResourceType.orders;
                var baseResponse = GetRecord(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                response.Order = ShopifyMapper.Map<ShopifyOrderModel>(baseResponse.Data["order"]);
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetOrderResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets a shopify order for specific values.
        /// </summary>
        /// <param name="request">GetRecordByQueryRequest</param>
        /// <returns>GetOrderResponse</returns>
        public GetOrderResponse GetOrderByQuery(GetRecordByQueryRequest request)
        {
            try
            {
                var response = new GetOrderResponse();
                
                request.ResourceType = ShopifyResourceType.orders;

                var baseResponse = GetRecordByQuery(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                var orders = ShopifyMapper.MapToList<ShopifyOrderModel>(baseResponse.Data, request.ResourceType);

                var name = request.SearchFields.FirstOrDefault(sf => sf.Key.Equals("name", StringComparison.CurrentCultureIgnoreCase)).Value;
                response.Order = orders.FirstOrDefault(o => o.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase));
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetOrderResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets the transactions for a shopify order for a specific order id.
        /// </summary>
        /// <param name="request">GetRecordRequest</param>
        /// <returns>GetOrderTransactionsResponse</returns>
        public GetOrderTransactionsResponse GetOrderTransactions(GetRecordRequest request)
        {
            try
            {
                var response = new GetOrderTransactionsResponse();
                
                string url = CreateUrl(ShopifyResourceType.orders) + "/" + request.RecordId.ToString() + "/transactions.json?";
                var webRequest = WebRequest.Create(url);
                SetBasicAuthHeader(webRequest, "GET");
                using (var dataResponse = webRequest.GetResponse())
                {
                    using (var reader = new StreamReader(dataResponse.GetResponseStream()))
                    {
                        AdjustForNextCall(dataResponse);
                        response.OrderTransactions = ShopifyMapper.MapToList<ShopifyOrderTransactionModel>(JObject.Parse(reader.ReadToEnd()), ShopifyResourceType.transactions);
                        response.IsSuccess = true;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                return new GetOrderTransactionsResponse { ErrorMessage = ex.Message };
            }
        }

        /// <summary>
        ///     Gets all of the shopify orders for a certain date range.
        /// </summary>
        /// <param name="request">GetRecordsRequest</param>
        /// <returns>GetOrdersResponse</returns>
        public GetOrdersResponse GetShopifyOrders(GetRecordsRequest request)
        {
            try
            {
                var response = new GetOrdersResponse();
                
                request.ResourceType = ShopifyResourceType.orders;
                var baseResponse = GetRecords(request);
                if (!baseResponse.IsSuccess) throw new ApplicationException(baseResponse.ErrorMessage);
                response.Orders = ShopifyMapper.MapToList<ShopifyOrderModel>(baseResponse.Data, request.ResourceType);
                response.IsSuccess = true;
                return response;
            }
            catch (Exception ex)
            {
                return new GetOrdersResponse { ErrorMessage = ex.Message };
            }
        }
    }
}