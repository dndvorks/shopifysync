﻿using System.Collections.Generic;

namespace HauffSports.UI.Website
{
    public class DropboxSettings
    {
        public string AccessToken { get; set; }
        public string Folder { get; set; }
    }

    public class ShopifySettings
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public string PublicKey { get; set; }
        public string SecretKey { get; set; }
        public DropboxSettings Dropbox { get; set; }
    }

    public class AppSettings
    {
        public string SendGridApiKey { get; set; }
        public string Shopworks { get; set; }
        public ICollection<ShopifySettings> ShopifyList { get; set; }
    }
}
