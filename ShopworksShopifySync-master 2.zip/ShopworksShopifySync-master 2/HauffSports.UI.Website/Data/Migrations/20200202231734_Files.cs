﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class Files : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "SalesOrderLogoFiles",
                newName: "Files");

            migrationBuilder.RenameColumn(
                table: "Files",
                name: "FileName",
                newName: "Name");

            migrationBuilder.AddColumn<string>(
                name: "ContentType",
                table: "Files",
                nullable: false,
                defaultValue: "application/octet-stream");

            migrationBuilder.CreateTable(
                name: "SalesOrderFile",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FileId = table.Column<string>(nullable: true),
                    SalesOrderLogoLocationId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalesOrderFile", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SalesOrderFile_Files_FileId",
                        column: x => x.FileId,
                        principalTable: "Files",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SalesOrderFile_SalesOrderLogoLocation_SalesOrderLogoLocationId",
                        column: x => x.SalesOrderLogoLocationId,
                        principalTable: "SalesOrderLogoLocation",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderFile_FileId",
                table: "SalesOrderFile",
                column: "FileId");

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderFile_SalesOrderLogoLocationId",
                table: "SalesOrderFile",
                column: "SalesOrderLogoLocationId");

            migrationBuilder.Sql(
                "INSERT INTO SalesOrderFile(FileId, SalesOrderLogoLocationId) " +
                "SELECT Id AS FileId, SalesOrderLogoLocationId FROM Files;");

            migrationBuilder.DropIndex(
                name: "IX_SalesOrderLogoFiles_SalesOrderLogoLocationId",
                table: "Files");

            migrationBuilder.DropForeignKey(
                name: "FK_SalesOrderLogoFiles_SalesOrderLogoLocation_SalesOrderLogoLocationId",
                table: "Files");

            migrationBuilder.DropColumn(
                name: "SalesOrderLogoLocationId",
                table: "Files");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Files",
                newName: "SalesOrderLogoFiles");

            migrationBuilder.DropColumn(
                name: "ContentType",
                table: "SalesOrderLogoFiles");

            migrationBuilder.RenameColumn(
                name: "Name",
                newName: "FileName",
                table: "SalesOrderLogoFiles");

            migrationBuilder.AddColumn<int>(
                name: "SalesOrderLogoLocationId",
                table: "SalesOrderLogoFiles",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_SalesOrderLogoFiles_SalesOrderLogoLocation_SalesOrderLogoLocationId",
                column: "SalesOrderLogoLocationId",
                table: "SalesOrderLogoFiles",
                principalTable: "SalesOrderLogoLocation",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderLogoFiles_SalesOrderLogoLocationId",
                table: "SalesOrderLogoFiles",
                column: "SalesOrderLogoLocationId");

            migrationBuilder.Sql(
                "UPDATE SalesOrderLogoFiles SET SalesOrderLogoFiles.SalesOrderLogoLocationId = SalesOrderFile.SalesOrderLogoLocationId FROM SalesOrderLogoFiles JOIN SalesOrderFile ON SalesOrderLogoFiles.Id = SalesOrderFile.FileId");

            migrationBuilder.DropTable(
                name: "SalesOrderFile");
        }
    }
}
