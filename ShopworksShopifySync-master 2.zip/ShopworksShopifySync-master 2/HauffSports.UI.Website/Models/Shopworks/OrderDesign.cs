﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("OrderDesign", Schema = "shopworks")]
    public class OrderDesign : BaseShopworks
    {
        public string OrderId { get; set; }
        public Order Order { get; set; }

        public string DesignId { get; set; }
        public Design Design { get; set; }

        public ICollection<OrderDesignLocation> OrderDesignLocations { get; set; }
    }
}

