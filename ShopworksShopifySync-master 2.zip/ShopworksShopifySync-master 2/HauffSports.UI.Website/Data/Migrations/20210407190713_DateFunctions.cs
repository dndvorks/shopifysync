﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class DateFunctions : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("CREATE FUNCTION dbo.getlocaldate(@timezone varchar(100)) RETURNS datetime2 AS BEGIN RETURN convert(datetime2(0), getutcdate() at time zone 'UTC' at time zone @timezone) END; ");
            migrationBuilder.Sql("CREATE FUNCTION dbo.getcstdate() RETURNS datetime2 AS BEGIN RETURN dbo.getlocaldate('Central Standard Time') END;");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("drop function dbo.getcstdate;");
            migrationBuilder.Sql("drop function dbo.getlocaldate;");
        }
    }
}
