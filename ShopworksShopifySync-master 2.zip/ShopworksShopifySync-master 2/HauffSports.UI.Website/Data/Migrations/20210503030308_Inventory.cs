﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HauffSports.UI.Website.Data.Migrations
{
    public partial class Inventory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "Cost",
                schema: "shopworks",
                table: "Product",
                type: "decimal(18,2)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AllowUpdateStatus",
                schema: "shopworks",
                table: "Product",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "HasSize01",
                schema: "shopworks",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasSize02",
                schema: "shopworks",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasSize03",
                schema: "shopworks",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasSize04",
                schema: "shopworks",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasSize05",
                schema: "shopworks",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasSize06",
                schema: "shopworks",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                schema: "shopworks",
                table: "Product",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PreprintGroup",
                schema: "shopworks",
                table: "Product",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "Price",
                schema: "shopworks",
                table: "Product",
                type: "decimal(18,2)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "InventoryLevel",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PartNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartColorRange = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Size01 = table.Column<int>(type: "int", nullable: true),
                    Size01_OnOrder = table.Column<int>(type: "int", nullable: true),
                    Size01_InProduction = table.Column<int>(type: "int", nullable: true),
                    Size01_Committed = table.Column<int>(type: "int", nullable: true),
                    Size01_Reconciled = table.Column<int>(type: "int", nullable: true),
                    Size01_ToReachMin = table.Column<int>(type: "int", nullable: true),
                    Size01_ToReachMax = table.Column<int>(type: "int", nullable: true),
                    Size02 = table.Column<int>(type: "int", nullable: true),
                    Size02_OnOrder = table.Column<int>(type: "int", nullable: true),
                    Size02_InProduction = table.Column<int>(type: "int", nullable: true),
                    Size02_Committed = table.Column<int>(type: "int", nullable: true),
                    Size02_Reconciled = table.Column<int>(type: "int", nullable: true),
                    Size02_ToReachMin = table.Column<int>(type: "int", nullable: true),
                    Size02_ToReachMax = table.Column<int>(type: "int", nullable: true),
                    Size03 = table.Column<int>(type: "int", nullable: true),
                    Size03_OnOrder = table.Column<int>(type: "int", nullable: true),
                    Size03_InProduction = table.Column<int>(type: "int", nullable: true),
                    Size03_Committed = table.Column<int>(type: "int", nullable: true),
                    Size03_Reconciled = table.Column<int>(type: "int", nullable: true),
                    Size03_ToReachMin = table.Column<int>(type: "int", nullable: true),
                    Size03_ToReachMax = table.Column<int>(type: "int", nullable: true),
                    Size04 = table.Column<int>(type: "int", nullable: true),
                    Size04_OnOrder = table.Column<int>(type: "int", nullable: true),
                    Size04_InProduction = table.Column<int>(type: "int", nullable: true),
                    Size04_Committed = table.Column<int>(type: "int", nullable: true),
                    Size04_Reconciled = table.Column<int>(type: "int", nullable: true),
                    Size04_ToReachMin = table.Column<int>(type: "int", nullable: true),
                    Size04_ToReachMax = table.Column<int>(type: "int", nullable: true),
                    Size05 = table.Column<int>(type: "int", nullable: true),
                    Size05_OnOrder = table.Column<int>(type: "int", nullable: true),
                    Size05_InProduction = table.Column<int>(type: "int", nullable: true),
                    Size05_Committed = table.Column<int>(type: "int", nullable: true),
                    Size05_Reconciled = table.Column<int>(type: "int", nullable: true),
                    Size05_ToReachMin = table.Column<int>(type: "int", nullable: true),
                    Size05_ToReachMax = table.Column<int>(type: "int", nullable: true),
                    Size06 = table.Column<int>(type: "int", nullable: true),
                    Size06_OnOrder = table.Column<int>(type: "int", nullable: true),
                    Size06_InProduction = table.Column<int>(type: "int", nullable: true),
                    Size06_Committed = table.Column<int>(type: "int", nullable: true),
                    Size06_Reconciled = table.Column<int>(type: "int", nullable: true),
                    Size06_ToReachMin = table.Column<int>(type: "int", nullable: true),
                    Size06_ToReachMax = table.Column<int>(type: "int", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventoryLevel", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "InventoryTransaction",
                schema: "shopworks",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PartNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartColorRange = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PartDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrderId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrderLineId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PurchaseOrderId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PurchaseOrderLineId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Size01 = table.Column<int>(type: "int", nullable: true),
                    Size01_Rem = table.Column<int>(type: "int", nullable: true),
                    Size02 = table.Column<int>(type: "int", nullable: true),
                    Size02_Rem = table.Column<int>(type: "int", nullable: true),
                    Size03 = table.Column<int>(type: "int", nullable: true),
                    Size03_Rem = table.Column<int>(type: "int", nullable: true),
                    Size04 = table.Column<int>(type: "int", nullable: true),
                    Size04_Rem = table.Column<int>(type: "int", nullable: true),
                    Size05 = table.Column<int>(type: "int", nullable: true),
                    Size05_Rem = table.Column<int>(type: "int", nullable: true),
                    Size06 = table.Column<int>(type: "int", nullable: true),
                    Size06_Rem = table.Column<int>(type: "int", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventoryTransaction", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Product_AllowUpdateStatus",
                schema: "shopworks",
                table: "Product",
                column: "AllowUpdateStatus");

            migrationBuilder.AddForeignKey(
                name: "FK_Product_Status_AllowUpdateStatus",
                schema: "shopworks",
                table: "Product",
                column: "AllowUpdateStatus",
                principalSchema: "shopworks",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Product_Status_AllowUpdateStatus",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropTable(
                name: "InventoryLevel",
                schema: "shopworks");

            migrationBuilder.DropTable(
                name: "InventoryTransaction",
                schema: "shopworks");

            migrationBuilder.DropIndex(
                name: "IX_Product_AllowUpdateStatus",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "AllowUpdateStatus",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "HasSize01",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "HasSize02",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "HasSize03",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "HasSize04",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "HasSize05",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "HasSize06",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "Notes",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "PreprintGroup",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "Price",
                schema: "shopworks",
                table: "Product");

            migrationBuilder.AlterColumn<string>(
                name: "Cost",
                schema: "shopworks",
                table: "Product",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)",
                oldNullable: true);
        }
    }
}
