﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using HauffSports.UI.Website.Models.Shopworks;
using Microsoft.EntityFrameworkCore;

namespace HauffSports.UI.Website.Models
{
    [Table("OrderNotification", Schema = "dbo")]
    [Index("OrderId", "EventType", IsUnique = true, Name = "IX_OrderIdEventType")]
    public class OrderNotification : BaseModel
    {
        public string OrderId { get; set; }
        public Order Order { get; set; }
        
        public string EventType { get; set; }
        public string Email { get; set; }
        public string Bcc { get; set; }
        public DateTime? SentAt { get; set; }
        public DateTime OrderUpdatedAt { get; set; }
    }
}