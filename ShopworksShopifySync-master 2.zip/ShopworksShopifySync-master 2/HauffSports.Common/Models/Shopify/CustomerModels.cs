﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace HauffSports.Common.Models.Shopify
{
    public class CustomerCreateModel
    {
        public CustomerCreateModel()
        {
            this.Id = 0;
            this.FirstName = string.Empty;
            this.LastName = string.Empty;
            this.Email = string.Empty;
            this.PhoneNumber = string.Empty;
            this.HasVerifiedEmail = false;
            this.SendEmailInvite = false;
            this.Addresses = new List<AddressCreateModel>();
            this.Metafields = new List<MetafieldModel>();
        }

        [JsonProperty(PropertyName = "id")]
        public long Id { get; set; }
        [JsonProperty(PropertyName = "first_name")]
        public string FirstName { get; set; }
        [JsonProperty(PropertyName = "last_name")]
        public string LastName { get; set; }
        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }
        [JsonIgnore]
        public string PhoneNumber { get; set; }
        [JsonProperty(PropertyName = "verified_email")]
        public bool HasVerifiedEmail { get; set; }
        [JsonProperty(PropertyName = "send_email_invite")]
        public bool SendEmailInvite { get; set; }
        [JsonIgnore]
        public List<AddressCreateModel> Addresses { get; set; }
        [JsonIgnore]
        public List<MetafieldModel> Metafields { get; set; }
    }

    public class CustomerModel : BaseModel
    {
        public CustomerModel()
        {
            this.LastOrderId = 0;
            this.LastOrderName = string.Empty;
            this.FirstName = string.Empty;
            this.LastName = string.Empty;
            this.Email = string.Empty;
            this.PhoneNumber = string.Empty;
            this.State = string.Empty;
            this.MultipassIdentifier = string.Empty;
            this.Note = string.Empty;
            this.Tags = string.Empty;
            this.OrderCount = 0;
            this.TotalSpent = 0.0m;
            this.AcceptsMarketing = false;
            this.HasVerifiedEmail = false;
            this.IsTaxExempt = false;
            this.Addresses = new List<AddressModel>();
            this.DefaultAddress = new AddressModel();
        }

        [JsonProperty(PropertyName = "last_order_id")]
        public long? LastOrderId { get; set; }
        [JsonProperty(PropertyName = "last_order_name")]
        public string LastOrderName { get; set; }
        [JsonProperty(PropertyName ="first_name")]
        public string FirstName { get; set; }
        [JsonProperty(PropertyName = "last_name")]
        public string LastName { get; set; }
        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }
        [JsonProperty(PropertyName = "phone_number")]
        public string PhoneNumber { get; set; }
        [JsonProperty(PropertyName = "state")]
        public string State { get; set; }
        [JsonProperty(PropertyName = "multipass_identifier")]
        public string MultipassIdentifier { get; set; }
        [JsonProperty(PropertyName = "note")]
        public string Note { get; set; }
        [JsonProperty(PropertyName = "tags")]
        public string Tags { get; set; }
        [JsonProperty(PropertyName = "order_count")]
        public int OrderCount { get; set; }
        [JsonProperty(PropertyName = "total_spent")]
        public decimal TotalSpent { get; set; }
        [JsonProperty(PropertyName = "accepts_marketing")]
        public bool AcceptsMarketing { get; set; }
        [JsonProperty(PropertyName = "has_verified_email")]
        public bool HasVerifiedEmail { get; set; }
        [JsonProperty(PropertyName = "is_tax_exempt")]
        public bool IsTaxExempt { get; set; }
        [JsonProperty(PropertyName = "addresses")]
        public List<AddressModel> Addresses { get; set; }
        [JsonProperty(PropertyName = "default_address")]
        public AddressModel DefaultAddress { get; set; }
    }
}
