﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Design", Schema = "shopworks")]
    public class Design : BaseShopworks
    {
        public string CustomerId { get; set; }
        public Customer Customer { get; set; }
        public string DesignName { get; set; }

        [ForeignKey("Active")]
        public string ActiveStatus { get; set; }
        public Status Active { get; set; }

        public ICollection<DesignLocation> DesignLocations { get; set; }
        public ICollection<DesignVariation> DesignVariations { get; set; }
        public ICollection<OrderDesign> OrderDesigns { get; set; }
    }
}
