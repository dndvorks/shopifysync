﻿using System;
using System.Data;
using System.IO;
using System.Text;


namespace HauffSports.Common.Converters
{
    public static class Convert
    {
        /// <summary>
        /// Adds data to the DataTable
        /// </summary>
        /// <param name="_dataTable">The DataTable to populate</param>
        /// <returns>A DataTable with the populated data</returns>
        public static DataTable AddData(DataTable _dataTable)
        {
            try
            {
                DataTable dt = _dataTable.Clone();

                for (int i = 0; i < 10; i++)
                {
                    DataRow dr = dt.NewRow();
                    for (int j = 0; j < _dataTable.Columns.Count; j++)
                        dr[j] = "Test " + i.ToString() + j.ToString();

                    dt.Rows.Add(dr);
                }

                return dt;
            }
            catch (Exception)
            {
                return _dataTable;
            }
        }

        /// <summary>
        /// Creates a delimited file from a DataTable
        /// </summary>
        /// <param name="_dataTable">The DataTable to create the delimited file from</param>
        /// <param name="_filePath">The path to save the file to</param>
        /// <param name="_delimitedValue">The string value used to seperate the file</param>
        /// <returns>A bool value if the file creation was successful</returns>
        public static bool CreateDelimitedFileFromDataTable(DataTable _dataTable, string _filePath, string _delimitedValue)
        {
            try
            {
                // Loop through each column header
                StringBuilder stringBuilder = new StringBuilder();
                foreach (DataColumn headerColumn in _dataTable.Columns)
                {
                    stringBuilder.Append(headerColumn.ColumnName.ToString() + _delimitedValue.Trim());
                    if (headerColumn.Ordinal == _dataTable.Columns.Count - 1)
                        stringBuilder.Append("~|");
                }

                // Loop through each datarow
                foreach (DataRow dataRow in _dataTable.Rows)
                {
                    // Loop through each column in datarow
                    foreach (DataColumn dataColumn in _dataTable.Columns)
                    {
                        stringBuilder.Append( dataRow[dataColumn].ToString() + _delimitedValue.Trim());
                        if (dataColumn.Ordinal == _dataTable.Columns.Count - 1)
                            stringBuilder.Append("~|");
                           
                    }
                }

                // Save the file to the path provided
                FileStream file = new FileStream(_filePath, FileMode.CreateNew, FileAccess.ReadWrite);
                StreamWriter writer = new StreamWriter(file, Encoding.UTF8);
                writer.Write(stringBuilder.ToString());
                writer.Flush();
                writer.Close();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
