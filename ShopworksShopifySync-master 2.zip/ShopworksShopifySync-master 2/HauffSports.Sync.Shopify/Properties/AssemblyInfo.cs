﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HauffSports.Sync.Shopify")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HauffSports.Sync.Shopify")]
[assembly: AssemblyCopyright("Copyright © 2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("974de49f-4702-4f9f-b592-7f569999a192")]
[assembly: AssemblyVersion("1.0.0.0")]