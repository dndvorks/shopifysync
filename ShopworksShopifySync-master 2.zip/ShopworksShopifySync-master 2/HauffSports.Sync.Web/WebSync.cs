﻿using HauffSports.Common.Clients.ShopWorks;
using log4net;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using Azure.Storage.Blobs;
using System.Collections.Generic;
using System.Linq;
using Azure.Storage.Blobs.Models;
using System.Text.RegularExpressions;

namespace HauffSports.Sync.Web
{
    public partial class WebSync
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly AppSettings _settings;

        public WebSync(AppSettings settings)
        {
            this._settings = settings;

            ServicePointManager.ServerCertificateValidationCallback += new RemoteCertificateValidationCallback(ValidateCertificate);
        }

        static bool ValidateCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }

        private class SqlHelper
        {
            private SqlConnection _conn;
            public SqlHelper(SqlConnection conn)
            {
                _conn = conn;
            }

            private SqlCommand Cmd(string query, SqlTransaction trans = null)
            {
                var cmd = new SqlCommand(query, _conn, trans);
                cmd.CommandTimeout = 0;
                return cmd;
            }

            public int Execute(string query, SqlTransaction trans = null)
            {
                return Cmd(query, trans).ExecuteNonQuery();
            }

            public object Value(string query, SqlTransaction trans = null)
            {
                return Cmd(query, trans).ExecuteScalar();
            }

            public SqlDataReader Reader(string query, SqlTransaction trans = null)
            {
                return Cmd(query, trans).ExecuteReader();
            }
        }

        private void SyncTables(SqlConnection conn, TableModel model, string cachePath)
        {
            var productClient = new ShopWorksProductClient(_settings.General.Shopworks, _settings.General.ImagesPath, false);
            var db = new SqlHelper(conn);

            var maxUpdated = (DateTime) productClient.FetchValue("select timestamp() from FileMaker_Tables fetch first row only", "Company");

            var clearTables = new Regex(_settings.General.ClearTables);

            foreach (var table in model.Tables)
            {
                var tableParts = table.DstName.Split('.');
                var tableName = tableParts.Last();
                var schema = tableParts.Length > 1 ? tableParts.First() : "dbo";
                var destTableName = $"[{schema}].[{tableName}]";
                var cacheFileName = Path.Combine(cachePath, $"{table.DstName}.xml");
                var schemaFileName = Path.Combine(cachePath, $"{table.DstName}.schema.xml");
                var clearTable = clearTables.IsMatch(table.DstName);
                DataTable data = null;

                if (!_settings.General.ReadCache)
                {
                    var minUpdated = new DateTime(1900, 01, 01);

                    if (!clearTable)
                    {
                        minUpdated = (DateTime)db.Value($"select coalesce(max(UpdatedAt), cast('1900-01-01' as datetime)) from {destTableName}");
                    }

                    Log.Info($"Getting new {destTableName} from {minUpdated} to {maxUpdated}");

                    DataTable chunkData = null;
                    int chunkSize = 20000;
                    int offset = 0;
                    bool firstTime = true;

                    do
                    {
                        var fields = string.Join(", ", table.Fields.ToList().Select(field => $"{field[0]} as {field[1]}"));
                        var query = $"select {fields} from \"{table.SrcName}\" "
                            + $"where {table.LastUpdated} > timestamp '{minUpdated:yyyy/MM/dd HH:mm:ss}' "
                            + $"and {table.LastUpdated} < timestamp '{maxUpdated:yyyy/MM/dd HH:mm:ss}' "
                            + (string.IsNullOrWhiteSpace(table.Where) ? " " : $"and {table.Where} ")
                            + (string.IsNullOrWhiteSpace(table.GroupBy) ? " " : $"group by {table.GroupBy} ")
                            + (string.IsNullOrWhiteSpace(table.GroupBy) ? $"order by {table.LastUpdated} asc " : " ")
                            + $"offset {offset} rows fetch first {chunkSize} rows only ";

                        chunkData = productClient.Fetch(query, table.Connection, table.DstName);
                        offset += chunkSize;

                        if (data == null)
                        {
                            data = chunkData;
                        }
                        else
                        {
                            data.Merge(chunkData);
                        }

                        if (!firstTime || chunkData.Rows.Count == chunkSize)
                        {
                            Log.Info($"Fetched {chunkData.Rows.Count} records...");
                        }

                        firstTime = false;

                    } while (chunkData.Rows.Count == chunkSize);

                    Log.Info($"Fetched {data.Rows.Count} total records for {destTableName}");

                    if (_settings.General.WriteCache)
                    {
                        data.WriteXml(cacheFileName);
                        data.WriteXmlSchema(schemaFileName);
                    }
                }

                if (_settings.General.ReadCache &&
                    File.Exists(cacheFileName) &&
                    File.Exists(schemaFileName))
                {
                    Log.Info($"Reading {data.Rows.Count} records for {destTableName}");

                    data = new DataTable(table.DstName);
                    data.ReadXmlSchema(schemaFileName);
                    data.ReadXml(cacheFileName);
                }

                if (data != null)
                {
                    if (data.Rows.Count > 0)
                    {
                        var tempTableName = $"[{schema}].[#Temp{tableName}]";
                        var tempFields = string.Join(", ", table.Fields.ToList().Select(field => $"{field[1]} {field[2]}"));

                        db.Execute($"drop table if exists {tempTableName};");
                        db.Execute($"create table {tempTableName} ({tempFields});");

                        var trans = conn.BeginTransaction();
                        var success = false;

                        try
                        {
                            SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans);
                            bulkCopy.BulkCopyTimeout = 0;
                            bulkCopy.DestinationTableName = tempTableName;
                            bulkCopy.WriteToServer(data);

                            db.Execute($"ALTER TABLE {destTableName} NOCHECK CONSTRAINT ALL", trans);

                            var insertFields = string.Join(", ", table.Fields.ToList().Select(field => field[1]));
                            var insertValues = string.Join(", ", table.Fields.ToList().Select(field => $"src.{field[1]}"));
                            var updateFields = string.Join(", ", table.Fields.ToList().Skip(1).Select(field => $"dst.{field[1]} = src.{field[1]}"));
                            
                            db.Execute(
                                $"MERGE {destTableName} AS dst " +
                                $"USING( " +
                                $"      SELECT * FROM {tempTableName}" +
                                $"  ) AS src " +
                                $"  ON dst.Id = src.Id " +
                                $"WHEN MATCHED THEN " +
                                $"  UPDATE SET {updateFields} " +
                                $"WHEN NOT MATCHED THEN " +
                                $"  INSERT ({insertFields}) VALUES ({insertValues});", trans);

                            foreach (var clean in table.Clean)
                            {
                                Log.Warn($"Cleaned {db.Execute(clean, trans)} records for {destTableName}");
                            }

                            var cleanupConditions = new Dictionary<string, Dictionary<string, List<string>>>();

                            using (var reader = db.Reader($"dbcc checkconstraints('{destTableName}') with all_constraints;", trans))
                            {
                                while (reader.Read())
                                {
                                    var constraintTable = reader["Table"] as string;
                                    var constraintWhere = reader["Where"] as string;
                                    var constraintName = reader["Constraint"] as string;

                                    if (!cleanupConditions.ContainsKey(constraintTable))
                                    {
                                        cleanupConditions.Add(constraintTable, new Dictionary<string, List<string>>());
                                    }

                                    if (!cleanupConditions[constraintTable].ContainsKey(constraintName))
                                    {
                                        cleanupConditions[constraintTable].Add(constraintName, new List<string>());
                                    }

                                    cleanupConditions[constraintTable][constraintName].Add(constraintWhere);
                                }
                            }

                            cleanupConditions
                                .Select(kvp => $"Cleaning up {kvp.Key} ({string.Join(", ", kvp.Value.Keys)})")
                                .ToList()
                                .ForEach(msg => Log.Warn(msg));

                            cleanupConditions
                                .Select(i =>
                                    $"DELETE FROM {i.Key} WHERE {string.Join(" OR ", i.Value.SelectMany(j => j.Value))} "
                                )
                                .ToList()
                                .ForEach(query => Log.Warn($"Cleaned {db.Execute(query, trans)} records for {destTableName}"));

                            db.Execute($"ALTER TABLE {destTableName} WITH CHECK CHECK CONSTRAINT ALL", trans);

                            success = true;
                        }
                        finally
                        {
                            if (success)
                            {
                                trans.Commit();
                            }
                            else
                            {
                                trans.Rollback();
                            }

                            db.Execute($"drop table if exists {tempTableName};");
                        }
                    }
                }
            }
        }

        private void GenerateOrderEmails(SqlConnection conn)
        {
            Log.Info("Generating Order Emails");

            var orderNotificationsQuery = File.ReadAllText(@"sql\orders.sql");

            var trans = conn.BeginTransaction();
            var success = false;

            try
            {
                var cmd = new SqlCommand(orderNotificationsQuery, conn, trans);
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
                success = true;
            }
            finally
            {
                if (success)
                {
                    trans.Commit();
                } 
                else 
                {
                    trans.Rollback(); 
                }
            }
        }

        private void GenerateInvoiceReminderEmails(SqlConnection conn)
        {
            Log.Info("Generating Invoice Reminder Emails");

            var orderNotificationsQuery = File.ReadAllText(@"sql\invoicing.sql");

            var trans = conn.BeginTransaction();
            var success = false;

            try
            {
                var cmd = new SqlCommand(orderNotificationsQuery, conn, trans);
                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
                success = true;
            }
            finally
            {
                if (success)
                {
                    trans.Commit();
                }
                else
                {
                    trans.Rollback();
                }
            }
        }

        private void SyncShopworks()
        {
            var tableModel = TableModel.FromJson(File.ReadAllText("tables.json"));
            var cachePath = Directory.CreateDirectory(_settings.General.CachePath).FullName;

            using (var conn = new SqlConnection(_settings.General.Website))
            {
                conn.Open();

                var db = new SqlHelper(conn);

                try
                {
                    db.Execute($"ALTER TABLE dbo.OrderNotification NOCHECK CONSTRAINT ALL");

                    SyncTables(conn, tableModel, cachePath);
                }
                finally
                {
                    var cleanupQueries = new List<string>();

                    using (var reader = db.Reader($"dbcc checkconstraints('dbo.OrderNotification') with all_constraints;"))
                    {
                        while (reader.Read())
                        {
                            Log.Warn($"Cleaning up \"{reader["Constraint"]}\" on {reader["Table"]} where {reader["Where"]}");
                            cleanupQueries.Add($"DELETE FROM {reader["Table"]} WHERE {reader["Where"]};");
                        }
                    }

                    cleanupQueries.ForEach(q => db.Execute(q));

                    db.Execute($"ALTER TABLE dbo.OrderNotification WITH CHECK CHECK CONSTRAINT ALL");
                }

                GenerateOrderEmails(conn);

                conn.Close();
            }
        }

        private void SyncInvoiceReminders()
        {
            using (var conn = new SqlConnection(_settings.General.Website))
            {
                conn.Open();

                GenerateInvoiceReminderEmails(conn);

                conn.Close();
            }
        }

        private void SyncLegacy(ManualResetEvent stopRequest)
        {
            // LEGACY UPDATES
            var productClient = new ShopWorksProductClient(_settings.General.Shopworks, _settings.General.ImagesPath, false);
            var customerClient = new ShopWorksCustomerClient(_settings.General.Shopworks);
            var orderClient = new ShopWorksOrderClient(_settings.General.Shopworks);

            Log.Info("Getting Products");
            var products = productClient.GetProductsSimple(stopRequest);

            // create products data table
            var productsTable = new DataTable("Products");
            productsTable.Columns.Add("Id", typeof(int));
            productsTable.Columns.Add("ProductId", typeof(int));
            productsTable.Columns.Add("ProductClassId", typeof(string));
            productsTable.Columns.Add("PartNumber", typeof(string));
            productsTable.Columns.Add("Description", typeof(string));
            productsTable.Columns.Add("Cost", typeof(string));
            productsTable.Columns.Add("Colors", typeof(string));

            int i = 0;

            foreach (var product in products)
            {
                productsTable.Rows.Add(
                    ++i,
                    product["ProductId"],
                    product["ProductClassId"],
                    product["PartNumber"],
                    product["Description"],
                    product["Cost"],
                    product["Colors"]
                );
            }

            Log.Info("Getting Customers");
            var customers = customerClient.GetCustomersSimple(stopRequest);

            // create customers data table
            var customersTable = new DataTable("Customers");
            customersTable.Columns.Add("Id", typeof(int));
            customersTable.Columns.Add("CompanyName", typeof(string));
            customersTable.Columns.Add("EmailMain", typeof(string));
            customersTable.Columns.Add("Address1", typeof(string));
            customersTable.Columns.Add("Address2", typeof(string));
            customersTable.Columns.Add("AddressCity", typeof(string));
            customersTable.Columns.Add("AddressState", typeof(string));
            customersTable.Columns.Add("AddressZip", typeof(string));

            foreach (var customer in customers)
            {
                customersTable.Rows.Add(
                    customer["CustomerId"],
                    customer["CompanyName"],
                    customer["EmailMain"],
                    customer["Address1"],
                    customer["Address2"],
                    customer["AddressCity"],
                    customer["AddressState"],
                    customer["AddressZip"]
                );
            }

            Log.Info("Getting Contacts");
            var contacts = customerClient.GetContactsSimple(stopRequest);

            // create contacts data table
            var contactsTable = new DataTable("Contacts");
            contactsTable.Columns.Add("Id", typeof(int));
            contactsTable.Columns.Add("CustomerId", typeof(int));
            contactsTable.Columns.Add("FirstName", typeof(string));
            contactsTable.Columns.Add("LastName", typeof(string));
            contactsTable.Columns.Add("Phone", typeof(string));
            contactsTable.Columns.Add("Email", typeof(string));

            foreach (var contact in contacts)
            {
                if (contact["FirstName"] != "" ||
                    contact["LastName"] != "" ||
                    contact["Phone"] != "" ||
                    contact["Email"] != "")
                {
                    contactsTable.Rows.Add(
                        contact["Id"],
                        contact["CustomerId"],
                        contact["FirstName"],
                        contact["LastName"],
                        contact["Phone"],
                        contact["Email"]
                    );
                }
            }

            Log.Info("Getting Designs");
            var designThumbnailsTable = orderClient.GetDesignThumbnailsTable(stopRequest);

            Log.Info("Writing Database");

            using (var conn = new SqlConnection(_settings.General.Website))
            {
                conn.Open();

                var db = new SqlHelper(conn);

                var trans = conn.BeginTransaction();
                var success = false;

                try
                {
                    var numProductsDeleted = db.Execute("delete from dbo.LegacyProduct;", trans);
                    var numCustomersDeleted = db.Execute("delete from dbo.LegacyCustomer;", trans);
                    var numContactsDeleted = db.Execute("delete from dbo.LegacyContact;", trans);
                    var numDesignsDeleted = db.Execute("delete from dbo.LegacyDesignThumbnail;", trans);

                    using (var copyProductsCmd = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans))
                    {
                        copyProductsCmd.DestinationTableName = "dbo.LegacyProduct";
                        copyProductsCmd.BulkCopyTimeout = 0;
                        copyProductsCmd.WriteToServer(productsTable);
                    }

                    using (var copyCustomersCmd = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans))
                    {
                        copyCustomersCmd.DestinationTableName = "dbo.LegacyCustomer";
                        copyCustomersCmd.BulkCopyTimeout = 0;
                        copyCustomersCmd.WriteToServer(customersTable);
                    }

                    using (var copyContactsCmd = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans))
                    {
                        copyContactsCmd.DestinationTableName = "dbo.LegacyContact";
                        copyContactsCmd.BulkCopyTimeout = 0;
                        copyContactsCmd.WriteToServer(contactsTable);
                    }

                    using (var copyDesignsCmd = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans))
                    {
                        copyDesignsCmd.DestinationTableName = "dbo.LegacyDesignThumbnail";
                        copyDesignsCmd.BulkCopyTimeout = 0;
                        copyDesignsCmd.WriteToServer(designThumbnailsTable);
                    }

                    success = true;
                }
                finally
                {
                    if (success)
                    {
                        trans.Commit();
                    }
                    else
                    {
                        trans.Rollback();
                    }
                }

                conn.Close();
            }
        }

        private void SyncThumbnails()
        {
            var client = new BlobServiceClient(_settings.General.Storage);

            //create a container 
            var container = client.GetBlobContainerClient("thumbnails");

            var existingBlobs = new Dictionary<string, string>();

            Log.Info("Checking existing blobs");

            foreach (var blockBlob in container.GetBlobs(BlobTraits.Metadata))
            {
                if (blockBlob != null && blockBlob.Metadata.ContainsKey("LastModified"))
                {
                    existingBlobs[blockBlob.Name] = blockBlob.Metadata["LastModified"];
                }
            }

            Log.InfoFormat("Checked {0} blobs", existingBlobs.Count);

            var thumbnailsDirectory = new DirectoryInfo(_settings.General.ImagesPath);

            var files = thumbnailsDirectory.GetFiles();

            Log.InfoFormat("Comparing to {0} files", files.Length);

            int numFilesUploaded = 0;

            foreach (var fileInfo in files)
            {
                string fileName = fileInfo.Name;
                string lastModified = fileInfo.LastWriteTimeUtc.ToString("o");

                if (!existingBlobs.ContainsKey(fileName) || existingBlobs[fileName] != lastModified)
                {
                    var blobClient = container.GetBlobClient(fileName);
                    blobClient.Upload(
                        fileInfo.FullName,
                        new BlobUploadOptions()
                        {
                            HttpHeaders = new BlobHttpHeaders()
                            {
                                ContentType = GetContentType(fileName)
                            },
                            Metadata = new Dictionary<string, string>()
                            {
                                { "LastModified", lastModified }
                            }
                        }

                    );
                    ++numFilesUploaded;
                }
            }

            Log.InfoFormat("Uploaded {0} files", numFilesUploaded);
        }

        public int Sync(ManualResetEvent stopRequest = null)
        {
            try
            {
                Log.Info("Web Sync Starting");

                if (_settings.General.SyncShopworks)
                {
                    Log.Info("Syncing Shopworks");
                    SyncShopworks();
                }

                if (_settings.General.SyncInvoiceReminders)
                {
                    Log.Info("Syncing Invoice Reminders");
                    SyncInvoiceReminders();
                }

                if (_settings.General.SyncLegacy)
                {
                    Log.Info("Syncing Legacy");
                    SyncLegacy(stopRequest);
                }

                if (_settings.General.SyncThumbnails)
                {
                    Log.Info("Syncing Thumbnails");
                    SyncThumbnails();
                }

                Log.Info("Web Sync Ended");
            }
            catch (Exception ex)
            {
                Log.Fatal(ex.Message, ex);

                if (!string.IsNullOrEmpty(_settings.General.ErrorEmail))
                {
                    var smtpClient = new SmtpClient(_settings.Email.Server)
                    {

                        Port = _settings.Email.Port,
                        Credentials = new NetworkCredential(_settings.Email.Address, _settings.Email.Password),
                        EnableSsl = _settings.Email.EnableSsl,
                    };

                    var from = new MailAddress(_settings.Email.Address, _settings.Email.DisplayName);
                    var to = new MailAddress(_settings.General.ErrorEmail);

                    var msg = new MailMessage(from, to);
                    msg.Subject = "Web Sync Failed";
                    msg.Body = ex.Message + "\r\n" + ex.StackTrace;

                    smtpClient.Send(msg);
                }

                return -1;
            }

            return 0;
        }

        private string GetContentType(string fileName)
        {
            return MimeMapping.MimeUtility.GetMimeMapping(fileName);
        }
    }
}
