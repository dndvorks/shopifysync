﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;

namespace HauffSports.Common.Clients.ShopWorks
{
    public abstract class ShopWorksBaseClient
    {
        protected string ConnectionString = "";
        protected Dictionary<string, OdbcConnection> Connections = new Dictionary<string, OdbcConnection>();

        public ShopWorksBaseClient(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        protected static string ConvertToString(object value)
        {
            try
            {
                if (value == DBNull.Value) return "";
                return Convert.ToString(value).Trim();
            }
            catch (Exception) { return ""; }
        }

        protected static decimal ConvertToDecimal(object value)
        {
            try
            {
                if (value == DBNull.Value) return 0.0m;
                return Convert.ToDecimal(value);
            }
            catch (Exception) { return 0.0m; }
        }

        protected static int ConvertToInt32(object value)
        {
            try
            {
                if (value == DBNull.Value) return 0;
                return Convert.ToInt32(value);
            }
            catch (Exception) { return 0; }
        }

        protected OdbcConnection GetConnection(string name)
        {
            return new($"DSN=FileMaker_Data_{name};{ConnectionString}");
        }

        public DataTable Fetch(string query, string connectionName, string resultName = "result")
        {
            var conn = GetConnection(connectionName);
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = query;

                var dataTable = new DataTable(resultName);

                conn.Open();

                var adapter = new OdbcDataAdapter(cmd);
                adapter.Fill(dataTable);
                return dataTable;
            }
        }

        public object FetchValue(string query, string connectionName)
        {
            var conn = GetConnection(connectionName);
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = query;
                return cmd.ExecuteScalar();
            }
        }
    }
}
