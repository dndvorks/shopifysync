with orderEmails as (
    select 
        o.Id as OrderId,
        case 
            when e.NameFull is not null then
                case
                    when dbo.ValidateEmail(e.EmailAddress, null) is not null then e.NameFull + ' <' + dbo.ValidateEmail(e.EmailAddress, null) + '>'
                    else null
                end
            else dbo.ValidateEmail(e.EmailAddress, null) 
        end as SalesRepEmailFull,
        case 
            when o.ContactFirst is not null or o.ContactLast is not null then
                case
                    when dbo.ValidateEmail(o.ContactEmail, null) is not null then ltrim(rtrim(coalesce(o.ContactFirst, '') + ' ' + coalesce(o.ContactLast, ''))) + ' <' + dbo.ValidateEmail(o.ContactEmail, null) + '>'
                    else null
                end
            else dbo.ValidateEmail(o.ContactEmail, null) 
        end as ContactEmailFull
    from shopworks."Order" o        
    left join shopworks.Employee e on
        e.NameFull = o.CustomerServiceRep and
        e.EmailAddress is not null
), orders as (
    select 
        o.Id as OrderId,
        o.OrderTypeId,
        o.HoldOrderText,
        o.LocationId,
        o.SalesStatusId,
        o.ShippedStatus,
        o.ReceivedStatus,
        o.ProducedStatus,
        o.UpdatedAt,
        a.ShipMethod,
        oe.SalesRepEmailFull as SalesRepEmail,
        coalesce(oe.ContactEmailFull, oe.SalesRepEmailFull) as ContactEmail,
        case
            when c.CustomField03 = 'No' then '0'
            else '1'
        end as SendConfirmation
    from shopworks."Order" o
    join orderEmails oe on
        oe.OrderId = o.id
    left join shopworks.Address a on 
        a.OrderId = o.id 
    left join shopworks.Customer c on
        c.Id = o.CustomerId
),
confirmation as (
    select
        OrderId,
        ContactEmail as Email,
        '' as Bcc,
        'Confirmation' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where
            OrderTypeId in (11, 13, 15, 21, 23, 83, 69, 70, 95)
        and HoldOrderText = 'No'    -- on hold
        and SendConfirmation = '1'  -- customer send confirmation
        and coalesce(ShippedStatus, '') != '1'    -- already shipped
        and coalesce(SalesStatusId, '') != '101'  -- already confirmed
        and coalesce(SalesStatusId, '') != '100'  -- on hold
),
completion_shipped as (
    select 
        OrderId,
        case
            when LocationId = '1' then ContactEmail
            else SalesRepEmail
        end as Email,
        case
            when LocationId = '1' then SalesRepEmail
            else ''
        end as Bcc,
        'Completion-Shipped' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where 
            ShipMethod = 'Ship'
        and ShippedStatus = '1'
),
completion_ready_to_ship as (
    select
        OrderId,
        'shipping@dakotalettering.com' as Email,
        '' as Bcc,
        'Completion-Ready-To-Ship' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where 
            ShipMethod = 'Ship'
        and (
                    OrderTypeId in (10, 11, 13, 21, 23, 83, 70) 
                and ProducedStatus = '1' 
                and ShippedStatus = '0'
            or
                    OrderTypeId in (15, 69, 73, 95) 
                and ReceivedStatus = '1' 
                and ShippedStatus = '0'
        )
),
completion_wholesale_pickup as (
    select
        OrderId,
        ContactEmail as Email,
        '' as Bcc,
        'Completion-Wholesale-Pickup' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where 
        ShipMethod = 'Wholesale Pick Up' and 
        ProducedStatus = '1' and 
        ShippedStatus = '0'
),
completion_other as (
    select 
        OrderId,
        SalesRepEmail as Email,
        '' as Bcc,
        'Completion-Other' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where 
        (
            ShipMethod is null
        )
        and (
                    OrderTypeId in (10, 11, 13, 21, 23, 83, 70) 
                and ProducedStatus = '1' 
                and ShippedStatus = '0'
            or
                    OrderTypeId in (15, 69, 73, 95) 
                and ReceivedStatus = '1' 
                and ShippedStatus = '0'
        )
),
completion_pickup as (
    select
        OrderId,
        ContactEmail as Email,
        '' as Bcc,
        'Completion-Pickup' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where 
            ShipMethod = 'Pick Up'
        and (
                    OrderTypeId in (10, 11, 13, 21, 23, 83, 70) 
                and ProducedStatus = '1' 
                and ShippedStatus = '0'
            or
                    OrderTypeId in (15, 69, 73, 95) 
                and ReceivedStatus = '1' 
                and ShippedStatus = '0'
        )
),
completion_pickup_07_days as (
    select
        rfp.OrderId,
        rfp.Email,
        '' as Bcc,
        'Completion-Pickup-7-Days' as EventType,
        rfp.OrderUpdatedAt
    from completion_pickup rfp
        join dbo.OrderNotification don on
                rfp.OrderId = don.OrderId
            and don.EventType = 'Completion-Pickup'
            and don.SentAt is not null
            and don.SentAt <= dateadd(day, -7, dbo.getcstdate())
),
completion_pickup_14_days as (
    select
        rfp.OrderId,
        rfp.Email,
        '' as Bcc,
        'Completion-Pickup-14-Days' as EventType,
        rfp.OrderUpdatedAt
    from completion_pickup rfp
        join dbo.OrderNotification don
            on rfp.OrderId = don.OrderId
            and don.EventType = 'Completion-Pickup'
            and don.SentAt is not null
            and don.SentAt <= dateadd(day, -14, dbo.getcstdate())
),
completion_pickup_21_days as (
    select
        rfp.OrderId,
        rfp.Email,
        concat(oe.SalesRepEmailFull, ',', 'Curt Hauff <curt@dakotalettering.com>') as Bcc,
        'Completion-Pickup-21-Days' as EventType,
        rfp.OrderUpdatedAt
    from completion_pickup rfp
        join dbo.OrderNotification don
            on rfp.OrderId = don.OrderId
            and don.EventType = 'Completion-Pickup'
            and don.SentAt is not null
            and don.SentAt <= dateadd(day, -21, dbo.getcstdate())
        join orderEmails oe on
            oe.OrderId = rfp.OrderId
),
completion_delivery as (
    select 
        OrderId,
        SalesRepEmail as Email,
        '' as Bcc,
        'Completion-Delivery' as EventType,
        UpdatedAt as OrderUpdatedAt
    from orders
    where 
            ShipMethod = 'Delivery'
        and (
                    OrderTypeId in (10, 11, 13, 21, 23, 83, 70) 
                and ProducedStatus = '1' 
                and ShippedStatus = '0'
            or
                    OrderTypeId in (15, 69, 73, 95) 
                and ReceivedStatus = '1' 
                and ShippedStatus = '0'
        )
),
completion_delivery_07_days as (
    select
        rfp.OrderId,
        rfp.Email,
        '' as Bcc,
        'Completion-Delivery-7-Days' as EventType,
        rfp.OrderUpdatedAt
    from completion_delivery rfp
        join dbo.OrderNotification don on
                rfp.OrderId = don.OrderId
            and don.EventType = 'Completion-Delivery'
            and don.SentAt is not null
            and don.SentAt <= dateadd(day, -7, dbo.getcstdate())
),
completion_delivery_14_days as (
    select
        rfp.OrderId,
        rfp.Email,
        '' as Bcc,
        'Completion-Delivery-14-Days' as EventType,
        rfp.OrderUpdatedAt
    from completion_delivery rfp
        join dbo.OrderNotification don
            on rfp.OrderId = don.OrderId
            and don.EventType = 'Completion-Delivery'
            and don.SentAt is not null
            and don.SentAt <= dateadd(day, -14, dbo.getcstdate())
),
completion_delivery_21_days as (
    select
        rfp.OrderId,
        rfp.Email,
        'Curt Hauff <curt@dakotalettering.com>' as Bcc,
        'Completion-Delivery-21-Days' as EventType,
        rfp.OrderUpdatedAt
    from completion_delivery rfp
        join dbo.OrderNotification don
            on rfp.OrderId = don.OrderId
            and don.EventType = 'Completion-Delivery'
            and don.SentAt is not null
            and don.SentAt <= dateadd(day, -21, dbo.getcstdate())
)
insert into dbo.OrderNotification(OrderId, EventType, Email, Bcc, OrderUpdatedAt, CreatedAt, UpdatedAt)
(
    select OrderId, 
        EventType, 
        Email, 
        Bcc, 
        OrderUpdatedAt, 
        dbo.getcstdate() as CreatedAt, 
        dbo.getcstdate() as UpdatedAt
    from (
              select * from confirmation
        union select * from completion_shipped
        union select * from completion_ready_to_ship
        union select * from completion_other
        union select * from completion_wholesale_pickup
        union select * from completion_pickup
        union select * from completion_pickup_07_days
        union select * from completion_pickup_14_days
        union select * from completion_pickup_21_days
        union select * from completion_delivery 
        union select * from completion_delivery_07_days 
        union select * from completion_delivery_14_days
        union select * from completion_delivery_21_days
    ) as new
    where not exists (
        select 1 
        from dbo.OrderNotification as o 
        where o.OrderId = new.OrderId and o.EventType = new.EventType
    )
);
