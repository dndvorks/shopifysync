﻿using log4net;
using HauffSports.Common.Models.Shopify;
using HauffSports.Common.RequestAndResponses.ShopWorksRequestAndResponses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Linq;
using System.Threading;

namespace HauffSports.Common.Clients.ShopWorks
{
    public class ShopWorksProductClient : ShopWorksBaseClient
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected OdbcConnection FileMakerProductsConnection { get; private set; }
        protected OdbcConnection FileMakerCompanyConnection { get; private set; }
        protected OdbcConnection FileMakerInventoryConnection { get; private set; }

        public List<ProductModel> Products { get; set; }
        public Dictionary<string, int> ProductInventory { get; set; }
        private Dictionary<int, string> ProductClasses { get; set; }
        private Dictionary<int, string> ProductColors { get; set; }
        private readonly string onSiteImagePath = "";
        private readonly bool useAlternatePrice = false;

        public ShopWorksProductClient(string connectionString, string onsiteImagePath, bool useAlternatePrice = false) : base(connectionString)
        {
            FileMakerProductsConnection = new OdbcConnection("DSN=FileMaker_Data_Products;" + ConnectionString);
            FileMakerCompanyConnection = new OdbcConnection("DSN=FileMaker_Data_Company;" + ConnectionString);
            FileMakerInventoryConnection = new OdbcConnection("DSN=FileMaker_Data_Inventory;" + ConnectionString);

            this.onSiteImagePath = onsiteImagePath; 
            this.useAlternatePrice = useAlternatePrice;
        }

        public List<Dictionary<string, string>> GetProductsSimple(ManualResetEvent stopRequest)
        {
            this.ProductColors = this.GetProductColors();

            var results = new List<Dictionary<string, string>>();
            var query = "SELECT p.ID_ProductSerial, p.id_ProductClass, p.PartNumber, p.Description, " +
                "p.cur_CostInventory AS Cost, p.id_ProductColorBlock " +
                "FROM Prod As p WHERE sts_Active = 1";

            using (var cmd = new OdbcCommand(query, FileMakerProductsConnection))
            { 
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    while (reader.Read())
                    {
                        if (stopRequest != null && stopRequest.WaitOne(0))
                        {
                            log.Info("Stop Requested");
                            break;
                        }

                        var result = new Dictionary<string, string>();

                        result.Add("ProductId", ConvertToString(reader["ID_ProductSerial"]));
                        result.Add("ProductClassId", ConvertToString(reader["id_ProductClass"]));
                        result.Add("PartNumber", ConvertToString(reader["PartNumber"]));
                        result.Add("Description", ConvertToString(reader["Description"]));
                        result.Add("Cost", ConvertToString(reader["Cost"]));
                        var colors = GetProductColors(ConvertToString(reader["id_ProductColorBlock"]), false).ToArray();
                        result.Add("Colors", String.Join(",", colors));

                        results.Add(result);
                    }
                }
            }

            return results;
        }

        public GetProductsResponse GetProducts(GetProductsRequest request, ManualResetEvent stopRequest)
        {
            try
            {
                this.ProductClasses = this.GetProductClasses();
                this.ProductInventory = this.GetProductInventory();
                this.ProductColors = this.GetProductColors();

                var response = new GetProductsResponse();
                var cmdText = GetProductCmdText() + "WHERE sts_AllowUpdate = 1";
                using (var cmd = new OdbcCommand(cmdText, FileMakerProductsConnection))
                {
                    cmd.Connection.Open();
                    this.Products = new List<ProductModel>();
                    using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (reader.Read())
                        {
                            if (stopRequest != null && stopRequest.WaitOne(0))
                            {
                                log.Info("Stop Requested");
                                break;
                            }
                            //LogReader(reader);
                            CreateProductModel(reader);
                        }

                    response.Products = this.Products;
                    response.IsSuccess = true;
                    return response;
                }
            }
            catch (Exception ex)
            {
                return new GetProductsResponse { ErrorMessage = ex.Message };
            }
        }

        public GetProductResponse GetProduct(GetProductRequest request)
        {
            try
            {
                this.ProductClasses = this.GetProductClasses();
                this.ProductInventory = this.GetProductInventory("WHERE PartNumber = '" + request.PartNumber.Trim() + "'");
                this.ProductColors = this.GetProductColors();

                var response = new GetProductResponse();
                var cmdText = GetProductCmdText() + "WHERE p.PartNumber = '" + request.PartNumber.Trim() + "' AND p.sts_AllowUpdate = 1";
                using (var cmd = new OdbcCommand(cmdText, this.FileMakerProductsConnection))
                {
                    cmd.Connection.Open();
                    this.Products = new List<ProductModel>();
                    using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (reader.Read())
                        {
                            LogReader(reader);
                            CreateProductModel(reader);
                        }

                    response.Products = this.Products;
                    response.IsSuccess = true;
                    return response;
                }
            }
            catch (Exception ex)
            {
                return new GetProductResponse { ErrorMessage = ex.Message };
            }
        }

        private void CreateProductModel(OdbcDataReader reader)
        {
            try
            {
                var title = ConvertToString(reader["Description"]);
                var partNumberArr = ConvertToString(reader["PartNumber"]).Split('_');
                var partNumber = partNumberArr[0].Trim();

                if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(partNumber))
                {
                    return;
                }

                var product = this.Products.FirstOrDefault(p => p.PartNumber.Equals(partNumber, StringComparison.CurrentCultureIgnoreCase));
                if (product == null)
                {
                    product = new ProductModel { PartNumber = partNumber };
                    this.Products.Add(product);
                }

                product.Title = title;
                product.BodyHtml = ConvertToString(reader["import_Notes"]);
                product.ProductType = ConvertToString(reader["ProductType"]);
                product.Vendor = ConvertToString(reader["VendorName"]);

                if (reader["ID_Serial"] != DBNull.Value && reader["FileName"] != DBNull.Value)
                {
                    var url = Path.Combine(this.onSiteImagePath, ConvertToString(reader["ID_Serial"]) + "_" + ConvertToString(reader["FileName"]));
                    product.ImageUrls.Add(url);
                }

                this.CreateMetafield(product, "shipping_days", ConvertToString(reader["CustomField09"]));
                this.CreateMetafield(product, "gender", ConvertToString(reader["CustomField01"]));
                this.CreateMetafield(product, "sub_category", ConvertToString(reader["CustomField02"]));
                this.CreateMetafield(product, "code_price", ConvertToString(reader["MtxPrice"]));
                this.CreateMetafield(product, "cost_price", ConvertToString(reader["MtxCost01"]));
                this.CreateMetafield(product, "find_code", ConvertToString(reader["FindCode"]));
                this.CreateMetafield(product, "preprint_group", ConvertToString(reader["PreprintGroup"]));

                var productClass = this.ProductClasses.FirstOrDefault(pc => pc.Key == ConvertToInt32(reader["id_ProductClass"]));
                if (productClass.Key > 0) this.CreateMetafield(product, "category", productClass.Value);

                var price = useAlternatePrice ? ConvertToDecimal(reader["MtxPrice"]) : 0.0m;
                if (price == 0.0m)
                {
                    price = ConvertToDecimal(reader["MtxPrice01"]);
                }

                var colors = ConvertToString(reader["id_ProductColorBlock"]);

                foreach (var color in GetProductColors(colors))
                {
                    if (ConvertToInt32(reader["cn_sts_LimitSize01Button"]) > 0)
                        this.CreateVariant(product, color, "s", price);
                    if (ConvertToInt32(reader["cn_sts_LimitSize02Button"]) > 0)
                        this.CreateVariant(product, color, "m", price);
                    if (ConvertToInt32(reader["cn_sts_LimitSize03Button"]) > 0)
                        this.CreateVariant(product, color, "l", price);
                    if (ConvertToInt32(reader["cn_sts_LimitSize04Button"]) > 0)
                        this.CreateVariant(product, color, "xl", price);
                    if (ConvertToInt32(reader["cn_sts_LimitSize05Button"]) > 0)
                        this.CreateVariant(product, color, "xxl", price);
                    if (ConvertToInt32(reader["cn_sts_LimitSize06Button"]) > 0)
                    {
                        var size = "o/s";
                        if (partNumberArr.Length > 1) size = partNumberArr[1];
                        this.CreateVariant(product, color, size, price);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to create model for " + Convert.ToString(reader["PartNumber"]) + " Error: " + ex.Message);
            }
        }

        private void CreateVariant(ProductModel product, string color, string size, decimal price)
        {
            try
            {
                if (string.IsNullOrEmpty(color)) color = "o/c";
                if (string.IsNullOrEmpty(size)) size = "o/s";
                var sku = product.PartNumber.Trim() + "-" + color + "-" + size;
                var variant = product.Variants.FirstOrDefault(v => v.Sku.Equals(sku, StringComparison.CurrentCultureIgnoreCase));

                if (variant == null)
                {
                    variant = new ProductVariantModel { Color = color, Size = size, Sku = sku};

                    product.Variants.Add(variant);

                    var colorOption = product.Options.FirstOrDefault(o => o.Name.Equals("Color"));
                    if (colorOption == null)
                    {
                        colorOption = new OptionModel { Name = "Color" };
                        product.Options.Add(colorOption);
                    }
                    if (!colorOption.Values.Contains(color, StringComparer.CurrentCultureIgnoreCase))
                        colorOption.Values.Add(color);

                    var sizeOption = product.Options.FirstOrDefault(o => o.Name.Equals("Size"));
                    if (sizeOption == null)
                    {
                        sizeOption = new OptionModel { Name = "Size" };
                        product.Options.Add(sizeOption);
                    }
                    if (!sizeOption.Values.Contains(size, StringComparer.CurrentCultureIgnoreCase))
                        sizeOption.Values.Add(size);
                }
                variant.Price = Math.Round(price, 2);
                variant.Taxable = true;

                var inventory = this.ProductInventory.FirstOrDefault(i => i.Key.Equals(sku, StringComparison.CurrentCultureIgnoreCase));
                if (string.IsNullOrEmpty(inventory.Key)) variant.InventoryQuantity = 0;
                else variant.InventoryQuantity = inventory.Value;

            }
            catch (Exception) { }
        }

        private void CreateMetafield(ProductModel product, string key, string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                var existingMetaField = product.Metafields.FirstOrDefault(m => m.Key == key);
                if (existingMetaField == null)
                {
                    var metafield = new MetafieldModel { Namespace = "global", Key = key, Value = value, ValueType = "string" };
                    product.Metafields.Add(metafield);
                }
                else
                {
                    existingMetaField.Value = value;
                }
            }
        }

        private Dictionary<string, int> GetProductInventory(string whereClause = "")
        {
            try
            {
                var inventory = new Dictionary<string, int>();
                var cmdText = "Select PartNumber, PartColor, Size01, Size02, Size03, Size04, Size05, Size06 FROM InvLevels " + whereClause;
                using (var cmd = new OdbcCommand(cmdText, this.FileMakerInventoryConnection))
                {
                    cmd.Connection.Open();
                    using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            //LogReader(reader);
                            var partNumberArr = ConvertToString(reader["PartNumber"]).Split('_');
                            var partNumber = partNumberArr[0].Trim();
                            var color = ConvertToString(reader["PartColor"]);

                            if (string.IsNullOrEmpty(color)) color = "o/c";
                            var sizes = new List<Tuple<int, string>>();
                            if (ConvertToInt32(reader["Size01"]) > 0)
                                sizes.Add(new Tuple<int, string>(ConvertToInt32(reader["Size01"]), "s"));
                            if (ConvertToInt32(reader["Size02"]) > 0)
                                sizes.Add(new Tuple<int, string>(ConvertToInt32(reader["Size02"]), "m"));
                            if (ConvertToInt32(reader["Size03"]) > 0)
                                sizes.Add(new Tuple<int, string>(ConvertToInt32(reader["Size03"]), "l"));
                            if (ConvertToInt32(reader["Size04"]) > 0)
                                sizes.Add(new Tuple<int, string>(ConvertToInt32(reader["Size04"]), "xl"));
                            if (ConvertToInt32(reader["Size05"]) > 0)
                                sizes.Add(new Tuple<int, string>(ConvertToInt32(reader["Size05"]), "xxl"));
                            if (ConvertToInt32(reader["Size06"]) > 0)
                            {
                                var size = "o/s";
                                if (partNumberArr.Length > 1) size = partNumberArr[1];
                                sizes.Add(new Tuple<int, string>(ConvertToInt32(reader["Size06"]), size));
                            }

                            foreach (var size in sizes)
                            {
                                var sku = partNumber + "-" + color + "-" + size.Item2;
                                var _inventory = inventory.FirstOrDefault(i => i.Key.Equals(sku, StringComparison.CurrentCultureIgnoreCase));
                                if (string.IsNullOrEmpty(_inventory.Key)) inventory.Add(sku, size.Item1);
                            }
                        }

                        return inventory;
                    }
                }
            }
            catch (Exception)
            {
                return new Dictionary<string, int>();
            }
        }

        private Dictionary<int, string> GetProductClasses()
        {
            var productClasses = new Dictionary<int, string>();
            var cmdText = "SELECT ID_ProductClass, ProductClass FROM ProdClass";
            using (var cmd = new OdbcCommand(cmdText, this.FileMakerCompanyConnection))
            {
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    while (reader.Read())
                    {
                        //LogReader(reader);
                        if (reader["ID_ProductClass"] != DBNull.Value && reader["ProductClass"] != DBNull.Value)
                            productClasses.Add(Convert.ToInt32(reader["ID_ProductClass"]), Convert.ToString(reader["ProductClass"]));
                    }
                }

                return productClasses;
            }
        }

        private Dictionary<Int32,string> GetProductColors()
        {
            var colors = new Dictionary<Int32, string>();
            var cmdText = "SELECT ID_ProductColors, ProductColors FROM ProdCol";
            using (var cmd = new OdbcCommand(cmdText, this.FileMakerCompanyConnection))
            {
                cmd.Connection.Open();
                using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    while (reader.Read())
                    {
                        //LogReader(reader);
                        colors.Add(ConvertToInt32(reader["ID_ProductColors"]), ConvertToString(reader["ProductColors"]));
                    }
                }
                return colors;
            }
        }

        private List<string> GetProductColors(string colorBlockArray, bool includeOther = true)
        {
            var colorString = colorBlockArray.Replace((char)13, ',').Replace("_", "").Replace(" ", "").Trim(',');
            if (string.IsNullOrEmpty(colorString))
            {
                if (includeOther)
                {
                    return new List<string> { "o/c" };
                }

                return new List<string>();
            }

            var idColorArray = colorString.Split(',').Select(Int32.Parse).ToList();
            var colors = idColorArray.Where(k => ProductColors.ContainsKey(k)).Select(k => ProductColors[k]).ToList();

            if (colors.Count == 0 && includeOther)
            {
                colors.Add("o/c");
            }

            return colors;
        }

        private static string GetProductCmdText()
        {
            return "SELECT p.Description, t.FileName, p.ID_ProductSerial, p.PartNumber, p.ProductType, v.VendorName, " +
                          "p.import_Notes, t.ID_Serial, p.MtxPrice01, p.sts_AllowUpdate, v.CustomField09, p.CustomField01, " +
                          "p.CustomField02, pm.MtxPrice, p.MtxCost01, p.id_ProductClass, p.FindCode, p.PreprintGroup, " +
                          "p.cn_sts_LimitSize01Button, p.cn_sts_LimitSize02Button, p.cn_sts_LimitSize03Button, " +
                          "p.cn_sts_LimitSize04Button, p.cn_sts_LimitSize05Button, p.cn_sts_LimitSize06Button, p.id_ProductColorBlock " +
                   "FROM Prod As p " +
                   "LEFT JOIN Thumb As t on t.id_ProductSerial = p.ID_ProductSerial " +
                   "LEFT JOIN Ven As v on v.ID_Vendor = p.id_Vendor " +
                   "LEFT JOIN PriceMtx pm ON pm.id_Product = p.ID_ProductSerial ";
        }

        private static void LogReader(OdbcDataReader reader)
        {
            var msg = "";
            for (int i = 0; i < reader.FieldCount; i++)
            {
                msg += "[" + reader.GetName(i) + ": " + Convert.ToString(reader[i]) + "]";
            }
            log.Debug(msg);
        }
    }
}