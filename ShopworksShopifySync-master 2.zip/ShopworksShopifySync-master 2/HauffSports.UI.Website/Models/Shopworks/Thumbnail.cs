﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HauffSports.UI.Website.Models.Shopworks
{
    [Table("Thumbnail", Schema = "shopworks")]
    public class Thumbnail : BaseShopworks
    {
        public string DesignLocationId { get; set; }
        public DesignLocation DesignLocation { get; set; }

        public string OrderDesignLocationId { get; set; }
        public OrderDesignLocation OrderDesignLocation { get; set; }

        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public string FileLocation { get; set; }
        public string FileWidth { get; set; }
        public string FileHeight { get; set; }
        public string FileStorageType { get; set; }
    }
}
